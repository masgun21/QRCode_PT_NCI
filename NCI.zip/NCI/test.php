<?php
include('dbcon.php');

/* $sql = "SELECT part_code FROM tbl_inventory WHERE replaced=1 AND delivered=1 AND qty=0 GROUP BY part_code";
$stmt = $conn->prepare($sql);
$stmt->execute();
$ep = array();
while($data = $stmt->fetch(PDO::FETCH_ASSOC)){
	$ep[] = $data['part_code'];
}

for($x = 0; $x <= sizeof($ep) - 1; $x++){
	$sql = "UPDATE tbl_inventory SET qty=(SELECT QTY_PER_BOX FROM tbl_parts WHERE PART_CODE='$ep[$x]') WHERE part_code='$ep[$x]' AND replaced=1 AND delivered=1 AND qty=0";
	$stmt = $conn->prepare($sql);
	$stmt->execute();

	echo $x."<br>";
}

 */

?>