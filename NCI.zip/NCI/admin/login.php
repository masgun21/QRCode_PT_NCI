<?php

include('dbcon.php');

session_start();
if(isset($_POST['username']) && isset($_POST['pw'])){
    $username = $_POST['username'];
    $pw = $_POST['pw'];
    $pw = md5($pw);

    $sql = "SELECT * FROM tbl_users WHERE username=? AND password=? AND role='ADMIN'";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$username, $pw]);

    if($row = $stmt->fetch(PDO::FETCH_ASSOC)){
        $_SESSION['userId'] = $row['user_id'];
        header('location:dashboard.php?id='.md5($_SESSION['userId']));
    } else {
        header('location:index.php?error=invalid_credentials');
        $error = "Invalid Crendetials";
    }
}

?>