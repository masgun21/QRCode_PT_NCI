<!doctype html>
<html lang="en">
<head>
    <title>PT. NCI Indonesia</title>
    <?php include 'include/header.php';?>
    <link href="assets/css/documentation.css" rel="stylesheet" />
    <link href="assets/css/prettify.css" rel="stylesheet" type="text/css">
</head>
<body>
    <div class="header-wrapper">
        <div class="header" style="background-image: url('assets/img/full-screen-image-3.jpg');">
            <div class="filter"></div>
            <div class="title-container text-center">
                <img src="assets/img/logo-nci2.png">
                <h3>Login</h3>
                <p class="description text-center">Please insert your username and password.</p>
                <div class="col-md-4">
                </div>
                <div class="col-md-4">
                    <form role="form" method="post" action="login.php">
                        <fieldset>
                            <div class="form-group">
                                <input class="form-control" placeholder="Username" name="username" autofocus>
                            </div>
                            <div class="form-group">
                                <input class="form-control" placeholder="Password" name="pw" type="password" value="">
                            </div>
                            
                            <input type="submit" class="btn btn-success btn-block btn-fill" value="Login">
                        </fieldset>
                    </form>
                </div>
                <div class="col-md-4">
                </div>
            </div>
        </div>
    </div>
</body>
<?php include 'include/footer.php';?>
</html>
