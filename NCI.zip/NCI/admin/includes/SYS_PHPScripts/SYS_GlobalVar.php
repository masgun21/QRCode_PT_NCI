<?php

// System debug mode
define("SYS_GlobalVar_ENABLE_DEBUG_MODE", TRUE);    

define("SYS_GlobalVar_STRING_ARRAY_DELIMITER0", "_#$%%$#_");    
define("SYS_GlobalVar_STRING_ARRAY_DELIMITER1", "_)(**()_");    

function SYS_GlobalVar_WriteToLogFile($msg,$user="SYSTEM",$logFileName=""){
	
	return; // do not log 
	
	
	$arrbt=debug_backtrace();
	//$stringRepresentation= json_encode($arrbt);
	$msg = basename($arrbt[0]['file']). ",".$msg;

	$userid="";
	if(isset($_SESSION['UserID'])){
		$userid=$_SESSION['UserID'];
	}	
	$msg= date("d/m/Y G:i:s").",$userid,".$msg;

	if($logFileName===""){
		$logFile='/KPCData/KPCLogs/kios.appxmart.id.log';
		if(isset($_SERVER['SERVER_NAME'])){
			$logFile="/KPCData/KPCLogs/".$_SERVER['SERVER_NAME'].".log";
		}
		
	}
	else
		$logFile=$logFileName;
	
 	$myfile = file_put_contents($logFile, $msg.PHP_EOL , FILE_APPEND);
 	//$myfile = file_put_contents('logs.txt', $msg.PHP_EOL , FILE_APPEND | LOCK_EX);
}


function my_error_handler($num,$msg,$errfile, $errline) {
	$msg= "RK Error msg -> File = $errfile, Line = $errline, Err Num = $num, Err Msg = $msg";
	echo "ERROR FOUND, see KIOS Error log file <br>";	
	$msg = str_replace("'","\'",$msg);	
	$msg= date("M d, G:i:s").", ".$msg;
	
	$logFile='/KPCData/KPCLogs/Error-kios.appxmart.id.log';
	if(isset($_SERVER['SERVER_NAME'])){
		$logFile="/KPCData/KPCLogs/Error-".$_SERVER['SERVER_NAME'].".log";
	}

 	$myfile = file_put_contents($logFile, $msg.PHP_EOL , FILE_APPEND);
	
	die;
}

function SYS_GlobalVar_cleaner_integer($var){
	if($var==null) $var=0;
	$var=(filter_var($var, FILTER_SANITIZE_NUMBER_INT));
	return htmlspecialchars($var);
}
function SYS_GlobalVar_cleaner_float($var){
	if($var==null) $var=0;
	$var=(filter_var($var, FILTER_SANITIZE_NUMBER_FLOAT,FILTER_FLAG_ALLOW_FRACTION));
	$var=$var+0;  // ini utk membuang 0 yg tidak terpakai dibelakang koma
	return htmlspecialchars($var);
}

function SYS_GlobalVar_cleaner_email($var){
	if($var==null) $var="";
	$var=(filter_var($var, FILTER_SANITIZE_EMAIL));
	return htmlspecialchars($var);
}
function SYS_GlobalVar_cleaner_string($var){
	//java script injection jadi gagal
	if($var==null) $var="";
	$var=str_replace(SYS_GlobalVar_STRING_ARRAY_DELIMITER0,"",$var); 
	$var=str_replace(SYS_GlobalVar_STRING_ARRAY_DELIMITER1,"",$var);
	$var=trim($var);
	$var = stripslashes($var); // buang semua \: \ bisa ngacauin string
    //$var = str_replace("\\","\\\\",$var);
    // $var = str_replace("\"","\\\"",$var);

	$var=(filter_var($var, FILTER_SANITIZE_STRING)); // 'diganti jadi &#39; " jadi &#34;  html tag dihilangkan
	//$var = preg_replace("/[^a-zA-Z0-9 =~!@#$%^&*(){}:?-]+/", "", $var);  // buang selain space, A-Z a-z 0-9 dan ~!@#$%^&*(){}:?-
	return $var;
}
function SYS_GlobalVar_cleaner_sql($var){
	global $SYS_GlobalVar_mysqli;
	if($var==null) $var="";
	//$var= mysql_real_escape_string($var);
	$var = $SYS_GlobalVar_mysqli->real_escape_string($var);
	$var= stripslashes($var);
	//return $var;
	return htmlspecialchars($var);
}
function SYS_GlobalVar_SafePrint($data){
	return htmlspecialchars($data);
}




if(SYS_GlobalVar_ENABLE_DEBUG_MODE==TRUE){
	error_reporting(E_ALL);
	ini_set('display_errors', 1);
}	
set_error_handler("my_error_handler");

global $SYS_GlobalVar_mysqli;
//$SYS_GlobalVar_mysqli = new mysqli(SYS_GlobalVar_HOST, SYS_GlobalVar_USER, SYS_GlobalVar_PASSWORD, SYS_GlobalVar_DATABASE);
$SYS_GlobalVar_mysqli = new PDO( "sqlsrv:server=.\sqlexpress ; Database=DaihoQRScanner", "", "");  
$SYS_GlobalVar_mysqli->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );

global $SYS_GlobalVar_HTTPREFERER;
$SYS_GlobalVar_HTTPREFERER="#";
if(isset($_SERVER['HTTP_REFERER'])) $SYS_GlobalVar_HTTPREFERER=$_SERVER['HTTP_REFERER'];


global $SYS_GlobalVar_SERVERTYPE;
$SYS_GlobalVar_SERVERTYPE="(Prod Server)";
if(isset($_SERVER['SERVER_NAME'])){	
	if (strpos(strtoupper($_SERVER['SERVER_NAME']), 'TEST') !== false) $SYS_GlobalVar_SERVERTYPE="(Test Server)";
	else if (strpos(strtoupper($_SERVER['SERVER_NAME']), 'DEV0') !== false) $SYS_GlobalVar_SERVERTYPE="(Dev0 Server)";
	else if (strpos(strtoupper($_SERVER['SERVER_NAME']), 'DEV') !== false) $SYS_GlobalVar_SERVERTYPE="(Dev Server)";
} 

?>
