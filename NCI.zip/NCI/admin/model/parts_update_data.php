<?php

				
	            $i = 0;
	            $search = $_GET['search']['value'];
	            $offset = $_GET['start'];
	            $size = $_GET['length'];
	            $draw = intval($_GET['draw']);
	            $data = array();
	            include("../dbcon.php");

	            $sel = "SELECT * FROM part_test ORDER BY PART_CODE ASC";

	            
	            $stmt = $conn->prepare($sel." OFFSET ".$offset." ROWS FETCH NEXT ".$size." ROWS ONLY");
	            $stmt->execute();
	           
	                            while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
	                            	$data[$i][0] = $row['PART_CODE'];
	                                $data[$i][1] = $row['PART_NO'];
	                                $data[$i][2] = $row['PART_NAME'];
	                                $data[$i][3] = $row['model'];
	                                $data[$i][4] = $row['MONTH_PP'];
	                                $data[$i][5] = $row['PART_PRICE'];
	                                $data[$i][6] = $row['QTY_PER_BOX'];
	                                $data[$i][7] = $row['status'];
	                                $data[$i][8] = $row['plain_parts'];
	                                $data[$i][9] = $row['spray_paint'];
                                    $data[$i][10] = $row['RAWMTL_CODE'];
                                    $data[$i][11] = $row['COLOR_CODE'];
	                                $data[$i][12] = $row['SUBMTL_CODE1'];
	                                $data[$i][13] = $row['submatl1_wt'];
	                                $data[$i][14] = $row['submatl1_price'];
	                                $data[$i][15] = $row['SUBMTL_CODE2'];
	                                $data[$i][16] = $row['submatl2_wt'];
	                                $data[$i][17] = $row['submatl2_price'];
	                                $data[$i][18] = $row['SUBMTL_CODE3'];
	                                $data[$i][19] = $row['submatl3_wt'];
                                    $data[$i][20] = $row['submatl3_price'];
                                    $data[$i][21] = $row['SUBMTL_CODE4'];
	                                $data[$i][22] = $row['submatl4_wt'];
	                                $data[$i][23] = $row['submatl4_price'];
	                                $data[$i][24] = $row['SUBMTL_CODE5'];
	                                $data[$i][25] = $row['submatl5_wt'];
	                                $data[$i][26] = $row['submatl5_price'];
	                                $data[$i][27] = $row['Submatl_Total'];
	                                $data[$i][28] = $row['Material_Price'];
	                                $data[$i][29] = $row['Partition_code'];
                                    $data[$i][30] = $row['Tray_code'];
                                    $data[$i][31] = $row['Box_code'];
	                                $data[$i][32] = $row['Sprue_weight'];
	                                $data[$i][33] = $row['Bag_code'];
	                                $data[$i][34] = $row['Bag_dim'];
	                                $data[$i][35] = $row['Mira_code'];
	                                $data[$i][36] = $row['Mira_dim'];
	                                $data[$i][37] = $row['CAV'];
	                                $data[$i][38] = $row['CYCLE'];
	                                $data[$i][39] = $row['PART_WEIGHT'];
                                    $data[$i][40] = $row['cust_code'];
                                    $data[$i][41] = $row['mc_no'];
	                                $data[$i][42] = $row['mt_code'];
	                                $data[$i][43] = $row['remarks'];
	                                $data[$i][44] = $row['matl_maker'];
	                                $data[$i][45] = $row['matl_grade'];
	                                $data[$i][46] = $row['matl_type'];
	                                $data[$i][47] = $row['rgrind_ratio'];
	                                $data[$i][48] = $row['ul_flame'];
	                                $data[$i][49] = $row['partition_price'];
                                    $data[$i][50] = $row['tray_price'];
                                    $data[$i][51] = $row['box_price'];
	                                $data[$i][52] = $row['bag_price'];
	                                $data[$i][53] = $row['mira_price'];
	                                $data[$i][54] = $row['man_power'];
	                                $data[$i][55] = $row['TONNAGE'];
	                                $data[$i][56] = $row['SUPPLIER'];
	                                $data[$i][57] = $row['Label_Color'];
	                                $data[$i][58] = $row['upsize_ts'];
	                                $data[$i][59] = $row['ep_no'];
	                                $data[$i][60] = $row['unit_price'];
	                                $i++;
	                     		}

	            
	            $stmt = $conn->prepare($sel);
	            $stmt->execute();
	                            $x = 0;
	                            while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
	                                $x++;
	                     		}
	                 


	$total = $x;
	$json_data = array(
	    "draw"            => intval( $_REQUEST['draw'] ), #
	    "recordsTotal"    =>  intval($total), #total number of records
	    "recordsFiltered" =>  intval($total), #Total number of filtered results after search. no search = number will be same for recordsTotal
	    "data"            => $data #fetched record data in multidimensional array
	);
	echo json_encode($json_data);


?>