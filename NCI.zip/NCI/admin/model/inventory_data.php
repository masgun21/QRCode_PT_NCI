<?php
if(isset($_GET['inv'])){
				$inventory = $_GET['inv'];
	            $i = 0;
	            $search = $_GET['search']['value'];
	            $offset = $_GET['start'];
	            $size = $_GET['length'];
	            $draw = intval($_GET['draw']);
	            $data = array();
	            include("../dbcon.php");

	            if($inventory == "WIP"){
	            	$sel = "SELECT tbl_parts.MONTH_PP, tbl_inventory_WIP.part_code, tbl_inventory_WIP.part_no, tbl_inventory_WIP.part_name, tbl_inventory_WIP.lot_date, SUM(tbl_inventory_WIP.qty) AS QTY FROM tbl_inventory_WIP INNER JOIN tbl_parts ON tbl_inventory_WIP.part_code = tbl_parts.PART_CODE WHERE ((tbl_inventory_WIP.part_code LIKE '%".$search."%') OR (tbl_inventory_WIP.part_no LIKE '%".$search."%') OR (tbl_inventory_WIP.lot_date LIKE '%".$search."%') OR (tbl_parts.MONTH_PP LIKE '%".$search."%')) AND tbl_inventory_WIP.DOCNUM_2 IS NULL AND tbl_inventory_WIP.delivered=0 GROUP BY tbl_parts.MONTH_PP, tbl_inventory_WIP.part_code, tbl_inventory_WIP.part_no, tbl_inventory_WIP.part_name, tbl_inventory_WIP.lot_date ORDER BY tbl_inventory_WIP.lot_date ASC";

	            } else if($inventory == "ONHOLD"){
	            	$sel = "SELECT tbl_parts.MONTH_PP, tbl_inventory_OH.part_code, tbl_inventory_OH.part_no, tbl_inventory_OH.part_name, tbl_inventory_OH.lot_date, SUM(tbl_inventory_OH.qty) AS QTY FROM tbl_inventory_OH INNER JOIN tbl_parts ON tbl_inventory_OH.part_code = tbl_parts.PART_CODE WHERE ((tbl_inventory_OH.part_code LIKE '%".$search."%') OR (tbl_inventory_OH.part_no LIKE '%".$search."%') OR (tbl_inventory_OH.lot_date LIKE '%".$search."%' OR (tbl_parts.MONTH_PP LIKE '%".$search."%'))) AND tbl_inventory_OH.DOCNUM_2 IS NULL AND tbl_inventory_OH.disposed IS NULL GROUP BY tbl_parts.MONTH_PP, tbl_inventory_OH.part_code, tbl_inventory_OH.part_no, tbl_inventory_OH.part_name, tbl_inventory_OH.lot_date ORDER BY tbl_inventory_OH.lot_date ASC";

	            } else if($inventory == "FGWHS"){ //tbl_inventory data
	            	$sel = "SELECT tbl_parts.MONTH_PP, tbl_inventory.part_code, tbl_inventory.part_no, tbl_inventory.part_name, tbl_inventory.lot_date, SUM(tbl_inventory.qty) AS QTY FROM tbl_inventory INNER JOIN tbl_parts ON tbl_inventory.part_code = tbl_parts.PART_CODE WHERE ((tbl_inventory.part_code LIKE '%".$search."%') OR (tbl_inventory.part_no LIKE '%".$search."%') OR (tbl_inventory.lot_date LIKE '%".$search."%') OR (tbl_parts.MONTH_PP LIKE '%".$search."%')) AND tbl_inventory.on_hold='0' AND tbl_inventory.delivered IS NULL GROUP BY tbl_parts.MONTH_PP, tbl_inventory.part_code, tbl_inventory.part_no, tbl_inventory.part_name, tbl_inventory.lot_date ORDER BY tbl_inventory.lot_date ASC";

	            }

	            
	            $stmt = $conn->prepare($sel." OFFSET ".$offset." ROWS FETCH NEXT ".$size." ROWS ONLY");
	            $stmt->execute();
	           
	                            while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
	                            	$data[$i][0] = $row['MONTH_PP'];
	                                $data[$i][1] = $row['part_code'];
	                                $data[$i][2] = $row['part_no'];
	                                $data[$i][3] = $row['part_name'];
	                                $data[$i][4] = $row['lot_date'];
	                                $data[$i][5] = $row['QTY'];
	                                $i++;
	                     		}

	            
	            $stmt = $conn->prepare($sel);
	            $stmt->execute();
	                            $x = 0;
	                            while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
	                                $x++;
	                     		}
	                 


	$total = $x;
	$json_data = array(
	    "draw"            => intval( $_REQUEST['draw'] ), #
	    "recordsTotal"    =>  intval($total), #total number of records
	    "recordsFiltered" =>  intval($total), #Total number of filtered results after search. no search = number will be same for recordsTotal
	    "data"            => $data #fetched record data in multidimensional array
	);
	echo json_encode($json_data);
}

?>