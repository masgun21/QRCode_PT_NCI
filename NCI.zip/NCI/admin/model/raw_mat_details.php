<?php
if(isset($_GET['inv'])){
				$inventory = $_GET['inv'];
	            $i = 0;
	            $search = $_GET['search']['value'];
	            $offset = $_GET['start'];
	            $size = $_GET['length'];
	            $draw = intval($_GET['draw']);
	            $data = array();
	            include("../dbcon.php");

	            $sel = "SELECT "

	            
	            $stmt = $conn->prepare($sel." OFFSET ".$offset." ROWS FETCH NEXT ".$size." ROWS ONLY");
	            $stmt->execute();
	           
	                            while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
	                            	$data[$i][0] = $row['MONTH_PP'];
	                                $data[$i][1] = $row['part_code'];
	                                $data[$i][2] = $row['part_no'];
	                                $data[$i][3] = $row['part_name'];
	                                $data[$i][4] = $row['lot_date'];
	                                $data[$i][5] = $row['QTY'];
	                                $i++;
	                     		}

	            
	            $stmt = $conn->prepare($sel);
	            $stmt->execute();
	                            $x = 0;
	                            while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
	                                $x++;
	                     		}
	                 


	$total = $x;
	$json_data = array(
	    "draw"            => intval( $_REQUEST['draw'] ), #
	    "recordsTotal"    =>  intval($total), #total number of records
	    "recordsFiltered" =>  intval($total), #Total number of filtered results after search. no search = number will be same for recordsTotal
	    "data"            => $data #fetched record data in multidimensional array
	);
	echo json_encode($json_data);
}

?>