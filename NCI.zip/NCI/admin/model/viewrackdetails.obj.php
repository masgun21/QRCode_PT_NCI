<?php

	class ViewRackDetails
	{

		private $conn;

		public function __construct()
		{
			

			try {
				$this->conn = new PDO( "sqlsrv:server=".$GLOBALS["db_server_name"]." ; Database=".$GLOBALS["db_name"], "", "");  
				$this->conn->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
			} catch(Exception $e) {
				throw new Exception("SQL Server connection could not be established: ".$e->getMessage());
			}	
		}

		public function getRackByID( $rackID )
		{
			$sql = "SELECT TOP 1 RackID, PaletteID, LastUpdatedBy, LastUpdate_Pick, LastUpdate_Store, StoreDate, ProductionDate, BoxInPalette, QTY_PER_BOX, TotalQty, PartCode, PART_NO, PART_NAME FROM view_rackdetails WHERE RackID = ?";
			
			$datas = $this->conn->prepare($sql);
			$datas->execute(array($rackID));
			
			if ($data = $datas->fetch( PDO::FETCH_ASSOC )){ 
				$rack["RackID"] = $data["RackID"];
				$rack["PaletteID"] = $data["PaletteID"];
				$rack["LastUpdatedBy"] = $data["LastUpdatedBy"];
				$rack["LastUpdate_Pick"] = $data["LastUpdate_Pick"];
				$rack["LastUpdate_Store"] = $data["LastUpdate_Store"];
				$rack["StoreDate"] = $data["StoreDate"];
				$rack["ProductionDate"] = $data["ProductionDate"];
				$rack["BoxInPalette"] = $data["BoxInPalette"];
				$rack["QTY_PER_BOX"] = $data["QTY_PER_BOX"];
				$rack["TotalQty"] = $data["TotalQty"];
				$rack["PartCode"] = $data["PartCode"];
				$rack["PART_NO"] = $data["PART_NO"];
				$rack["PART_NAME"] = $data["PART_NAME"];

				return $rack;
			}
			return false;

		}

		public function getListByRackGroupID( $rackGroupID, $position )
		{
			$sql = "SELECT RackID, RackNumber FROM view_rackdetails WHERE RackGroupID = ? AND RackPosition = ? GROUP BY RackID,RackNumber ORDER BY RackNumber ASC";
			$datas = $this->conn->prepare($sql);
			$datas->execute(array($rackGroupID, $position));
			
			$rack = array();

			$i = 0;
			if ($data = $datas->fetch( PDO::FETCH_ASSOC )){ 
				$rack[$i]["RackID"] = $data["RackID"];
				$i++;
			}

			return $rack;

		}

		public function getRackByPaletteID( $paletteID )
		{
			$sql = "SELECT RackID, PaletteID, LastUpdatedBy, LastUpdate_Pick, LastUpdate_Store, StoreDate, ProductionDate, BoxInPalette, QTY_PER_BOX, TotalQty, PartCode, PART_NO, PART_NAME FROM view_rackdetails WHERE PaletteID = ? LIMIT 1";
			$datas = $this->conn->prepare($sql);
			$datas->execute(array($paletteID));

			if ($data = $datas->fetch( PDO::FETCH_ASSOC )){ 
				$rack["RackID"] = $data["RackID"];
				$rack["PaletteID"] = $data["PaletteID"];
				$rack["LastUpdatedBy"] = $data["LastUpdatedBy"];
				$rack["LastUpdate_Pick"] = $data["LastUpdate_Pick"];
				$rack["LastUpdate_Store"] = $data["LastUpdate_Store"];
				$rack["StoreDate"] = $data["StoreDate"];
				$rack["ProductionDate"] = $data["ProductionDate"];
				$rack["BoxInPalette"] = $data["BoxInPalette"];
				$rack["QTY_PER_BOX"] = $data["QTY_PER_BOX"];
				$rack["TotalQty"] = $data["TotalQty"];
				$rack["PartCode"] = $data["PartCode"];
				$rack["PART_NO"] = $data["PART_NO"];
				$rack["PART_NAME"] = $data["PART_NAME"];

				return $rack;
			}
			
			return false;

		}

	}
	
?>