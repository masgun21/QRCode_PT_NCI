<?php

	class PickList
	{

		private $conn;

		public function __construct()
		{
			$sessionId = session_id();
			
			if( strlen($sessionId) == 0)
				throw new Exception("No session has been started.\n<br />Please add `session_start();` initially in your file before any output.");

			try {
				$this->conn = new PDO( "sqlsrv:server=".$GLOBALS["db_server_name"]." ; Database=".$GLOBALS["db_name"], "", "");  
				$this->conn->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
			} catch(Exception $e) {
				throw new Exception("SQL Server connection could not be established: ".$e->getMessage());
			}
		}

		public function isExist( $RackID, $ProductionDate, $partCode )
		{

			$sql = "SELECT TOP 1 * FROM tbl_PickList WHERE RackID=? AND ProductionDate=? AND partCode=?";
			$datas = $this->conn->prepare($sql);
			$datas->execute(array($RackID, $ProductionDate, $partCode));

			if ($data = $datas->fetch( PDO::FETCH_ASSOC )){
				return true;
			} else {
				return false;
			}
		}

		public function hasPPU($RackID)
		{

			$sql = "SELECT TOP 1 * FROM tbl_PickList WHERE RackID=? AND PPUCount > 0";
			$datas = $this->conn->prepare($sql);
			$datas->execute(array($RackID));

			if ($data = $datas->fetch( PDO::FETCH_ASSOC )){
				return true;
			} else {
				return false;
			}

		}

		public function updatePickList( $RackID, $ProductionDate, $partCode, $ppuCount )
		{
			$sql = "UPDATE tbl_PickList SET PPUCount=? WHERE RackID=? AND ProductionDate=? AND partCode=?";
			$datas = $this->conn->prepare($sql);
			$datas->execute(array($ppuCount, $RackID, $ProductionDate, $partCode));
			return true;
		}

		public function insertPickList( $RackID, $ProductionDate, $partCode, $ppuCount )
		{
			$sql = "INSERT INTO tbl_PickList (RackID, PartCode, ProductionDate, PPUCount) VALUES (?,?,?,?)";
			$datas = $this->conn->prepare($sql);
			$datas->execute(array($RackID, $partCode, $ProductionDate, $ppuCount));
			return true;
		}

	}
	
?>