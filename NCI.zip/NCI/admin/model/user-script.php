<?php
require('../dbcon.php');

header('Content-Type: application/json');
$response = array();


if(isset($_POST['data'])){
	$json = json_decode($_POST['data']);
	if($json->operation == "create-user"){
		$user_id = generate();
		$username = $json->username;
		$password = $json->password;
		$role = $json->role;

		if(!check_user($username)){
			create_user($user_id, $username, $password, $role);
			$response['success'] = true;
    		$response['message'] = "Success";
		} else {
			$response['success'] = false;
	    	$response['message'] = "UserID already exists.";
		}
	} else if($json->operation == "delete-user"){
		delete_user($json->username);
		$response['success'] = true;
		$response['message'] = "User Deleted";
	} else if($json->operation == "update-user"){
		update_user($json->username, md5($json->password), $json->role);
		$response['success'] = true;
		$response['message'] = "User Updated";
	}

	echo json_encode($response);


} else {
	$response['success'] = false;
}




function check_user($username){
	require('../dbcon.php');
	$sql = "SELECT TOP 1 username FROM tbl_Users WHERE username=?";
	$stmt = $conn->prepare($sql);
	$stmt->execute([$username]);
	if($data = $stmt->fetch(PDO::FETCH_ASSOC)){
		return true;
	} else {
		return false;
	}
}


function create_user($user_id, $username, $password, $role){
	require('../dbcon.php');
	$sql = "INSERT INTO tbl_Users (user_id, username, password, role) VALUES (?,?,?,?)";
	$stmt = $conn->prepare($sql);
	$stmt->execute([$user_id, $username, md5($password), $role]);
}

function delete_user($username){
	require('../dbcon.php');
	$sql = "DELETE FROM tbl_Users WHERE username=?";
	$stmt = $conn->prepare($sql);
	$stmt->execute([$username]);
}

function update_user($username, $password, $role){
	require('../dbcon.php');
	$sql = "UPDATE tbl_Users SET [password]=?, [role]=? WHERE [username]=?";
	$stmt = $conn->prepare($sql);
	$stmt->execute([$password, $role, $username]);
}
function generate($length = 5){
	$characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
	$charactersLength = strlen($characters);
	$randomString = '';
	for ($i = 0; $i < $length; $i++) {
	  $randomString .= $characters[rand(0, $charactersLength - 1)];
	}
	return $randomString;
}


?>