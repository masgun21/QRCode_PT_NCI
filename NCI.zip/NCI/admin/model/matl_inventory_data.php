<?php
if(isset($_GET['inv'])){
				$inventory = $_GET['inv'];
	            $i = 0;
	            $search = $_GET['search']['value'];
	            $offset = $_GET['start'];
	            $size = $_GET['length'];
	            $draw = intval($_GET['draw']);
	            $data = array();
	            include("../dbcon.php");

	            if($inventory == "crsng"){
	            	$sel = "SELECT rack_id, code, type, grade, color, SUM(weight_kg) AS wkg FROM tbl_inventory_matl WHERE DOCNUM IS NULL AND rack_id LIKE '%C-%' AND (LOWER(rack_id) LIKE '%".$search."%' OR LOWER(code) LIKE '%".$search."%') GROUP BY rack_id, code, type, grade, color ORDER BY rack_id ASC";

	            } else if($inventory == "virgin"){
	            	$sel = "SELECT rack_id, code, type, grade, color, SUM(weight_kg) AS wkg FROM tbl_inventory_matl WHERE rack_id NOT LIKE '%C-%' AND DOCNUM IS NULL AND (LOWER(rack_id) LIKE '%".$search."%' OR LOWER(code) like '%".$search."%') GROUP BY rack_id, code, type, grade, color ORDER BY rack_id ASC";

	            } 

	            
	            $stmt = $conn->prepare($sel." OFFSET ".$offset." ROWS FETCH NEXT ".$size." ROWS ONLY");
	            $stmt->execute();
	           
	                            while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
	                            	$data[$i][0] = $row['rack_id'];
	                                $data[$i][1] = $row['code'];
	                                $data[$i][2] = $row['type'];
	                                $data[$i][3] = $row['grade'];
	                                $data[$i][4] = $row['color'];
	                                $data[$i][5] = $row['wkg'];
	                                $i++;
	                     		}

	            
	            $stmt = $conn->prepare($sel);
	            $stmt->execute();
	                            $x = 0;
	                            while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
	                                $x++;
	                     		}
	                 


	$total = $x;
	$json_data = array(
	    "draw"            => intval( $_REQUEST['draw'] ), #
	    "recordsTotal"    =>  intval($total), #total number of records
	    "recordsFiltered" =>  intval($total), #Total number of filtered results after search. no search = number will be same for recordsTotal
	    "data"            => $data #fetched record data in multidimensional array
	);
	echo json_encode($json_data);
}

?>