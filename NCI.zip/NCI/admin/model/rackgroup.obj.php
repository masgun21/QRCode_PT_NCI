<?php

	class RackGroup
	{

		private $conn;

		public function __construct()
		{
			try {
				$this->conn = new PDO( "sqlsrv:server=".$GLOBALS["db_server_name"]." ; Database=".$GLOBALS["db_name"], "", "");  
				$this->conn->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
			} catch(Exception $e) {
				throw new Exception("SQL Server connection could not be established: ".$e->getMessage());
			}
		}

		public function getAll()
		{
			$sql = "SELECT RackGroupID, SerialNumber FROM view_rackgroup ORDER BY SerialNumber ASC";
			$datas = $this->conn->prepare($sql);
			$datas->execute(array($paletteID));
			
			$rackGroup = array();

			$i = 0;
			while ($data = $datas->fetch( PDO::FETCH_ASSOC )){ 
				$rackGroup[$i]["RackGroupID"] = $data["RackGroupID"];
				$rackGroup[$i]["SerialNumber"] = $data["SerialNumber"];
				$i++;
			}

			return $rackGroup;

		}

		public function getByID($rackGroupID)
		{
			$sql = "SELECT RackGroupID, SerialNumber FROM view_rackgroup WHERE RackGroupID = ? ORDER BY SerialNumber ASC";
			$datas = $this->conn->prepare($sql);
			$datas->execute(array($rackGroupID));
			
			if ($data = $datas->fetch( PDO::FETCH_ASSOC )){ 
				$rackGroup["RackGroupID"] = $data["RackGroupID"];
				$rackGroup["SerialNumber"] = $data["SerialNumber"];
				return $rackGroup;
			}
			return false;
		}

		public function getFirst()
		{
			$sql = "SELECT TOP 1 RackGroupID, SerialNumber FROM view_rackgroup ORDER BY SerialNumber ASC";
			$datas = $this->conn->prepare($sql);
			$datas->execute();

			if ($data = $datas->fetch( PDO::FETCH_ASSOC )){ 
				$rackGroup["RackGroupID"] = $data["RackGroupID"];
				$rackGroup["SerialNumber"] = $data["SerialNumber"];
				return $rackGroup;
			}
			return false;

		}

		public function getPrev($serialNumber)
		{
			$sql = "SELECT TOP 1 RackGroupID, SerialNumber FROM view_rackgroup WHERE SerialNumber < ? ORDER BY SerialNumber DESC";
			$datas = $this->conn->prepare($sql);
			$datas->execute(array($serialNumber));
			
			if ($data = $datas->fetch( PDO::FETCH_ASSOC )){ 
				$rackGroup["RackGroupID"] = $data["RackGroupID"];
				$rackGroup["SerialNumber"] = $data["SerialNumber"];
				return $rackGroup;
			}
			return false;
		}

		public function getNext($serialNumber)
		{
			$sql = "SELECT TOP 1 RackGroupID, SerialNumber FROM view_rackgroup WHERE SerialNumber > ? ORDER BY SerialNumber ASC";
			$datas = $this->conn->prepare($sql);
			$datas->execute(array($serialNumber));
			
			if ($data = $datas->fetch( PDO::FETCH_ASSOC )){ 
				$rackGroup["RackGroupID"] = $data["RackGroupID"];
				$rackGroup["SerialNumber"] = $data["SerialNumber"];
				return $rackGroup;
			}
			return false;
		}

	}
	
?>