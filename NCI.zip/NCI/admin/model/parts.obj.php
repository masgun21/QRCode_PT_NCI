<?php

	class Part
	{

		private $conn;

		public function __construct()
		{
			$sessionId = session_id();
			
			if( strlen($sessionId) == 0)
				throw new Exception("No session has been started.\n<br />Please add `session_start();` initially in your file before any output.");

			try {
				$this->conn = new PDO( "sqlsrv:server=".$GLOBALS["db_server_name"]." ; Database=".$GLOBALS["db_name"], "", "");  
				$this->conn->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
			} catch(Exception $e) {
				throw new Exception("SQL Server connection could not be established: ".$e->getMessage());
			}
		}

		public function getPartByPartCode( $partCode )
		{
			$sql = "SELECT TOP 1 PART_CODE, PART_NO, PART_NAME, QTY_PER_BOX FROM tbl_Parts WHERE PART_CODE = ?";
			$datas = $this->conn->prepare($sql);
			$datas->execute(array($partCode));

			if ($data = $datas->fetch( PDO::FETCH_ASSOC )){
				$part["PART_CODE"] = $data["PART_CODE"];
				$part["PART_NO"] = $data["PART_NO"];
				$part["PART_NAME"] = $data["PART_NAME"];
				$part["QTY_PER_BOX"] = $data["QTY_PER_BOX"];

				return $part;
			}

			return false;

		}

	}
	
?>