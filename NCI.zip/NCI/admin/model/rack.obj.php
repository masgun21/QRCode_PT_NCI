<?php

	class Rack
	{

		private $conn;

		public function __construct()
		{
			try {
				$this->conn = new PDO( "sqlsrv:server=".$GLOBALS["db_server_name"]." ; Database=".$GLOBALS["db_name"], "", "");  
				$this->conn->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
			} catch(Exception $e) {
				throw new Exception("SQL Server connection could not be established: ".$e->getMessage());
			}
		}

		public function getRackByPaletteID( $paletteID )
		{
			$sql = "SELECT RackID, PaletteID, LastUpdatedBy, LastUpdate_Pick, LastUpdate_Store FROM tbl_Rack WHERE PaletteID = ? LIMIT 1";
			$datas = $this->conn->prepare($sql);
			$datas->execute(array($paletteID));

			if ($data = $datas->fetch( PDO::FETCH_ASSOC )){ 
				$rack["RackID"] = $data["RackID"];
				$rack["PaletteID"] = $data["PaletteID"];
				$rack["LastUpdatedBy"] = $data["LastUpdatedBy"];
				$rack["LastUpdate_Pick"] = $data["LastUpdate_Pick"];
				$rack["LastUpdate_Store"] = $data["LastUpdate_Store"];

				return $rack;
			}
			return false;

		}

		public function getListByRackGroupID( $rackGroupID, $position )
		{
			$sql = "SELECT RackID, PaletteID, LastUpdatedBy, LastUpdate_Pick, LastUpdate_Store FROM tbl_Rack WHERE RackGroupID = ? AND RackPosition = ? ORDER BY RackID ASC";
			$datas = $this->conn->prepare($sql);
			$datas->execute(array($rackGroupID, $position));
			
			$rack = array();

			$i = 0;
			if ($data = $datas->fetch( PDO::FETCH_ASSOC )){ 
				$rack[$i]["RackID"] = $data["RackID"];
				$rack[$i]["PaletteID"] = $data["PaletteID"];
				$rack[$i]["LastUpdatedBy"] = $data["LastUpdatedBy"];
				$rack[$i]["LastUpdate_Pick"] = $data["LastUpdate_Pick"];
				$rack[$i]["LastUpdate_Store"] = $data["LastUpdate_Store"];
				$i++;
			}
			
			return $rack;

		}

		public function getSingleRack( $rackID)
		{

			$sql = "SELECT TOP 1 RackID, PaletteID, CurrentQTY, MaxQTY, OccupancyStatus FROM tbl_rack WHERE RackID=?";

			$datas = $this->conn->prepare($sql);
			$datas->execute(array($rackID));

			if ($data = $datas->fetch( PDO::FETCH_ASSOC )){ 
				$rack["RackID"] = $data["RackID"];
				$rack["PaletteID"] = $data["PaletteID"];
				$rack["MaxQTY"] = $data["MaxQTY"];
				$rack["CurrentQTY"] = $data["CurrentQTY"];
				$rack["OccupancyStatus"] = $data["OccupancyStatus"];
				return $rack;
			}
			return false;

		}


		public function createRack( $rackID )
		{
			$sql = "INSERT INTO tbl_Rack (RackID) VALUES (?)";
			$datas = $this->conn->prepare($sql);
			return $datas->execute(array($rackID));
		}

		public function deleteRack( $rackID )
		{
			$sql = "DELETE FROM tbl_Rack WHERE RackID=?";
			$datas = $this->conn->prepare($sql);
			return $datas->execute(array($rackID));
		}

		public function updateRack( $rackID, $oldRackID )
		{
			$sql = "UPDATE tbl_Rack SET RackID = ? WHERE RackID= ? ";
			$datas = $this->conn->prepare($sql);
			return $datas->execute(array($rackID, $oldRackID));
		}

		public function getListDT($search, $offset, $size)
		{
			$sql = "SELECT RackID, PartCode, PART_NO, PART_NAME, ProductionDate, CurrentBoxQty, QTY_PER_BOX, ItemQuantity, PPUCount FROM view_rack WHERE LOWER(PART_NO) LIKE '%".strtolower($search)."%' OR LOWER(RackID) LIKE '%".strtolower($search)."%' OR LOWER(PartCode) LIKE '%".strtolower($search)."%' ORDER BY ProductionDate ASC OFFSET ".$offset." ROWS FETCH NEXT ".$size." ROWS ONLY";
			$datas = $this->conn->prepare($sql);
			$datas->execute();
			
			$rack = array();

			$i = 0;
			while ($data = $datas->fetch( PDO::FETCH_ASSOC )){ 
				$rack[$i][0] = $data["RackID"];
				$rack[$i][1] = $data["RackID"];
				$rack[$i][2] = $data["PartCode"];
				$rack[$i][3] = $data["PART_NO"];
				$rack[$i][4] = $data["PART_NAME"];
				$rack[$i][5] = $data["ProductionDate"];
				$rack[$i][6] = $data["CurrentBoxQty"];
				$rack[$i][7] = $data["QTY_PER_BOX"];
				$rack[$i][8] = $data["ItemQuantity"];
				$rack[$i][9] = $data["PPUCount"];
				$i++;
			}
			
			return $rack;

		}

		public function getSizeDT($search)
		{
			$sql = "SELECT RackID, PartCode, PART_NO, PART_NAME, ProductionDate, CurrentBoxQty, QTY_PER_BOX, ItemQuantity, PPUCount FROM view_rack WHERE LOWER(PART_NO) LIKE '%".strtolower($search)."%' OR LOWER(RackID) LIKE '%".strtolower($search)."%' OR LOWER(PartCode) LIKE '%".strtolower($search)."%' ORDER BY ProductionDate ASC";
			$datas = $this->conn->prepare($sql);
			$datas->execute();
			
			$rack = array();

			$i = 0;
			while ($data = $datas->fetch( PDO::FETCH_ASSOC )){ 
				$i++;
			}
			
			return $i;

		}

		public function getDetailListDT($RackID, $search, $offset, $size)
		{

			$sql = "SELECT TOP 1 Kanban_ID, lot_no, rcv_date, code, type, grade, color FROM tbl_inventory_matl WHERE rack_id='".$RackID."'ORDER BY Kanban_ID ASC OFFSET ".$offset." ROWS FETCH NEXT ".$size." ROWS ONLY";
			$datas = $this->conn->prepare($sql);
			$datas->execute();
			
			$rack = array();

			$i = 0;
			while ($data = $datas->fetch( PDO::FETCH_ASSOC )){ 
				$rack[$i][0] = $data["Kanban_ID"];
				$rack[$i][1] = $data["lot_no"];
				$rack[$i][2] = $data["rcv_date"];
				$rack[$i][3] = $data["code"];
				$rack[$i][4] = $data["type"];
				$rack[$i][5] = $data["grade"];
				$rack[$i][6] = $data["color"];
				$i++;
			}
			
			return $rack;

		}

		public function getDetailSizeDT($RackID, $search)
		{
			
			$sql = "SELECT TOP 1 Kanban_ID, lot_no, rcv_date, code, type, grade, color FROM tbl_inventory_matl WHERE rack_id='".$RackID."'ORDER BY Kanban_ID ASC";
			$datas = $this->conn->prepare($sql);
			$datas->execute();
			
			$rack = array();

			$i = 0;
			while ($data = $datas->fetch( PDO::FETCH_ASSOC )){ 
				$i++;
			}
			
			return $i;

		}

	}
	
?>