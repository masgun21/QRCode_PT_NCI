<?php

	class User
	{

		private $conn;

		public function __construct()
		{
			

			try {
				$this->conn = new PDO( "sqlsrv:server=".$GLOBALS["db_server_name"]." ; Database=".$GLOBALS["db_name"], $GLOBALS["uname"], $GLOBALS["pword"]);  
				$this->conn->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
			} catch(Exception $e) {
				throw new Exception("SQL Server connection could not be established: ".$e->getMessage());
			}

			
		}

		public function createUser($user_id, $username, $password, $role )
		{
			$sql = "INSERT INTO tbl_Users (user_id, username, password, role) VALUES (?,?,?,?)";
			$datas = $this->conn->prepare($sql);
			$datas->execute([$user_id, $username, $password, $role]);	
			return true;
		}

		public function loginUser( $username, $password )
		{
			$sql = "SELECT TOP 1 UserID, UserRole FROM tbl_Users WHERE UserID='".$username."' AND Password = CONVERT(VARCHAR(32), HashBytes('MD5', '".$password."'), 2)";
			$datas = $this->conn->prepare($sql);
			$datas->execute();

			if ($data = $datas->fetch( PDO::FETCH_ASSOC )){
				$_SESSION[$this->sessionName]["userId"] = $data["UserID"];
				$_SESSION[$this->sessionName]["role"] = $data["UserRole"];
				$this->logged_in = true;
				return true;
			}

			return false;
		}

		public function logoutUser()
		{
			if( isset($_SESSION[$this->sessionName]) )
				unset($_SESSION[$this->sessionName]);

			$this->logged_in = false;
		}

		public function setPassword( $password, $userId = null )
		{
			if( $userId == null )
				$userId = $_SESSION[$this->sessionName]["userId"];

			$sql = "UPDATE tbl_Users SET Password=CONVERT(VARCHAR(32), HashBytes('MD5', '".$password."'), 2) WHERE UserID='".$userId."'";
			$datas = $this->conn->prepare($sql);
			$datas->execute();
		}

		public function getUsers()
		{
			
			$sql = "SELECT DISTINCT UserID FROM tbl_Users ORDER BY UserID ASC";

			$datas = $this->conn->prepare($sql);
			$datas->execute();

			$users = array();

			$i = 0;
			while ($data = $datas->fetch( PDO::FETCH_ASSOC )){
				$users[$i]["userId"] = $data["UserID"];
				$i++;
			}
			
			return $users;

		}

		public function getSingleUser( $userId )
		{

			$sql = "SELECT TOP 1 user_id FROM tbl_Users WHERE user_id='".$userId."'";
			$datas = $this->conn->prepare($sql);
			$datas->execute();
			
			if ($data = $datas->fetch( PDO::FETCH_ASSOC )){
				$user["userId"] = $data["user_id"];
				return $user;
			}
			return false;

		}

		public function deleteUser( $userId )
		{
			$sql = "DELETE FROM tbl_Users WHERE user_id='".$userId."'";
			$datas = $this->conn->prepare($sql);
			$datas->execute();

			return;
		}

		private function _validateUser()
		{
			if( !isset($_SESSION[$this->sessionName]["userId"]) )
				return;

			if( !$this->_validateUserId() )
				return;

			$this->logged_in = true;
		}

		private function _validateUserId()
		{
			$userId = $_SESSION[$this->sessionName]["userId"];

			$sql = "SELECT TOP 1 UserID FROM tbl_Users WHERE UserID='".$userId."'";
			$datas = $this->conn->prepare($sql);
			$datas->execute();

			if ($data = $datas->fetch( PDO::FETCH_ASSOC )){
				return true;
			}

			$this->logoutUser();

			return false;
		}

		public function getUserByIDPass( $userId, $password )
		{
			if( $userId == null )
				$userId = $_SESSION[$this->sessionName]["userId"];

			$sql = "SELECT TOP 1 UserID FROM tbl_Users WHERE UserID='".$userId."' AND Password=CONVERT(VARCHAR(32), HashBytes('MD5', '".$password."'), 2)";
			$datas = $this->conn->prepare($sql);
			$datas->execute();
			
			if ($data = $datas->fetch( PDO::FETCH_ASSOC )){
				$user["userId"] = $data["UserID"];
				return $user;
			}
			return false;
		}

		public function updateUser( $userId, $password, $role )
		{
			$sql = "UPDATE tbl_Users SET Password = CONVERT(VARCHAR(32), HashBytes('MD5', '".$password."'), 2), UserRole = '".$role."' WHERE UserID='".$userId."'";
			$datas = $this->conn->prepare($sql);
			$datas->execute();
			return;
		}

		public function getListDT($search, $offset, $size)
		{
			$sql = "SELECT user_id, username, password, role FROM tbl_Users WHERE LOWER(username) LIKE '%".strtolower($search)."%' ORDER BY username ASC OFFSET ".$offset." ROWS FETCH NEXT ".$size." ROWS ONLY";
			$datas = $this->conn->prepare($sql);
			$datas->execute();
			
			$rack = array();

			$i = 0;
			while ($data = $datas->fetch( PDO::FETCH_ASSOC )){ 
				$rack[$i][0] = $data["username"];
				$rack[$i][1] = $data["role"];
				$rack[$i][2] = $data["username"];
				$rack[$i][3] = $data["username"];
				$rack[$i][4] = $data['user_id']."*".$data['username']."*".$data['password']."*".$data['role'];
				$i++;
			}
			
			return $rack;

		}

		public function getSizeDT($search)
		{
			$sql = "SELECT user_id, username, password, role FROM tbl_Users WHERE LOWER(username) LIKE '%".strtolower($search)."%' ORDER BY username ASC";
			$datas = $this->conn->prepare($sql);
			$datas->execute();
			
			$rack = array();

			$i = 0;
			while ($data = $datas->fetch( PDO::FETCH_ASSOC )){ 
				$i++;
			}
			
			return $i;

		}

		public function generate($length = 5) {
	      $characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
	      $charactersLength = strlen($characters);
	      $randomString = '';
	      for ($i = 0; $i < $length; $i++) {
	          $randomString .= $characters[rand(0, $charactersLength - 1)];
	      }
	      return $randomString;
    	}
	}
	
?>