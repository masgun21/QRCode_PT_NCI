<?php

	class BoxInfo
	{

		private $conn;

		public function __construct()
		{
			$sessionId = session_id();
			
			if( strlen($sessionId) == 0)
				throw new Exception("No session has been started.\n<br />Please add `session_start();` initially in your file before any output.");
			try {
				$this->conn = new PDO( "sqlsrv:server=".$GLOBALS["db_server_name"]." ; Database=".$GLOBALS["db_name"], "", "");  
				$this->conn->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
			} catch(Exception $e) {
				throw new Exception("SQL Server connection could not be established: ".$e->getMessage());
			}	
		}

		public function getBoxInfoByPartCode( $partCode )
		{

			$sql = "SELECT TOP 1 BoxID, PaletteID, CreatedBy, PrintDate, StoreDate, PickDate, ProductionDate FROM tbl_BoxInfo WHERE PaletteID LIKE '%".$partCode."%' AND PickDate IS NULL ORDER BY ProductionDate, StoreDate ASC";
			$datas = $this->conn->prepare($sql);
			$datas->execute();

			if ($data = $datas->fetch( PDO::FETCH_ASSOC )){ 
				$boxInfo["BoxID"] = $data["BoxID"];
				$boxInfo["PaletteID"] = $data["PaletteID"];
				$boxInfo["CreatedBy"] = $data["CreatedBy"];
				$boxInfo["PrintDate"] = $data["PrintDate"];
				$boxInfo["StoreDate"] = $data["StoreDate"];
				$boxInfo["ProductionDate"] = $data["ProductionDate"];

				return $boxInfo;
			}
			return false;
		}

		public function getListBoxInfoByPartCode( $partCode )
		{
			$boxInfo = array();
			$i = 0;

			$sql = "SELECT BoxID, PaletteID, CreatedBy, PrintDate, StoreDate, PickDate, ProductionDate FROM tbl_BoxInfo WHERE PaletteID LIKE '%".$partCode."%' AND PickDate IS NULL ORDER BY ProductionDate, StoreDate ASC";
			$datas = $this->conn->prepare($sql);
			$datas->execute();
			while ($data = $datas->fetch( PDO::FETCH_ASSOC )){ 
				$boxInfo[$i]["BoxID"] = $data["BoxID"];
				$boxInfo[$i]["PaletteID"] = $data["PaletteID"];
				$boxInfo[$i]["CreatedBy"] = $data["CreatedBy"];
				$boxInfo[$i]["PrintDate"] = $data["PrintDate"];
				$boxInfo[$i]["StoreDate"] = $data["StoreDate"];
				$boxInfo[$i]["ProductionDate"] = $data["ProductionDate"];
				$i++;
			}

			return $boxInfo;

		}

		public function updateBoxInfo( $kanbanId, $checked, $ppuCount )
		{
			$sql = "UPDATE tbl_BoxInfo SET Status=?,PPUCount=? WHERE KanbanID=? LIMIT 1";
			$status = 'N/A';
			if ($checked) {
				$status = 'PPU';
			}

			$datas = $this->conn->prepare($sql);
			return $datas->execute(array($status, $ppuCount, $kanbanId));
		}

		public function hasPPU( $paletteID )
		{
			$sql = "SELECT * FROM tbl_BoxInfo WHERE PaletteID = ? AND PickDate IS NULL AND Status = ?";
			if( !$this->stmt = $this->mysqli->prepare($sql) )
				throw new Exception("MySQL Prepare statement failed: ".$this->mysqli->error);

			$status = 'PPU';

			$datas = $this->conn->prepare($sql);
			$datas->execute(array($paletteID, $status));

			if ($data = $datas->fetch( PDO::FETCH_ASSOC )){ 
				return false;
			} else {
				return true;
			}

		}

	}
	
?>