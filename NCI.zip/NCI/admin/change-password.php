<?php

    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }
    require_once(dirname(__FILE__)."/config/su.inc.php");

    $User = new User();
    if( !$User->logged_in )
    {
        header("Location: login.php");
        exit;
    }
?>
<!doctype html>
<html lang="en">
<head>
    <title>Daiho</title>
    <?php include 'include/header.php';?>
</head>
<body>

<div class="wrapper">
    <?php $menu = -1;?>
    <?php include 'include/navigation.php';?>

    <div class="main-panel">
        <nav class="navbar navbar-default navbar-fixed">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation-example-2">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#"></a>
                </div>
                <?php include 'include/navbar.php';?>
            </div>
        </nav>

        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Change Password</h4>
                                <p class="category"></p>
                            </div>
                            <div class="content">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="content">
                                            <form role="form" class="form-horizontal">
                                                <fieldset>
                                                    <div class="form-group">
                                                        <label class="control-label col-sm-4">Old Password</label>
                                                        <div class="col-sm-8">
                                                            <input class="form-control" placeholder="Old Password" name="old-password" id="old-password" type="password" value="">
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="control-label col-sm-4">New Password</label>
                                                        <div class="col-sm-8">
                                                            <input class="form-control" placeholder="Password" name="new-password" id="new-password" type="password" value="">
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="control-label col-sm-4">Retype New Password</label>
                                                        <div class="col-sm-8">
                                                            <input class="form-control" placeholder="Password" name="re-new-password" id="re-new-password" type="password" value="">
                                                        </div>
                                                    </div>
                                                </fieldset>
                                                <button type="button" class="btn btn-fill btn-danger pull-right" id="cp-save-btn">Save</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php include 'include/content-footer.php';?>
    </div>
</div>
</body>
<?php include 'include/footer.php';?>
<script type="text/javascript">
    $(document).ready(function(){
        $("#cp-save-btn").click(function(){
            var data = Object();
            data.operation = "change-password";
            data.old_password = $("#old-password").val();
            data.new_password = $("#new-password").val();
            data.renew_password = $("#re-new-password").val();

            if (data.old_password.length == 0){
                alert("Old password can't be null.");
                return;
            }

            if (data.new_password.length == 0){
                alert("New password can't be null.");
                return;
            }

            if (data.renew_password.length == 0){
                alert("Retype New password can't be null.");
                return;
            }

            if (data.new_password != data.renew_password){
                alert("New Password and Retype New password are mismatch.");
                return;   
            }

            var request = $.ajax({
                url: "api/user.api.php",
                dataType:'json',
                contentType: "application/json",
                type: 'POST',
                data: JSON.stringify(data)
            });
            request.always(function(){
                
            });
            request.done(function(response){
                if (response.success) {
                    showNotification('top', 'center', 'info', "Update user successfull.");
                } else {
                    showNotification('top', 'center', 'danger', response.message);
                }
            });
            request.fail(function(jqXHR,textStatus){
                if(textStatus=='timeout'){
                    console.log('timeout');
                } else {
                    console.log('error');
                }
            });
        });
    });
</script>
</html>

