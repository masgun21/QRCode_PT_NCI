<?php

	$path = dirname(__FILE__);

	include($path."/config.inc.php");
	include($path."/../model/boxInfo.obj.php");

?>