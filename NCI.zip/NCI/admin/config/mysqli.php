<?php
	$path = dirname(__FILE__);

	include($path."/config.inc.php");
	
	$mysqli = new mysqli($GLOBALS["mysql_hostname"], $GLOBALS["mysql_username"], $GLOBALS["mysql_password"], $GLOBALS["mysql_database"], $GLOBALS["mysql_port"]);
?>