<?php
    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }
    require_once(dirname(__FILE__)."/config/su.inc.php");

    $User = new User();
    if( !$User->logged_in )
    {
        header("Location: login.php");
        exit;
    }
?>
<!doctype html>
<html lang="en">
<head>
    <title>Daiho-BIS</title>
    <?php include 'include/header.php';?>
</head>
<body>

<div class="modal fade" id="createUserModal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="myModalLabel">Create User</h4>
            </div>
        <div class="modal-body">
            <form role="form" class="form-horizontal">
                <fieldset>
                    <div class="form-group">
                        <label class="control-label col-sm-2">Username</label>
                        <div class="col-sm-10">
                            <input class="form-control" placeholder="Username" name="username" id="cr-username" autofocus>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-2">Password</label>
                        <div class="col-sm-10">
                            <input class="form-control" placeholder="Password" name="password" id="cr-password" type="password" value="">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-2">Role</label>
                        <div class="col-sm-10">
                            <select id="cr-role" name="cr-role" class="form-control">
                                <option value="ADMIN">ADMIN</option>
								<option value="OPERATOR" selected>OPERATOR</option>
                                <option value="STAFF">STAFF</option>
                            </select> 
                        </div>
                    </div>
                </fieldset>
            </form>
        </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-fill btn-warning" data-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-fill btn-danger" id="create-btn">Create</button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="updateUserModal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="myModalLabel">Update User</h4>
            </div>
        <div class="modal-body">
            <form role="form" class="form-horizontal">
                <fieldset>
                    <div class="form-group">
                        <label class="control-label col-sm-2">Username</label>
                        <div class="col-sm-10">
                            <input class="form-control" placeholder="Username" name="username" id="up-username" disabled="disabled">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-2">Password</label>
                        <div class="col-sm-10">
                            <input class="form-control" placeholder="Password" name="password" id="up-password" type="password" value="">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-2">Role</label>
                        <div class="col-sm-10">
                            <select id= "up-role" name="up-role" class="form-control">
								<option value="ADMIN">ADMIN</option>
                                <option value="OPERATOR">OPERATOR</option>
                                <option value="STAFF">STAFF</option>
                            </select> 
                        </div>
                    </div>
                </fieldset>
            </form>
        </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-fill btn-warning" data-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-fill btn-danger" id="save-btn">Save</button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="deleteUserModal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="myModalLabel">Delete User</h4>
            </div>
        <div class="modal-body">
            <p>Are you sure wants to delete user <strong><span id="deleteUserId"></span></strong>?</p>
            <input type="hidden" name="de-username" id="de-username" value="">
        </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-fill btn-warning" data-dismiss="modal">No</button>
                <button type="button" class="btn btn-fill btn-danger" id="yes-btn">Yes</button>
            </div>
        </div>
    </div>
</div>

<div class="wrapper">
    <?php $menu = 4;?>
    <?php include 'include/navigation.php';?>

    <div class="main-panel">
        <nav class="navbar navbar-default navbar-fixed">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation-example-2">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#"></a>
                </div>
                <?php include 'include/navbar.php';?>
            </div>
        </nav>

		<div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">User Management</h4>
                                <p class="category">List of registered users</p>
                            </div>
                            <div class="content">
                                <div class="row">
                                    <div class="col-md-12">
                                        <button type="button" class="btn btn-fill btn-danger" onclick="showCreateModal();">
                                            Add User
                                        </button>
                                        <div class="content table-responsive table-full-width">
                                            <table id="table" class="table table-hover table-striped">
                                                <thead>
                                                    <tr>
                                                        <th>User ID</th>
                                                        <th>Role</th>
                                                        <th>Edit</th>
                                                        <th>Delete</th>
                                                    </tr>
                                                </thead>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php include 'include/content-footer.php';?>
    </div>
</div>
</body>
<?php include 'include/footer.php';?>
<script type="text/javascript">
    $(document).ready(function() {
        $('#table').DataTable( {
            "processing": true,
            "serverSide": true,
            "ajax": "api/user.php",
            "columnDefs": [
                {
                    "render": function ( data, type, row ) {
                        var html = '<button type="button" onClick="showUpdateModal(\''+row[0]+'\',\''+row[1]+'\');" class="hand btn btn-icon btn-fill waves-effect waves-light btn-warning btn-xs"><i class="pe-7s-pen"></i></span>';
                        return html;
                    },
                    "targets": 2
                },
                {
                    "render": function ( data, type, row ) {
                        var html = '<button type="button" onClick="showDeleteModal(\''+row[0]+'\');" class="hand btn btn-icon btn-fill waves-effect waves-light btn-danger btn-xs"><i class="pe-7s-trash"></i></span>';
                        return html;
                    },
                    "targets": 3
                }
            ]
        } );

        $("#create-btn").click(function(){
            var data = Object();
            data.operation = "create-user";
            data.user_id = $("#cr-username").val();
            data.password = $("#cr-password").val();
            data.role = $("#cr-role").val();

            if (data.user_id.length == 0){
                alert("UserId can't be null.");
                return;
            }

            if (data.password.length == 0){
                alert("Password can't be null.");
                return;
            }

            var request = $.ajax({
                url: "api/user.api.php",
                dataType:'json',
                contentType: "application/json",
                type: 'POST',
                data: JSON.stringify(data)
            });
            request.always(function(){
                $('#createUserModal').modal('hide');
                $('#table').DataTable().ajax.reload();
            });
            request.done(function(response){
                if (response.success) {
                    showNotification('top', 'center', 'info', "Create user successfull.");
                } else {
                    showNotification('top', 'center', 'danger', response.message);
                }
            });
            request.fail(function(jqXHR,textStatus){
                if(textStatus=='timeout'){
                    console.log('timeout');
                } else {
                    console.log('error');
                }
            });
        });

        $("#save-btn").click(function(){
            var data = Object();
            data.operation = "update-user";
            data.user_id = $("#up-username").val();
            data.password = $("#up-password").val();
            data.role = $("#up-role").val();

            if (data.user_id.length == 0){
                alert("UserId can't be null.");
                return;
            }

            if (data.password.length == 0){
                alert("Password can't be null.");
                return;
            }

            var request = $.ajax({
                url: "api/user.api.php",
                dataType:'json',
                contentType: "application/json",
                type: 'POST',
                data: JSON.stringify(data)
            });
            request.always(function(){
                $('#updateUserModal').modal('hide');
                $('#table').DataTable().ajax.reload();
            });
            request.done(function(response){
                if (response.success) {
                    showNotification('top', 'center', 'info', "Update user successfull.");
                } else {
                    showNotification('top', 'center', 'danger', response.message);
                }
            });
            request.fail(function(jqXHR,textStatus){
                if(textStatus=='timeout'){
                    console.log('timeout');
                } else {
                    console.log('error');
                }
            });
        });

        $("#yes-btn").click(function(){
            var data = Object();
            data.operation = "delete-user";
            data.user_id = $("#de-username").val();

            var request = $.ajax({
                url: "api/user.api.php",
                dataType:'json',
                contentType: "application/json",
                type: 'POST',
                data: JSON.stringify(data)
            });
            request.always(function(){
                $('#deleteUserModal').modal('hide');
                $('#table').DataTable().ajax.reload();
            });
            request.done(function(response){
                if (response.success) {
                    showNotification('top', 'center', 'info', "User successfully deleted.");
                } else {
                    showNotification('top', 'center', 'danger', response.message);
                }
            });
            request.fail(function(jqXHR,textStatus){
                if(textStatus=='timeout'){
                    console.log('timeout');
                } else {
                    console.log('error');
                }
            });
        });
    } );

    function showCreateModal(){
        $('#cr-username').val("");
        $('#cr-password').val("");
        $('#createUserModal').modal('show');
    }

    function showDeleteModal(userId){
        $('#de-username').val(userId);
        $('#deleteUserId').html(userId);
        $('#deleteUserModal').modal('show');
    }

    function showUpdateModal(userId, role){
        $('#up-username').val(userId);
        $('#up-password').val("");
        $('#up-role').val(role);
        $('#updateUserModal').modal('show');
    }
</script>
</html>