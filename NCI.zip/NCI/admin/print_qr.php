<?php
if(isset($_GET['data'])){
	$qr_data = explode("*", $_GET['data']);
}
?>
<!DOCTYPE html>
<head>
	<script src="../assets/js/qrcode.min.js" type="text/javascript"></script>
</head>
<body>
<div style="width: 150px;">
<p align="center" id="qrcode"></p>
<h3 align="center"><?php echo $qr_data[1];?></h3>
</div>

<script type="text/javascript">
	var qrcode = new QRCode(document.getElementById("qrcode"), {width: 128, height: 128 });
	qrcode.clear();
	qrcode.makeCode("<?php echo $_GET['data'];?>");
</script>

</body>

</html>