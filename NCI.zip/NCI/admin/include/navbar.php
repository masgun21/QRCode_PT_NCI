<div class="collapse navbar-collapse">

    <ul class="nav navbar-nav navbar-right">
        <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                    <p>
                        Account
                        <b class="caret"></b>
                    </p>

              </a>
              <ul class="dropdown-menu">
                <li><a href="change-password.php" id="cp-btn">Change Password</a></li>
                <li class="divider"></li>
                <li><a href="logout.php">Log out</a></li>
              </ul>
        </li>
        <li class="separator hidden-lg"></li>
    </ul>
</div>