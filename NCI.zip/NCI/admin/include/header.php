<meta charset="utf-8" />
<link rel="icon" type="image/png" href="assets/img/nci.ico">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
<meta name="viewport" content="width=device-width" />


<!-- Bootstrap core CSS     -->
<link href="assets/css/bootstrap.min.css" rel="stylesheet" />

<!-- Animation library for notifications   -->
<link href="assets/css/animate.min.css" rel="stylesheet"/>

<!--  Light Bootstrap Table core CSS    -->
<link href="assets/css/light-bootstrap-dashboard.css?v=1.4.0" rel="stylesheet"/>

<!--     Fonts and icons     -->
<link href="assets/css/font-awesome.min.css" rel="stylesheet">
<!-- <link href='assets/css/roboto.css' rel='stylesheet' type='text/css'> -->
<link href="assets/css/pe-icon-7-stroke.css" rel="stylesheet" />

<!--	Datatables -->
<link href="assets/plugins/DataTables/datatables.min.css" rel="stylesheet" />

<link href="assets/css/rack.css" rel="stylesheet"/>