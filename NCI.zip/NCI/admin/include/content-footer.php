
<footer class="footer">
    <div class="container-fluid">
        <p class="copyright pull-right">
            &copy; <script>document.write(new Date().getFullYear())</script> <a href="#">PT. Daiho Indonesia</a>
        </p>
    </div>
</footer>