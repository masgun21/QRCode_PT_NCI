<div class="sidebar" data-color="azure" data-image="assets/img/sidebar-4.jpg" id="side_nav">

    <!--

        Tip 1: you can change the color of the sidebar using: data-color="blue | azure | green | orange | red | purple"
        Tip 2: you can also add an image using data-image tag

    -->

    <div class="sidebar-wrapper">
        <div class="logo">
            <img src="assets/img/nci-nav.png">
        </div>

        <ul class="nav">
            <li class="<?php echo ($menu == 1) ? "active" : "" ?>">
                <a href="dashboard.php">
                    <i class="pe-7s-user"></i>
                    <p>Users</p>
                </a>
            </li>
            <li class="<?php echo ($menu == 2) ? "active" : "" ?>">
                <a href="parts_update.php">
                    <i class="pe-7s-cash"></i>
                    <p>Update Part Price</p>
                </a>
            </li>
        </ul>
    </div>
</div>