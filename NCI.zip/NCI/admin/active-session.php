<?php
	include('dbcon.php');
	include('session.php');

	$sql = "SELECT * FROM tbl_Users WHERE user_id=?";
	$stmt = $conn->prepare($sql);
	$stmt->execute([$_SESSION['userId']]);

	if($row = $stmt->fetch(PDO::FETCH_ASSOC)){
		$username = $row['username'];
	}

?>