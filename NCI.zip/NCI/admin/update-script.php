<?php 
include('dbcon.php');

header('Content-Type: application/json');
$tbl_price_array = array();
if(isset($_GET['m'])){
	$m = $_GET['m'];

	$sql = "SELECT PART_CODE, PART_NUMBER, ".$m." FROM tbl_price";
	$stmt = $conn->prepare($sql);
	$stmt->execute();
	$i= 0;
	while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
		$tbl_price_array[$i]['PART_CODE'] = $row['PART_CODE'];
		$tbl_price_array[$i]['PART_NUMBER'] = $row['PART_NUMBER'];
		$tbl_price_array[$i]['PRICE'] = $row[$m];
		$i++;
	}

/* 	for($x = 0; $x <= sizeof($tbl_price_array)-1; $x++){
		$sql = "SELECT tbl_rawmats.UnitPrice AS RM_PRICE FROM tbl_rawmats INNER JOIN tbl_parts ON tbl_rawmats.[CODE] = tbl_parts.RAWMTL_CODE WHERE tbl_parts.PART_CODE=?";
		$stmt = $conn->prepare($sql);
		$stmt->execute([$tbl_price_array[$x]['PART_CODE']]);
		if($row = $stmt->fetch(PDO::FETCH_ASSOC)){
			$tbl_price_array[$x]['MATL_PRICE'] = round($row['RM_PRICE'], 3);
		} else {
			$tbl_price_array[$x]['MATL_PRICE'] = 0;
		}
	}

	for($x = 0; $x <= sizeof($tbl_price_array)-1; $x++){
		$upd = "UPDATE tbl_parts SET PART_PRICE='".$tbl_price_array[$x]['PRICE']."', Material_Price='".$tbl_price_array[$x]['MATL_PRICE']."' WHERE PART_CODE='".$tbl_price_array[$x]['PART_CODE']."' AND PART_NO='".$tbl_price_array[$x]['PART_NUMBER']."'";
		$stmt = $conn->prepare($upd);
		$stmt->execute();
	}

	echo json_encode("Parts Updated!"); */


	for($x = 0; $x <= sizeof($tbl_price_array)-1; $x++){
		$upd = "UPDATE JAKAD SET PART_PRICE='".$tbl_price_array[$x]['PRICE']."' WHERE PART_CODE='".$tbl_price_array[$x]['PART_CODE']."' AND PART_NO='".$tbl_price_array[$x]['PART_NUMBER']."'";
		$stmt = $conn->prepare($upd);
		$stmt->execute();
	}

	for($x = 0; $x <= sizeof($tbl_price_array)-1; $x++){
		$upd = "UPDATE JAKAD_ARCHIVES SET PART_PRICE='".$tbl_price_array[$x]['PRICE']."' WHERE PART_CODE='".$tbl_price_array[$x]['PART_CODE']."' AND PART_NO='".$tbl_price_array[$x]['PART_NUMBER']."'";
		$stmt = $conn->prepare($upd);
		$stmt->execute();
	}

	for($x = 0; $x <= sizeof($tbl_price_array)-1; $x++){
		$upd = "UPDATE JAKAD_T SET PART_PRICE='".$tbl_price_array[$x]['PRICE']."' WHERE PART_CODE='".$tbl_price_array[$x]['PART_CODE']."' AND PART_NO='".$tbl_price_array[$x]['PART_NUMBER']."'";
		$stmt = $conn->prepare($upd);
		$stmt->execute();
	}

	echo json_encode("PRICES UPDATED!");




} else {
	echo json_encode("No Data!");
}


?>