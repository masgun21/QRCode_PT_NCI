<?php
include('active-session.php');
?>

<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="theme.css" type="text/css">
  <link rel="icon" href="assets/img/daiho.ico">
  <!-- <link rel="stylesheet" href="includes/w3.css" type="text/css"> -->
  <link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css">
  <title>PT. DAIHO INDONESIA</title>
</head>
 <embed src="pc_beep.WAV" hidden=true autostart=false loop=false name="firstSound" mastersound>
<body style="background-color: white; color: black;" onload="autofocus()">

  <!-- side nav -->
  <!-- <div class="w3-sidebar w3-bar-block" style="width: auto; background-color: #3a7ce8; color: white; height: 100%; font-size: 17px; margin-top: 0px;">
      <a href="#" class="w3-bar-item w3-button w3-hover-white"><i class="fa fa-home"></i></a>
      <a href="#" class="w3-bar-item w3-button w3-hover-white"><i class="fa fa-gear"></i></a>
  </div> -->


<!-- main container -->
<div class='container-fluid' style="margin: 0px; width: 100%; padding: 0px;">
  <!-- top nav -->
 
    <nav class="navbar navbar-expand-md navbar-light bg-secondary" style="text-align: center; margin-bottom: 5%;">
    <a class="navbar-brand mx-3 " href="../../logo-login-1-daiho.png">
      <img style="margin-left: 70%;" src="assets/img/logo-nav-old.png" width="100%" alt="" height="auto" class="d-inline-block align-top"> </a>
    <!-- <div class="container">
      <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbar2SupportedContent">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse text-center justify-content-end" id="navbar2SupportedContent">
        <a class="btn navbar-btn ml-2 text-white btn-secondary">
          <i class="fa d-inline fa-lg fa-user-circle-o"></i>User</a>
      </div>
    </div> -->
  </nav>

  <style>
    .form-control{
      border-radius: 0px;
    }
    .input-width {
      width: 50%;
    }

  #btn_new{
    background-color: #4CAF50;
    border: none;
    color: white;
    padding: 5px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 15px;
    margin: 4px 2px;
    border-radius: 3px;

  }

  #logout{
    background-color: red;
    border: none;
    color: white;
    padding: 5px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 15px;
    margin: 4px 2px;
    border-radius: 3px;

  }

  label {
    font-weight: bold; 
  }
  </style>

  <style>
.switch {
  position: relative;
  display: inline-block;
  width: 60px;
  height: 34px;
}

.switch input {display:none;}

.slider {
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #ccc;
  -webkit-transition: .4s;
  transition: .4s;
}

.slider:before {
  position: absolute;
  content: "";
  height: 26px;
  width: 26px;
  left: 4px;
  bottom: 4px;
  background-color: white;
  -webkit-transition: .4s;
  transition: .4s;
}

input:checked + .slider {
  background-color: red;
}

input:focus + .slider {
  box-shadow: 0 0 1px #2196F3;
}

input:checked + .slider:before {
  -webkit-transform: translateX(26px);
  -ms-transform: translateX(26px);
  transform: translateX(26px);
}

/* Rounded sliders */
.slider.round {
  border-radius: 34px;
}

.slider.round:before {
  border-radius: 50%;
}

.bt {
  width: 100%;
  margin-bottom: 2%;
}
</style>


   <!-- The Modal -->
  <div class="modal fade" id="menu_modal">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">SELECT TRANSFER PROCESS</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
            
           <div class="form-group">
             <button class="btn btn-lg btn-danger bt" value="FGWHS-ONHOLD" onclick="set_loc(this.value)">FGWHS - ONHOLD</button>
             <button class="btn btn-lg btn-danger bt" value="ONHOLD-CRSNG" onclick="set_loc(this.value)">ONHOLD - CRSNG</button>
             <button class="btn btn-lg btn-danger bt" value="ONHOLD-FGWHS" onclick="set_loc(this.value)">ONHOLD - FGWHS</button>
             
			 
           </div>


        </div>
        
        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        </div>
        
      </div>
    </div>
  </div>




   <div class="container-fluid">
  <div class="row">
    <div class="col-md-12">
      <div class="text-center">
        <strong>User: <?php if($username == "fika"){ echo "Rofika ".'🌸';} else {echo $username;}?></strong>
        <button id="logout" onclick="window.location.assign('logout.php')">Logout</button>
      </div>
      
      <form role="form" class="form-inline">
        <input type="hidden" id="userID" value="<?php echo $username;?>"> <!-- this will hold the username of the current user -->
        <div class="form-group input-width">
          <label for="location_from">
            Document No.
          </label>
          <input type="text" class="form-control" id="DOCNUM" placeholder="Document No." disabled>
        </div>

        <div class="form-group input-width">
          <label for="location_from">
            Select Doc. No.
          </label>
          <select class="form-control" id="select_receipt" onchange="select_doc_num(this.value)">
             <option value="default" selected>---</option>
              <?php
                 include('dbcon.php');
                 $sql = "SELECT DOCNUM FROM tbl_inv_header WHERE DOCNUM LIKE '%FGH%' OR DOCNUM LIKE '%CRT%' OR DOCNUM LIKE '%RFG%' ORDER BY DOCNUM DESC";
                 $st = $conn->prepare($sql);
                 $st->execute();
                 while($row = $st->fetch(PDO::FETCH_ASSOC)){
                  echo "<option>".$row['DOCNUM']."</option>";
                 }
               ?>
          </select>
        </div>
        <div class="form-group input-width">
           <label for="location_from">
            Location From:
          </label>
          <select class="form-control" id="location_from" disabled>
            <option value="default" selected>---</option>
            <option vlaue="ONHOLD">ONHOLD</option>
            <option vlaue="FGWHS">FGWHS</option>
            <option vlaue="CRSNG">CRSNG</option>
          </select>
        </div>
        <div class="form-group input-width">
           <label for="location_from">
            Location To:
          </label>
          <select class="form-control" id="location_to" disabled>
            <option value="default" selected>---</option>
            <option vlaue="CRSNG">CRSNG</option>
            <option vlaue="ONHOLD">ONHOLD</option>
            <option vlaue="FGWHS">FGWHS</option>
          </select>
        </div>

        <div class="form-group input-width">
          <label for="location_from">
            Date:
          </label>
          <input type="date" class="form-control" id="transfer_date"> <!-- value="YYY-MM-DD" -->
        </div>

        <div class="form-group input-width">
          <label for="location_from">
            Shift: 
          </label>
          <select class="form-control" id="shift" onchange="generate_docnum()" disabled>
            <option value="default" selected>---</option>
            <option>A</option>
            <option>B</option>
            <option>C</option>
            <option>D</option>
          </select>
        </div>

        <div class="form-group" style="width: 100%;">
          <label for="scanned_text">Scanned QR Code:</label>
          <input type="text" class="form-control" id="scanned_text" onchange="delete_or_not()" disabled>
        </div>  

      </form>

      <div class="form-group" style="width: 100%;">

        <h5>Cancel Scan</h5>
          <label class="switch">
            <input type="checkbox" id="delete_check" onchange="toggle_delete()">
            <span class="slider round"></span>
          </label>

          <button id="btn_new" style="float: right;" onclick="window.location.assign('dashboard.php')">New Document No.</button>
        </div>

      <table class="table table-hover table-sm" id="res_table">
        <thead>
          <th>#</th>
          <th>P. Code</th>
          <th>P. No.</th>
          <th>P. Name</th>
          <th>Box QTY</th>
          <th>QTY</th>
        </thead>
        <tbody id="tbod">
          <?php
            include('box_data.php');
          ?>
         
          
        </tbody>
      </table>




    </div>
  </div>
</div>
</div>
    
    




<script src="assets/js/daijkt.js"></script>
<script src="assets/js/jquery-3.3.1.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
  
</body>

</html>