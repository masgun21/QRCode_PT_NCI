var checked;
var box_counter = 0;
function beep_ok() { var audio = new Audio("pc_beep.wav"); audio.play(); }
function beep_x() { var audio = new Audio("error.wav"); audio.play(); }

var d = new Date();
var date_string = d.getFullYear() + "-" + checkTime(d.getMonth()+1) + "-" + checkTime(d.getDate());
document.getElementById("transfer_date").value = date_string;

function toggle_delete(){
    checked = document.getElementById("delete_check").checked;
    document.getElementById("scanned_text").focus();
    console.log(checked);
  }

function delete_or_not(){
  if(checked){
    delete_mode();
  } else {
    send_data();
  }

}



function autofocus(){
  
  var url = new URL(window.location.href);
  var c = url.searchParams.get("docnum"); //get URL params
  if(c == null || c == "default"){
    document.getElementById("DOCNUM").value = "";
    document.getElementById("location_from").value = "default";
    document.getElementById("location_to").value = "default";
    document.getElementById("location_from").disabled = true;
    document.getElementById("location_to").disabled = true;
    document.getElementById("shift").value = "";
    document.getElementById("scanned_text").value = "";
    document.getElementById("scanned_text").disabled = true;
    $("#menu_modal").modal('show');
  } else {
    console.log(c);
    document.getElementById("DOCNUM").value = c;
    document.getElementById("scanned_text").disabled = false;
    document.getElementById("scanned_text").focus();
    generate_doc_data(c);
  }
}

function set_loc(loc_data){
  var loc = loc_data.split("-");
  document.getElementById("location_from").value = loc[0];
  document.getElementById("location_to").value = loc[1];
  document.getElementById("shift").disabled = false;
  $("#menu_modal").modal('hide');
}

function checkTime(i) {
if (i < 10) {i = "0" + i};  // add zero in front of numbers < 10
return i;
}

function init_1(){
  document.getElementById("location_to").disabled = false;
}
function init_2(){
  document.getElementById("shift").disabled = false;
}

function select_doc_num(doc_num){
  window.location.assign('dashboard.php?docnum='+doc_num);
}

function generate_docnum(){
  var loc_to = document.getElementById("location_to").value;
  var loc_from = document.getElementById("location_from").value;
  var shift_code = document.getElementById("shift").value;
  var loc_code, doc_num_string;
  date_string = document.getElementById("transfer_date").value;
  var date_split = date_string.split("-");

  if(loc_from == "FGWHS" && loc_to == "ONHOLD"){
    loc_code = "FGH";
  }
   else if(loc_from == "ONHOLD" && loc_to == "FGWHS"){
    loc_code = "RFG";
  } else if(loc_from == "ONHOLD" && loc_to == "CRSNG"){
    loc_code = "CRT";
  }

  doc_num_string = loc_code+date_split[2]+date_split[1]+date_split[0].substr(2,2)+shift_code;
  document.getElementById("DOCNUM").value = doc_num_string;
  document.getElementById("location_to").disabled = true;
  document.getElementById("location_from").disabled = true;

  document.getElementById("scanned_text").disabled = false;
  document.getElementById("scanned_text").focus();
}

function send_data(){
  var header_data = {};

  var doc_num = document.getElementById("DOCNUM").value;
  var loc_from = document.getElementById("location_from").value;
  var loc_to = document.getElementById("location_to").value;
  var shift_code = document.getElementById("shift").value;
  var date = document.getElementById("transfer_date").value;
  var scanned = document.getElementById("scanned_text").value;
  var userID = document.getElementById("userID").value;

  header_data.DOCNUM = doc_num;
  header_data.DATE = date_string;
  header_data.USERID = userID;
  header_data.FROMLOC = loc_from;
  header_data.TOLOC = loc_to;
  header_data.SHIFT = shift_code;

 


  $.post("insert_scan.php",
  {
      doc_num: doc_num,
      scanned: scanned,
      loc_to: loc_to,
      userID: userID,
      date: date_string,
      loc_from: loc_from

  },
  function(data, status){
      console.log(data);
    var resp = JSON.parse(data);
    console.log(resp);

    if(resp.message){
      beep_x();
      document.getElementById("scanned_text").value = "";
      document.getElementById("scanned_text").focus();

    } else {
     
      var xmlhttp = new XMLHttpRequest();
      xmlhttp.onreadystatechange = function() {
          if (this.readyState == 4 && this.status == 200) {

            $("#res_table").find("tbody").empty();
            document.getElementById("tbod").innerHTML = this.responseText;

            header_data.BOX_QTY = resp.box_qty;
            var string_header = JSON.stringify(header_data);


            $.post("insert-header.php",
            {
                header_d: string_header
            },
            function(data, status){
                //console.log(data, status);
            });
             
          }
          
      };
      xmlhttp.open("GET", "box_data.php?docnum="+doc_num, true);
      xmlhttp.send();

      //DISBALE ALL INPUTS EXCEPT SCANNED TEXT
      document.getElementById("shift").disabled = true;
      document.getElementById("select_receipt").disabled = true;
      document.getElementById("transfer_date").disabled = true;


      document.getElementById("scanned_text").value = "";
      document.getElementById("scanned_text").focus();
      beep_ok();
    }

  });


}

function delete_mode(){
    var docnum = document.getElementById("DOCNUM").value;
    var scanned = document.getElementById("scanned_text").value;
    var locto = document.getElementById("location_to").value;
    $.post("delete_mode.php",
      {
          DOCNUM: docnum,
          SCAN: scanned,
          LOCTO: locto
      },
      function(data, status){
        console.log(data);
        var respo = JSON.parse(data);

        if(respo.message){
          beep_x();
          document.getElementById("scanned_text").value = "";
          document.getElementById("scanned_text").focus();
          toggle_delete();
        } else {
         var xmlhttp = new XMLHttpRequest();
          xmlhttp.onreadystatechange = function() {
              if (this.readyState == 4 && this.status == 200) {
                

                $("#res_table").find("tbody").empty();
                document.getElementById("tbod").innerHTML = this.responseText;

              } 
          };
          xmlhttp.open("GET", "box_data.php?docnum="+docnum, true);
          xmlhttp.send();

          document.getElementById("scanned_text").value = "";
          document.getElementById("scanned_text").focus();
          beep_ok();
          toggle_delete();
        
        }

          
      });

}


function generate_doc_data(docnum){
    var xmlhttp = new XMLHttpRequest();
          xmlhttp.onreadystatechange = function() {
              if (this.readyState == 4 && this.status == 200) {
                var data_obj = JSON.parse(this.responseText);

                console.log(data_obj);
                  var myDate = data_obj.DOC_DATE;
                 myDate = myDate.split("-");

                document.getElementById("transfer_date").value = myDate[2] + "-" + myDate[1] + "-" + myDate[0];
                document.getElementById("location_from").value = data_obj.FROMLOC;
                document.getElementById("location_to").value = data_obj.TOLOC;
                
                document.getElementById("shift").value = data_obj.SHIFT;

                
                
              } 
          };
          xmlhttp.open("GET", "get_doc_data.php?docnum="+docnum, true);
          xmlhttp.send();
  }