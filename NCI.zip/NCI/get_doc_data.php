<?php

include('dbcon.php');

if(isset($_GET['docnum'])){

	$docnum = $_GET['docnum'];

	$resp_data = array();

	$sql = "SELECT TOP 1 * FROM tbl_inv_header WHERE DOCNUM=?";
	$stmt = $conn->prepare($sql);
	$stmt->execute([$docnum]);

	while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
		$resp_data['DOC_DATE'] = $row['DOC_DATE'];
		$resp_data['SHIFT'] = $row['SHIFT'];
		$resp_data['FROMLOC'] = $row['FROMLOC'];
		$resp_data['TOLOC'] = $row['TOLOC'];
	}

	echo json_encode($resp_data);








}



?>