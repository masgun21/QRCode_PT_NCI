<?php
	require_once(dirname(__FILE__)."/../config/laminate.inc.php");
	
	$search = $_GET['search']['value'];
	$offset = $_GET['start'];
	$size = $_GET['length'];
	$draw = intval($_GET['draw']);

	$Laminate = new Laminate();
	$datas = $Laminate->getListDT($search, $offset, $size);
	$total = $Laminate->getSizeDT($search);

    $output = array(
    	"draw" => $draw,
        "recordsTotal" => $total,
        "recordsFiltered" => $total,
        "data" => $datas
    );

    echo json_encode( $output );
?>