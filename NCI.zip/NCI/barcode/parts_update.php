<?php
include('active-session.php');
?>
<!doctype html>
<html lang="en">
<head>
    <title>PT. NCI Indonesia</title>
    <?php include 'include/header.php';?>
</head>
<body>

<div class="wrapper">
    <?php $menu = 2;?>
    <?php include 'include/navigation.php';?>

    <div class="main-panel">
        <nav class="navbar navbar-default navbar-fixed">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation-example-2">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#"></a>
                </div>
                <?php include 'include/navbar.php';?>
            </div>
        </nav>

		<div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Update Part Price</h4>
                               
                            </div>
                            <div class="content">
                                <div class="row">
                                    <div class="col-md-12">
                                    <label>Month Price: </label>
                                <select name="month_price" class='form-control' id="month_price" style="width: 20%;">
                                    <option selected></option>
                                    <option>JAN</option>
                                    <option>FEB</option>
                                    <option>MAR</option>
                                    <option>APR</option>
                                    <option>MAY</option>
                                    <option>JUN</option>
                                    <option>JUL</option>
                                    <option>AUG</option>
                                    <option>SEP</option>
                                    <option>OCT</option>
                                    <option>NOV</option>
                                    <option>DEC</option>
                                </select>
                                <br />
                                <button class="btn btn-primary" id="update_btn" onclick="send_update()" style="width: 20%;">UPDATE</button>
                                        <div class="content table-responsive table-full-width">
                                            <table id="table" class="table table-hover table-striped">
                                                <thead>
                                                    <tr>
                                                    <th>PartCode</th>
                                                    <th>PartNo</th>
                                                    <th>PartName</th>
                                                    <th>model</th>
                                                    <th>MONTH_PP</th>
                                                    <th>PART_PRICE</th>
                                                    <th>QTY_PER_BOX</th>
                                                    <th>status</th>
                                                    <th>plain_parts</th>
                                                    <th>spray_paint</th>
                                                    <th>RAWMTL_CODE</th>
                                                    <th>COLOR_CODE</th>
                                                    <th>SUBMTL_CODE1</th>
                                                    <th>submtl1_wt</th>
                                                    <th>submtl1_price</th>
                                                    <th>SUBMTL_CODE2</th>
                                                    <th>submtl2_wt</th>
                                                    <th>submtl2_price</th>
                                                    <th>SUBMTL_CODE3</th>
                                                    <th>submtl3_wt</th>
                                                    <th>submtl3_price</th>
                                                    <th>SUBMTL_CODE4</th>
                                                    <th>submtl4_wt</th>
                                                    <th>submtl4_price</th>
                                                    <th>SUBMTL_CODE5</th>
                                                    <th>submtl5_wt</th>
                                                    <th>submtl5_price</th>
                                                    <th>Submtl_total</th>
                                                    <th>Material_Price</th>
                                                    <th>Partition_Code</th>
                                                    <th>Tray_Code</th>
                                                    <th>Box_Code</th>
                                                    <th>Sprue_weight</th>
                                                    <th>Bag_code</th>
                                                    <th>Bag_dim</th>
                                                    <th>Mira_code</th>
                                                    <th>Mira_Dim</th>
                                                    <th>CAV</th>
                                                    <th>CYCLE</th>
                                                    <th>PART_WEIGHT</th>
                                                    <th>cust_code</th>
                                                    <th>mc_no</th>
                                                    <th>mt_code</th>
                                                    <th>remarks</th>
                                                    <th>matl_maker</th>
                                                    <th>matl_grade</th>
                                                    <th>matl_type</th>
                                                    <th>rgrind_ratio</th>
                                                    <th>ul_flame</th>
                                                    <th>partition_price</th>
                                                    <th>tray_price(USD)</th>
                                                    <th>box_price(Rp)</th>
                                                    <th>bag_price(Rp/Kg)</th>
                                                    <th>mira_price(Rp)</th>
                                                    <th>man_power</th>
                                                    <th>TONNAGE</th>
                                                    <th>SUPPLIER</th>
                                                    <th>Label_Color</th>
                                                    <th>upsize_ts</th>
                                                    <th>ep_no</th>
                                                    <th>unit_price</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                    
                                    <?php

                                    include('dbcon.php');
                                    error_reporting(0);
                                    $sql = "SELECT * FROM tbl_parts"; 
                                    $stmt = $conn->prepare($sql);
                                    $stmt->execute();

                                    while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
                                        echo "
                                        <tr>
                                        <td>".$row['PART_CODE']."</td>
                                        <td>".$row['PART_NO']."</td>
                                        <td>".$row['PART_NAME']."</td>
                                        <td>".$row['model']."</td>
                                        <td>".$row['MONTH_PP']."</td>
                                        <td>".number_format($row['PART_PRICE'],3)."</td>
                                        <td>".$row['QTY_PER_BOX']."</td>
                                        <td>".$row['status']."</td>
                                        <td>".$row['plain_parts']."</td>
                                        <td>".$row['spray_paint']."</td>
                                        <td>".$row['RAWMTL_CODE']."</td>
                                        <td>".$row['COLOR_CODE']."</td>
                                        <td>".$row['SUBMTL_CODE1']."</td>
                                        <td>".$row['submatl1_wt']."</td>
                                        <td>".$row['submatl1_price']."</td>
                                        <td>".$row['SUBMTL_CODE2']."</td>
                                        <td>".$row['submatl2_wt']."</td>
                                        <td>".$row['submatl2_price']."</td>
                                        <td>".$row['SUBMTL_CODE3']."</td>
                                        <td>".$row['submatl3_wt']."</td>
                                        <td>".$row['submatl3_price']."</td>
                                        <td>".$row['SUBMTL_CODE4']."</td>
                                        <td>".$row['submatl4_wt']."</td>
                                        <td>".$row['submatl4_price']."</td>
                                        <td>".$row['SUBMTL_CODE5']."</td>
                                        <td>".$row['submatl5_wt']."</td>
                                        <td>".$row['submatl5_price']."</td>
                                        <td>".$row['Submatl_Total']."</td>
                                        <td>".$row['Material_Price']."</td>
                                        <td>".$row['Partition_code']."</td>
                                        <td>".$row['Tray_code']."</td>
                                        <td>".$row['Box_code']."</td>
                                        <td>".$row['Sprue_weight']."</td>
                                        <td>".$row['Bag_code']."</td>
                                        <td>".$row['Bag_dim']."</td>
                                        <td>".$row['Mira_code']."</td>
                                        <td>".$row['Mira_dim']."</td>
                                        <td>".$row['CAV']."</td>
                                        <td>".$row['CYCLE']."</td>
                                        <td>".$row['PART_WEIGHT']."</td>
                                        <td>".$row['cust_code']."</td>
                                        <td>".$row['mc_no']."</td>
                                        <td>".$row['mt_code']."</td>
                                        <td>".$row['remarks']."</td>
                                        <td>".$row['matl_maker']."</td>
                                        <td>".$row['matl_grade']."</td>
                                        <td>".$row['matl_type']."</td>
                                        <td>".$row['rgrind_ratio']."</td>
                                        <td>".$row['ul_flame']."</td>
                                        <td>".$row['partition_price']."</td>
                                        <td>".$row['tray_price(USD)']."</td>
                                        <td>".$row['box_price(Rp)']."</td>
                                        <td>".$row['bag_price(Rp/Kg)']."</td>
                                        <td>".$row['mira_price(Rp)']."</td>
                                        <td>".$row['man_power']."</td>
                                        <td>".$row['TONNAGE']."</td>
                                        <td>".$row['SUPPLIER']."</td>
                                        <td>".$row['Label_Color']."</td>
                                        <td>".$row['upsize_ts']."</td>
                                        <td>".$row['ep_no']."</td>
                                        <td>".number_format($row['unit_price'], 2)."</td>
                                        </tr>

                                        ";
                                    }
                                    ?>


                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php include 'include/content-footer.php';?>
    </div>
</div>
</body>
<?php include 'include/footer.php';?>
<script type="text/javascript">
    $(document).ready(function() {
        var table = $("#table").DataTable({
                scrollY: "1000px",
                scrollX: true,
                scrollCollapse: true,
            });

      
    } );

    function send_update(){
        var month_price = $("#month_price").val();
        $.get("update-script.php?m="+month_price, function(data, status){
            alert(data);
            location.reload();
        });
    }

    function showCreateModal(){
        $('#cr-username').val("");
        $('#cr-password').val("");
        $('#createUserModal').modal('show');
    }

    function showDeleteModal(userId){
        $('#de-username').val(userId);
        $('#deleteUserId').html(userId);
        $('#deleteUserModal').modal('show');
    }

    function showUpdateModal(userId, role){
        $('#up-username').val(userId);
        $('#up-password').val("");
        $('#up-role').val(role);
        $('#updateUserModal').modal('show');
    }
</script>
</html>