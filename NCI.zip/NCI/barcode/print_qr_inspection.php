<?php
if (isset($_GET['data'])) {
	$params = explode(";", $_GET['data']);
	$printCounts = array();

	foreach ($params as $param) {
		$barcode = explode("*", $param);
		$printCount = $barcode[2];
		$materialName = $barcode[1];
		$printCounts[] = array('materialName' => $materialName, 'printCount' => $printCount);
	}
?>
	<!DOCTYPE html>
	<html>

	<head>
		<script src="../assets/js/qrcode.min.js" type="text/javascript"></script>
		<style>
			/* Define the grid container */
			.grid-container {
				display: grid;
				grid-template-columns: repeat(9, 1fr);
				grid-gap: 20px;
				padding: 20px;
			}
		</style>
	</head>

	<body>
		<?php
		foreach ($printCounts as $print) {
			$materialName = $print['materialName'];
			$printCount = $print['printCount'];
		?>
			<div class="grid-container">
				<?php for ($i = 0; $i < $printCount; $i++) { ?>
					<div class="barcode-container" data-material="<?php echo $materialName; ?>">
						<div class="qr-code"></div>
						<div class="text"><?php echo $materialName; ?></div>
					</div>
				<?php } ?>
			</div>
		<?php
		}
		?>

		<script>
			var qrCodeContainers = document.querySelectorAll('.barcode-container');
			var indexMap = {};

			qrCodeContainers.forEach(function(container) {
				var qrCodeDiv = container.querySelector('.qr-code');
				var qrCode = new QRCode(qrCodeDiv, {
					width: 80,
					height: 80
				});
				var materialName = container.dataset.material;

				if (!indexMap[materialName]) {
					indexMap[materialName] = 1;
				} else {
					indexMap[materialName]++;
				}

				var currentDate = new Date();
				var formattedDate = currentDate.toLocaleDateString('en-GB').split('/').reverse().join('-') + ":" + currentDate.toLocaleTimeString('en-GB').replace(/:/g, ':');

				var barcodeValue = "INCOMING" + "/" + materialName + "/" + formattedDate;
				qrCode.makeCode(barcodeValue);
			});
		</script>











	</body>

	</html>
<?php
}
?>