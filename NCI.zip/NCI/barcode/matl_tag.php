<?php

if(isset($_GET['ref'])){
	require_once('../config/material.inc.php');
	$matl = new MATERIAL();
	$params = json_decode($_GET['ref'], true);
	$rcv_data = ($matl->GET_RECEIVED_DATA($params['receive_id'], $params['manuf_item'], $params['lot_no']));

}


?>


<!DOCTYPE html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

</head>

<style>
    
 @medial all {
     .page-break {
         display: none;
     }
 }

 @media print {
     .page-break {
        display: block; 
        page-break-before: auto;
        position: relative;
        border-collapse: collapse;
        margin: 0.00in;
        padding: 0;
        margin-left: 0.1in;
        margin-right: 0.1in;
        margin-top: 0.1in;
        margin-bottom: 0.1in;

        
        width: auto;
        height: 100%;
        border: 0px solid black;
        border-style: solid;
        background: white;

     }

 }

 .palette_qr img {
	 width: 80px;
	 height: 80px;
 }


</style>

<style type="text/css">
.tg  {border-collapse:collapse;border-spacing:0;}
.tg td{font-family:Arial, sans-serif;font-size:70%;padding-bottom:0.3%; padding-top:0.3%; border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:black;}
.tg th{font-family:Arial, sans-serif;font-size:70%;font-weight:normal;padding-bottom:0.3%; padding-top:0.3%;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:black;}
.tg .tg-0lax{text-align:left;vertical-align:top;}
.h { font-size: 10px; font-weight: bold;}

#table_wrapper {
  height: 210px;
}
</style>





<script src="../assets/js/jquery.3.2.1.min.js"></script>
<script src="../assets/js/jquery-qrcode-0.15.0.min.js"></script>

<link href="../assets/css/bootstrap.min.css" rel="stylesheet">
<script src="../assets/js/bootstrap.min.js"></script>


<body onload="print()" onafterprint="window.history.back()">

        <?php 
					if(isset($rcv_data)){
						$pid_string = PID_STRING();
						for($x = 0; $x <= $params['tag_count']-1; $x++){
							$palette_id="PID-".$pid_string."-".($x+1);
							$qr_data = $palette_id."*".$rcv_data['material_code']."*".$rcv_data['lot_no']."*".$params['palette_weight']."*".$rcv_data['receive_date']."*".$params['receive_id'];

							echo "<div class='page-break' id='lw_".$x."'>";
							echo "<div class='container-fluid' style='font-size: 17px;'>
							<div class='row'>
								<div class='col-md-12'>
									<header>
										<img src='../assets/img/logo-nci.png' style='width: auto; height: 40px; margin-top: 0px;'/>
										<img src='../assets/img/header1-.png' style='float: right; width: auto; height: 40px; margin-top: 20px;'/>
									</header>
									<div class='row' style='width: 100%;'></div>

									

									<h1 class='text-center'>
										<strong>MATERIAL TAG</strong>
									</h1>
									<div class='row'>
										<div class='col-md-12'>
											<table class='tabke table-bordered tbl-sm' style='width: 100%;'>
												<thead>
													<tr>
														<td colspan='2' class='text-center' style='text-align: center; padding-top: 2%; padding-bottom: 2%;'><div id='qr_$x' class='palette_qr'></div></td>
													</tr>
												</thead>
												<tbody>

													<tr>
														<td><strong>Material Code:</strong></td>
														<td class='text-center'>".$rcv_data['material_code']."</td>
														
													</tr>
													<tr>
														<td><strong>Lot No.:</strong></td>
														<td class='text-center'>".$rcv_data['lot_no']."</td>
													</tr>
													<tr>
														<td><strong>Palette ID:</strong></td>
														<td class='text-center'>".$palette_id."</td>
														
													</tr>
													<tr>
														<td><strong>Weight:</strong></td>
														<td class='text-center'>".$params['palette_weight']." Kg</td>
													</tr>
													<tr>
														<td><strong>Received Date:</strong></td>
														<td class='text-center'>".$rcv_data['receive_date']."</td>
													</tr>
													<tr>
														<td><strong>Received ID:</strong></td>
														<td class='text-center'>".$params['receive_id']."</td>
													</tr>

													<tr>
														<td><strong>Received By:</strong></td>
														<td class='text-center'></td>
													</tr>
													
												</tbody>

											</table>
											
										</div>
									</div>
								</div>
							</div>
						
						</div>";

              echo '</div>';
                        
							echo "<p style='page-break-after: always; height: 0px;'</p>"; ?>
							<script>
								function generate_qr(data, id){
										$("#qr_"+id).qrcode({
											text: data,
											size: 300,
											render: 'image'
										}); 
								}
								generate_qr('<?php echo $qr_data;?>', '<?php echo $x;?>');
							</script>
					<?php	}
					}    
        ?>

<?php
function PID_STRING($length = 3){
	$characters = '0123456789ABCDEFGGHIJKLMNOPQRSTUVWXYZ';
	$charactersLength = strlen($characters);
	$randomString = date('m');
	for ($i = 0; $i < $length; $i++) {
	  $randomString .= $characters[rand(0, $charactersLength - 1)];
	}
	return $randomString;
}

?>

</body>

</html>