<?php
require('dbcon.php');


for ($i = 0; $i <= count($_POST['hapus']) - 1; $i++) {
    // //menghapus data sesuai urutan array
    mysqli_query($conn, "DELETE FROM t_inspection WHERE id=" . $_POST['hapus'][$i]);

    // // // require('../dbcon.php');
    // $sql = "DELETE FROM t_inspection WHERE id=?" . $_POST['hapus'][$i];
    // $stmt = $conn->prepare($sql);
    // $stmt->execute([$id]);
}

//kembali ke halaman sebelumnya
header("Location: inspection.php");
die();
