<div class="sidebar" data-color="azure" data-image="assets/img/batik3.jpg" id="side_nav">

    <!--

        Tip 1: you can change the color of the sidebar using: data-color="blue | azure | green | orange | red | purple"
        Tip 2: you can also add an image using data-image tag

    -->

    <div class="sidebar-wrapper">
        <div class="logo">
            <img src="assets/img/nci-nav.png">
        </div>

        <ul class="nav">

            <li class="<?php echo ($menu == 1) ? "active" : "" ?>">
                <a href="incoming.php">
                    <i class="pe-7s-note2"></i>
                    <p>Incoming</p>
                </a>
            </li>
            <!-- <li class="<?php /*  echo ($menu == 1) ? "active" : "" */ ?>">
                <a href="dashboard.php">
                    <i class="pe-7s-paint-bucket"></i>
                    <p>Mixing</p>
                </a>
            </li> -->
            <!-- <li class="<?php /* echo ($menu == 1) ? "active" : "" */ ?>">
                <a href="laminate.php">
                    <i class="pe-7s-photo-gallery"></i>
                    <p>Laminate</p>
                </a>
            </li> -->
        </ul>
    </div>
</div>