<?php
require('../dbcon.php');

header('Content-Type: application/json');
$response = array();


if (isset($_POST['data'])) {
	$json = json_decode($_POST['data']);
	if ($json->operation == "create-data") {
		$id = generate();
		$material_name = $json->material_name;
		$sup_lot = $json->sup_lot;
		$qty = $json->qty;
		$rcv_date = $json->rcv_date;
		$inspector = $json->inspector;
		$certificate = $json->certificate;
		$ex_date = $json->ex_date;
		$insp_result = $json->insp_result;

		if (!check_data($material_name)) {
			create_data($id, $material_name, $sup_lot, $qty, $rcv_date, $inspector, $certificate, $ex_date, $insp_result);
			$response['success'] = true;
			$response['message'] = "Success";
		} else {
			$response['success'] = false;
			$response['message'] = "Material ID already exists.";
		}
	} else if ($json->operation == "update-data") {
		update_data($json->id, $json->material_name, $json->sup_lot, $json->qty, $json->rcv_date, $json->inspector, $json->certificate, $json->ex_date, $json->insp_result, $json->id);
		$response['success'] = true;
		$response['message'] = "Data Berhasil di Update";
	} else if ($json->operation == "delete-data") {
		delete_data($json->id);
		$response['success'] = true;
		$response['message'] = "Data berhasil di hapus";
	}

	echo json_encode($response);
} else {
	$response['success'] = false;
}




function check_data($material_name)
{
	require('../dbcon.php');
	return;
	$sql = "SELECT TOP 1 material_name FROM t_incoming WHERE material_name=?";
	$stmt = $conn->prepare($sql);
	$stmt->execute([$material_name]);
	if ($data = $stmt->fetch(PDO::FETCH_ASSOC)) {
		return true;
	} else {
		return false;
	}
}


function create_data($id, $material_name, $sup_lot, $qty, $rcv_date, $inspector, $certificate, $ex_date, $insp_result)
{
	require('../dbcon.php');
	$sql = "INSERT INTO t_inspection (id, material_name, sup_lot, qty, rcv_date, inspector, certificate, ex_date, insp_result) VALUES (?,?,?,?,?,?,?,?,?)";
	$stmt = $conn->prepare($sql);
	$stmt->execute([$id, $material_name, $sup_lot, $qty, $rcv_date, $inspector, $certificate, $ex_date, $insp_result]);
}

function update_data($id, $material_name, $sup_lot, $qty, $rcv_date, $inspector, $certificate, $ex_date, $insp_result)
{
	require('../dbcon.php');
	$sql = "UPDATE `t_inspection`  SET `material_name`=?,`sup_lot`=?,`qty`=?,`rcv_date`=?,`inspector`=?,`certificate`=?,`ex_date`=?,`insp_result`=? WHERE `id`=?";
	$stmt = $conn->prepare($sql);
	$stmt->execute([$material_name, $sup_lot, $qty, $rcv_date, $inspector, $certificate, $ex_date, $insp_result, $id]);
}

function delete_data($id)
{
	require('../dbcon.php');
	$sql = "DELETE FROM t_inspection WHERE id=?";
	$stmt = $conn->prepare($sql);
	$stmt->execute([$id]);
}


function generate($length = 5)
{
	$characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
	$charactersLength = strlen($characters);
	$randomString = '';
	for ($i = 0; $i < $length; $i++) {
		$randomString .= $characters[rand(0, $charactersLength - 1)];
	}
	return $randomString;
}
