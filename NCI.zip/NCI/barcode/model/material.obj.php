<?php
	date_default_timezone_set("Asia/Jakarta");

	class MATERIAL
	{

		private $conn;

		public function __construct()
		{
			try {
				$this->conn = new PDO( "sqlsrv:server=".$GLOBALS["db_server_name"]." ; Database=".$GLOBALS["db_name"], $GLOBALS['uname'], $GLOBALS['pword']);  
				$this->conn->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
			} catch(Exception $e) {
				throw new Exception("SQL Server connection could not be established: ".$e->getMessage());
			}
		}


		public function MATERIAL_DETAILS($CODE){
			$sql = "SELECT * FROM tbl_rawmats WHERE [CODE]=?";
			$stmt = $this->conn->prepare($sql);
			$stmt->execute([$CODE]);
			$d = array();
			if($row = $stmt->fetch(PDO::FETCH_ASSOC)){
				$d[0] = $row['Description'];
				$d[1] = $row['COLOR'];
				$d[2] = $row['TYPE'];
				$d[3] = $row['CODE'];
				$d[4] = number_format($row['UnitPrice'],3);
				$d[5] = substr($row['CURRENCY'], 0,3);
				$d[6] = $row['SUPPLIER'];
			} else {
				$d = 0;
			}
			return $d;
		}

		public function GET_MATERIAL_D($search){
			$sql = "SELECT TOP 1 * FROM tbl_rawmats WHERE ([CODE] LIKE '%$search%') OR (MANUITEM LIKE '%$search%') OR ([Description] LIKE '%$search%') ORDER BY [CODE] ASC";
			$stmt = $this->conn->prepare($sql);
			$stmt->execute();
			if($row = $stmt->fetch(PDO::FETCH_ASSOC)){
				return $row['MANUITEM'];
			} else {
				return 0;
			}
		}
		public function MATERIAL_SUPPLIERS(){
			$sql = "  SELECT DISTINCT(SUPPLIER), SUPPLIER_NAME FROM tbl_rawmats";
			$stmt = $this->conn->prepare($sql);
			$stmt->execute();
			$d = array();
			while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
				$d[0][] = strtoupper($row['SUPPLIER_NAME']);
				$d[1][] = $row['SUPPLIER'];
			}
			return $d;
		}

		public function GET_SUPPLIER_NAME($SUPPLIER_CODE){
			$sql = "SELECT TOP 1 SUPPLIER_NAME FROM tbl_rawmats WHERE SUPPLIER=?";
			$stmt = $this->conn->prepare($sql);
			$stmt->execute([$SUPPLIER_CODE]);
			$d = array();
			while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
				return $row['SUPPLIER_NAME'];
			}
		}

		public function GET_RM_RACK(){
			$sql = "SELECT DISTINCT(RackID) FROM tbl_rack WHERE LEFT(RackID,2)<>'C-' ORDER BY RackID ASC";
			$stmt = $this->conn->prepare($sql);
			$stmt->execute();
			$d = array();
			while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
				$d[] = $row['RackID'];
			}
			return $d;
		}

		public function GENERATE_PID($type){
			if($type == "VIRGIN"){
				$sql = "SELECT TOP 1 palette_id FROM tbl_orders WHERE palette_id LIKE '%PID-%' ORDER BY palette_id DESC";
			} else if($type == "RETURN"){
				$sql = "SELECT TOP 1 palette_id FROM tbl_orders WHERE palette_id LIKE '%RID-%' ORDER BY palette_id DESC";
			} else if($type == "CRUSHED"){
				$sql = "SELECT TOP 1 palette_id FROM tbl_orders WHERE palette_id LIKE '%CID-%' ORDER BY palette_id DESC";
			}
			$stmt = $this->conn->prepare($sql);
			$stmt->execute();
			while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
				$last_id = $row['palette_id'];
			}

			if(!isset($last_id)){
				$resp['id'] = $last_id = 0;
			} else {
				$explode = explode("-", $last_id);
				$do_count = substr($explode[1], 4, 6);
				$do_count = intval($do_count);
				$resp['id'] = $do_count;
			}
			
			$resp['date'] = date('y').date('m');
			
			return ($resp);
		}

		public function CREATE_MATERIAL_KANBAN($lbl_count){
			$sql = "SELECT TOP 1 Kanban_ID FROM tbl_inventory_matl ORDER BY Kanban_ID DESC";
			$stmt = $this->conn->prepare($sql);
			$stmt->execute();
			if($data = $stmt->fetch(PDO::FETCH_ASSOC)){
				$kanban = substr($data['Kanban_ID'],1);
				
			} else {
				$kanban = 0;
			}
		
			for($x = 1; $x <= $lbl_count; $x++){
				$kanban = intval($kanban) + 1;
				$kanban_id[] = "M".str_pad(intval($kanban), 12, '0', STR_PAD_LEFT);
			}
		
			return $kanban_id;
		}

		public function INSERT_ORDER($INPUTS){
			$d = json_decode($INPUTS, true);
			$sql = "INSERT INTO tbl_orders(date, ref_no, code, type, color, wt_per_bag, order_qty, labels_to_produce, rcv_date, supplier, kanban_stat, lot_no, PO_No, palette_id, do_no, pengajuan, pendaftaran, bc_type, invoice_no, unit_price, price_total, tanggal_pendaftaran, currency, rack_id) VALUES (GETDATE(),?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			$stmt = $this->conn->prepare($sql);
			$stmt->execute([$d['kanban_no'], $d['matl_code'], $d['matl_type'], $d['matl_color'], $d['matl_wkg'], $d['matl_qty'], $d['matl_count'], $d['matl_date'], $d['matl_supplier'], 1, $d['matl_lot'], $d['matl_po'], $d['pid'], $d['matl_do'], $d['bc_pengajuan'], $d['bc_pendaftaran'], $d['bc_type'], $d['matl_invoice'], $d['matl_price'], $d['matl_total'], $d['bc_tgl_pendaftaran'], $d['matl_currency'], $d['matl_loc']]);
			/* $sql = "INSERT INTO tbl_material_palette(palette_id, [timestamp], matl_code, matl_name, matl_type, matl_color, wt_per_bag, order_qty, lot_no, location_id, REF_NO) VALUES(?,GETDATE(),?,?,?,?,?,?,?,?,?)";
			$stmt = $this->conn->prepare($sql);
			$stmt->execute([$d['pid'], $d['matl_code'], $d['matl_name'], $d['matl_type'], $d['matl_color'], $d['matl_wkg'], $d['matl_qty'], $d['matl_lot'], $d['matl_do'], $d['ref_no']]); */
		}

		public function INSERT_MATL_KANBAN($kanban_id, $palette_id, $lot_no, $matl_date, $matl_code, $matl_type, $matl_grade, $matl_color, $matl_wkg, $matl_supplier, $rack_id){
			/* $sql = "INSERT INTO tbl_inventory_matl(Kanban_ID, palette_id, matl_code, matl_type, matl_color, lot_no, wt_per_bag, location_id) VALUES (?,?,?,?,?,?,?,?)"; */
			$sql = "INSERT INTO tbl_inventory_matl(Kanban_ID, palette_id, lot_no, rcv_date, code, type, grade, color, weight_kg, SUPPLIER, rack_id) VALUES (?,?,?,?,?,?,?,?,?,?,?)";
			$stmt = $this->conn->prepare($sql);
			$stmt->execute([$kanban_id, $palette_id, $lot_no, $matl_date, $matl_code, $matl_type, $matl_grade, $matl_color, $matl_wkg, $matl_supplier, $rack_id]);

		}

		public function GET_PALETTE_IDS($type){
			if($type == "VIRGIN"){
				$sql = "SELECT DISTINCT palette_id FROM tbl_material_palette WHERE palette_id LIKE '%PID-%' ORDER BY palette_id DESC";
			} else if($type == "RETURN"){
				$sql = "SELECT DISTINCT palette_id FROM tbl_material_palette WHERE palette_id LIKE '%RID-%' ORDER BY palette_id DESC";
			} else if($type == "CRUSHED"){
				$sql = "SELECT DISTINCT palette_id FROM tbl_material_palette WHERE palette_id LIKE '%CID-%' ORDER BY palette_id DESC";
			}
			$stmt = $this->conn->prepare($sql);
			$stmt->execute();
			$pids = array();
			while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
				$pids[] = $row;
			} 
			return $pids;
		}

		public function GET_PALETTE_INFO($pid){
			$sql = "SELECT * FROM tbl_orders WHERE palette_id=?";
			$stmt = $this->conn->prepare($sql);
			$stmt->execute([$pid]);
			if($row = $stmt->fetch(PDO::FETCH_ASSOC)){
				return $row;
			} else {
				return 0;
			}
		}

		public function DELETE_PALETTE_DATA($pid){
			$sql[0] = "DELETE FROM tbl_material_palette WHERE palette_id=?";
			$sql[1] = "DELETE FROM tbl_inventory_matl WHERE palette_id=?";

			for($x = 0; $x <= sizeof($sql)-1; $x++){
				$stmt = $this->conn->prepare($sql[$x]);
				$stmt->execute([$pid]);
			}
		}

		public function PALETTE_CHECK($palette_id){
			$sql = "SELECT TOP 1 palette_id FROM tbl_material_palette WHERE (palette_id=?) AND (location_id IS NULL)";
			$stmt = $this->conn->prepare($sql);
			$stmt->execute([$palette_id]);
			if($row = $stmt->fetch(PDO::FETCH_ASSOC)){
				return true;
			} else {
				return false;
			}
		}

		public function ASSIGN_PALETTE_LOCATION($palette_id, $location_id, $cancel){
			if(!$cancel){
				$sql[0] = "UPDATE tbl_material_palette SET location_id=? WHERE (palette_id=?)";
				$sql[1] = "UPDATE tbl_inventory_matl SET location_id=? WHERE (palette_id=?) AND (issued_date IS NULL) AND (supplied IS NULL)";
			} else {
				$sql[0] = "UPDATE tbl_material_palette SET location_id=NULL WHERE (location_id=?) AND (palette_id=?)";
				$sql[1] = "UPDATE tbl_inventory_matl SET location_id=NULL WHERE (location_id=?) AND (palette_id=?)AND (issued_date IS NULL) AND (supplied IS NULL)";
			}

			for($x = 0; $x <= sizeof($sql)-1; $x++){
				$stmt = $this->conn->prepare($sql[$x]);
				$stmt->execute([$location_id, $palette_id]);
			}
		}


		public function MATL_ISSUE_CHECK($palette_qr, $matl_qr){
			$p_qr = explode("*", $palette_qr);
			$m_qr = explode("*", $matl_qr);
			$sql = "SELECT vw_Parts.mt_code FROM vw_Parts WHERE [PART_CODE]=?";
			$stmt = $this->conn->prepare($sql);
			$stmt->execute([$m_qr[1]]);
			if($row = $stmt->fetch(PDO::FETCH_ASSOC)){
				if(strpos($row['mt_code'], $p_qr[1]) !== false){
					return true;
				} else {
					return false;
				}
			} else {
				return false;
			}
		}

		public function ISSUE_MATL($palette_qr, $matl_qr, $cancel){
			$p_qr = explode("*", $palette_qr);
			$m_qr = explode("*", $matl_qr);
			#GET ISSUE STATUS OF THE LABEL ID
			$i_status = $this->CHECK_ISSUE_STATUS($m_qr[0]);
			
			if($cancel == "false"){
				if(!$i_status){
					$sql = "UPDATE TOP (1) tbl_inventory_matl SET mc_no=?, part_code=?, part_kanban_id=?, issued_date=GETDATE() WHERE (palette_id=?) AND (matl_code=?) AND (issued_date IS NULL)";
					$stmt = $this->conn->prepare($sql);
					$c = ($stmt->execute([$m_qr[7], $m_qr[1], $m_qr[0], $p_qr[0], $p_qr[1]]));
				} else {
					$c = false;
				}
			} else {
				if($i_status){
					$sql = "UPDATE TOP(1) tbl_inventory_matl SET mc_no=NULL, part_code=NULL, part_kanban_id=NULL, issued_date=NULL WHERE (part_kanban_id=?) AND (palette_id=?)";
					$stmt = $this->conn->prepare($sql);
					$c = $stmt->execute([$m_qr[0], $p_qr[0]]);
				} else {
					$c = false;
				}
			}


			return $c;
		
		}

		public function CHECK_ISSUE_STATUS($part_kanban_id){
			$sql = "SELECT TOP 1 Kanban_ID FROM tbl_inventory_matl WHERE part_kanban_id=?";
			$stmt = $this->conn->prepare($sql);
			$stmt->execute([$part_kanban_id]);
			if($row = $stmt->fetch(PDO::FETCH_ASSOC)){
				return true;
			} else {
				return false;
			}
		}

		public function MATERIAL_LOCATION_DATA($location_id){
			$sql = "SELECT dbo.tbl_inventory_matl.palette_id, dbo.tbl_inventory_matl.matl_code, dbo.tbl_rawmats.MATL_NAME, SUM(dbo.tbl_inventory_matl.wt_per_bag) AS QTY
			FROM dbo.tbl_inventory_matl INNER JOIN
			dbo.tbl_rawmats ON dbo.tbl_inventory_matl.matl_code = dbo.tbl_rawmats.CODE
			WHERE (dbo.tbl_inventory_matl.location_id = ?) AND dbo.tbl_inventory_matl.issued_date IS NULL
			GROUP BY dbo.tbl_inventory_matl.palette_id, dbo.tbl_inventory_matl.matl_code, dbo.tbl_rawmats.MATL_NAME, dbo.tbl_inventory_matl.location_id";
			$stmt = $this->conn->prepare($sql);
			$stmt->execute([$location_id]);
			$d = array();
			while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
				$d[] = $row;
			}
			return $d;
		}
		

		public function VALIDATE_INSTRUCTION_QR($qr){
			$sql = "SELECT tbl_packing_header.* FROM tbl_packing_header WHERE REF_NO=?";
			$stmt = $this->conn->prepare($sql);
			$stmt->execute([$qr]);
			$resp = array();
			if($row = $stmt->fetch(PDO::FETCH_ASSOC)){
				$resp[0] = $row;
				$resp[1] = $this->GET_INSTRUCTION_MATL($row['REF_NO']);
			} else {
				$resp[0] = false;
			}
			return $resp;
		}

		public function GET_INSTRUCTION_MATL($REF_NO){
			$sql = "SELECT tbl_packing_details.*, tbl_rawmats.CODE AS CODE
			FROM tbl_packing_details INNER JOIN tbl_rawmats ON tbl_packing_details.ITEM_CODE = tbl_rawmats.MANUITEM WHERE tbl_packing_details.REF=?";

			#GET ONLY THE MATERIAL CODE THAT DOES NOT HAVE THE COMPLETE QTY RECEIVED BASED ON THE ORIGINAL PACKING LIST
			/* $sql = "SELECT PD.ITEM_CODE, PD.ITEM_NAME
			FROM tbl_packing_details PD 
			WHERE ISNULL((SELECT SUM(order_qty) FROM tbl_material_palette WHERE tbl_material_palette.REF_NO = PD.REF AND tbl_material_palette.matl_code = PD.ITEM_CODE GROUP BY tbl_material_palette.matl_code),0)
			<>
			(SELECT SUM(PD_1.WEIGHT) FROM tbl_packing_details PD_1 WHERE PD_1.REF = PD.REF AND PD_1.ITEM_CODE = PD.ITEM_CODE)
			AND PD.REF=?
			GROUP BY ITEM_CODE, ITEM_NAME"; */
			$stmt = $this->conn->prepare($sql);
			$stmt->execute([$REF_NO]);
			$resp = array();
			while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
				$resp[] = $row;
			}
			return $resp;
		}

		public function RETURN_MATERIAL($label_data, $RID, $location_id){
			$lbl_d = explode("*", $label_data);
			$i_status = $this->CHECK_ISSUE_STATUS($lbl_d[0]);
			if($i_status){
				$sql = "UPDATE tbl_inventory_matl SET mc_no=NULL, part_code=NULL, part_kanban_id=NULL, issued_date=NULL, returned_date=GETDATE(), palette_id=?, location_id=? WHERE (part_kanban_id=?) AND (rm_code=?)";
				$stmt = $this->conn->prepare($sql);
				$c = $stmt->execute([$RID, $location_id, $lbl[0], $lbl[3]]);
			} else {
				//Label Kanban ID Not Found
				$c = false;
			}
			return $c;
		}


		public function GET_RCV_MATL($KANBAN_NUMBER, $MATERIAL_CODE, $LOT){
			$sql = "SELECT SUM(order_qty) AS RCV FROM tbl_material_received WHERE (kanban_number=?) AND (manu_item=?) AND (lot_no=?)";
			$stmt = $this->conn->prepare($sql);
			$stmt->execute([$KANBAN_NUMBER, $MATERIAL_CODE, $LOT]);
			if($row = $stmt->fetch(PDO::FETCH_ASSOC)){
				return $row['RCV'];
			} else {
				return 0;
			}
		}



		/* MATERIAL KANBAN */

		public function GET_CURRENT_INVENTORY(){
			$sql = "SELECT        tbl_inventory_matl.palette_id, tbl_rawmats.CODE, tbl_rawmats.MATL_NAME, tbl_rawmats.COLOR_CODE, tbl_rawmats.MATL_TYPE, tbl_rawmats.MATL_MAKER, SUM(tbl_inventory_matl.wt_per_bag) AS QTY,
			tbl_inventory_matl.wt_per_bag AS WKG, SUM(tbl_inventory_matl.wt_per_bag)/tbl_inventory_matl.wt_per_bag AS BAG_COUNT, tbl_inventory_matl.location_id AS LOC
			FROM            tbl_inventory_matl INNER JOIN
			tbl_rawmats ON tbl_inventory_matl.matl_code = tbl_rawmats.CODE
			WHERE tbl_inventory_matl.issued_date IS NULL
			GROUP BY tbl_rawmats.CODE, tbl_rawmats.MATL_NAME, tbl_rawmats.COLOR_CODE, tbl_rawmats.MATL_TYPE, tbl_rawmats.MATL_MAKER, tbl_inventory_matl.palette_id, tbl_inventory_matl.wt_per_bag, tbl_inventory_matl.location_id
			ORDER BY tbl_inventory_matl.palette_id DESC";
			$stmt = $this->conn->prepare($sql);
			$stmt->execute();
			$data = array();
			while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
				$data[] = $row;
			}
			return $data;
		}


		public function CREATE_KANBAN_NUMBER(){
			$sql = "SELECT TOP 1 KANBAN_DO FROM tbl_material_kanban ORDER BY INPUT_TIMESTAMP DESC";
			$stmt = $this->conn->prepare($sql);
			$stmt->execute();
			if($row = $stmt->fetch(PDO::FETCH_ASSOC)){
				$LAST_DO = $row['KANBAN_DO'];
			} else {
				$LAST_DO = "RM-0000000";
			}

			/* RM-0000001 */
			$RUNNING_NO = explode('-', $LAST_DO);
			$RUNNING_NO = intval($RUNNING_NO[1]) + 1;

			return "RM-".str_pad(intval($RUNNING_NO), 7, '0', STR_PAD_LEFT);

		}


		public function SAVE_KANBAN_HEADER($HEADER_DATA){
			$KANBAN_NO = $this->CREATE_KANBAN_NUMBER();
			$HD = json_decode($HEADER_DATA, true);
			$sql = "INSERT INTO tbl_material_kanban(KANBAN_DO, SENDER, RECEIVER, KANBAN_DATE, REMARKS, INPUT_TIMESTAMP, USER_INPUT) VALUES (?,?,?,?,?,GETDATE(),?)";
			$stmt = $this->conn->prepare($sql);
			$stmt->execute([$KANBAN_NO, $HD['sender'], $HD['receiver'], $HD['date'], $HD['remarks'], $HD['user_input']]);
			return $KANBAN_NO;
		}

		public function SAVE_KANBAN_ITEM($DETAILS){
			$D = json_decode($DETAILS, true);
			$sql = "INSERT INTO tbl_material_kanban_details(KANBAN_NO, PALETTE_ID, LOCATION_ID, MATL_CODE, WKG, QTY, ITEM_COUNT, MATL_PRICE) VALUES(?,?,?,?,?,?,?,?)";
			$stmt = $this->conn->prepare($sql);
			$stmt->execute([$D['kanban'], $D['palette'], $D['loc'], $D['code'], $D['kg'], $D['qty'], $D['count'], 0]);

			for($x = 1; $x <= intval($D['count']); $x++){
				$this->PICK_MATERIAL($D['palette'], $D['code'], $D['kanban'], 1);
			}
		}

		public function GET_KANBAN_NUMBERS(){
			$sql = "SELECT KANBAN_DO FROM tbl_material_kanban ORDER BY INPUT_TIMESTAMP DESC";
			$stmt = $this->conn->prepare($sql);
			$stmt->execute();
			$data = array();
			while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
				$data[] = $row['KANBAN_DO'];
			}
			return $data;
		}

		public function GET_KANBAN_NUMBER_DETAILS($KANBAN_NO){
			$sql = "SELECT * FROM tbl_material_kanban WHERE KANBAN_DO=?";
			$stmt = $this->conn->prepare($sql);
			$stmt->execute([$KANBAN_NO]);
			if($row = $stmt->fetch(PDO::FETCH_ASSOC)){
				return $row;
			} else {
				return false;
			}
		}

		public function GET_KANBAN_NUMBER_ITEMS($KANBAN_NO){
			$sql = "SELECT        tbl_material_kanban_details.DATA_NO, tbl_material_kanban_details.KANBAN_NO, tbl_material_kanban_details.PALETTE_ID, tbl_material_kanban_details.MATL_CODE, tbl_material_kanban_details.WKG, 
			tbl_material_kanban_details.QTY, tbl_material_kanban_details.ITEM_COUNT, tbl_material_kanban_details.MATL_PRICE, tbl_rawmats.COLOR_CODE AS COLOR, tbl_rawmats.MATL_TYPE AS TYPE, tbl_rawmats.GRADE, 
			tbl_rawmats.MATL_NAME AS NAME, tbl_material_kanban_details.LOCATION_ID
			FROM            tbl_material_kanban_details INNER JOIN
						tbl_rawmats ON tbl_material_kanban_details.MATL_CODE = tbl_rawmats.CODE WHERE tbl_material_kanban_details.KANBAN_NO=?";
			$stmt = $this->conn->prepare($sql);
			$stmt->execute([$KANBAN_NO]);
			$data = array();
			while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
				$data[] = $row;
			} 
			return $data;
		}

		public function DELETE_KANBAN_ITEM($DATA_NO){
			$D = explode("*", $DATA_NO);
			$sql = "DELETE FROM tbl_material_kanban_details WHERE DATA_NO=?";
			$stmt = $this->conn->prepare($sql);
			$stmt->execute([$D[0]]);

			for($x = 1; $x <= intval($D[3]); $x++){
				$this->PICK_MATERIAL($D[1], $D[2], $D[4], 0);
			}
		}

		public function DELETE_KANBAN($KANBAN){
			$sql = "SELECT * FROM tbl_material_kanban_details WHERE KANBAN_NO=?";
			$stmt = $this->conn->prepare($sql);
			$stmt->execute([$KANBAN]);
			while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
				for($x = 1; $x <= intval($row['ITEM_COUNT']); $x++){
					$this->PICK_MATERIAL($row['PALETTE_ID'], $row['MATL_CODE'], $KANBAN, 0);
				}
			}
			
			$sql = "DELETE FROM tbl_material_kanban WHERE KANBAN_DO=?";
			$stmt = $this->conn->prepare($sql);
			$stmt->execute([$KANBAN]);

			$sql = "DELETE FROM tbl_material_kanban_details WHERE KANBAN_NO=?";
			$stmt = $this->conn->prepare($sql);
			$stmt->execute([$KANBAN]);


		}

		public function PICK_MATERIAL($PALETTE_ID, $MATL_CODE, $KANBAN_DO, $STATE){

			if($STATE == 1){
				$sql = "UPDATE TOP (1) tbl_inventory_matl SET mc_no='ENGIAP', part_kanban_id=?, issued_date=GETDATE() WHERE (palette_id=?) AND (matl_code=?) AND (issued_date IS NULL)";
			} else if($STATE == 0){
				$sql = "UPDATE TOP (1) tbl_inventory_matl SET mc_no=NULL, issued_date=NULL, part_kanban_id=NULL WHERE (part_kanban_id=?) AND (palette_id=?) AND (matl_code=?) AND (issued_date IS NOT NULL)";
			}
			$stmt = $this->conn->prepare($sql);
			$stmt->execute([$KANBAN_DO, $PALETTE_ID, $MATL_CODE]);

		}

		public function GET_RACK_STATUS($rack_id){
			$sql = "SELECT SUM(weight_kg) AS C FROM tbl_inventory_matl WHERE rack_id=? AND issued_date IS NULL";
			$stmt = $this->conn->prepare($sql);
			$stmt->execute([$rack_id]);
			if($row = $stmt->fetch(PDO::FETCH_ASSOC)){
				return $row['C'];
			} else {
				return 0;
			}

		}

		public function GET_RECEIVED_DATA($RCV_ID, $MANU_ITEM, $LOT){
			$sql = "SELECT TOP 1 * FROM tbl_material_received WHERE (receive_no=?) AND (manu_item=?) AND (lot_no=?)";
			$stmt = $this->conn->prepare($sql);
			$stmt->execute([$RCV_ID, $MANU_ITEM, $LOT]);
			if($row = $stmt->fetch(PDO::FETCH_ASSOC)){
				return $row;
			}
		}

		public function CHECK_ASSIGNED_MATERIAL($RM_CODE, $LOT, $RCV_DATE, $RCV_ID){
			$sql = "SELECT DISTINCT(T1.PALETTE_ID) AS PID, (SELECT SUM(T2.BAG_WEIGHT) FROM tbl_material_inventory T2 WHERE T2.MATERIAL_CODE='$RM_CODE' AND T2.LOT_NO='$LOT' AND T2.RECEIVE_ID='$RCV_ID') AS QTY FROM tbl_material_inventory T1 WHERE T1.[MATERIAL_CODE]=? AND T1.LOT_NO=? AND T1.RECEIVE_ID=? GROUP BY T1.PALETTE_ID";

			$stmt = $this->conn->prepare($sql);
			$stmt->execute([$RM_CODE, $LOT, $RCV_ID]);
			$data = array();
			while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
				$data['PID'][] = $row['PID'];
				$data['QTY'][] = $row['QTY'];
			}
			return $data;
		}


		public function GET_REPRINT_DATA($PALETTE_ID){
			$sql = "SELECT TOP 1 MATERIAL_CODE AS code, LOT_NO as lot_no, SUM(BAG_WEIGHT) AS palette_weight, CONVERT(date, ASSIGN_TIME, 111) AS rcv_date, RECEIVE_ID AS PO_NO FROM tbl_material_inventory WHERE palette_id=? GROUP BY MATERIAL_CODE, LOT_NO, CONVERT(date, ASSIGN_TIME, 111), RECEIVE_ID";
			$stmt = $this->conn->prepare($sql);
			$stmt->execute([$PALETTE_ID]);
			if($row = $stmt->fetch(PDO::FETCH_ASSOC)){
				return $row;
			}
		}




















		
        
    
    
        


	}
	
?>