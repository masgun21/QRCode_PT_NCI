<?php

class Incoming
{

	private $conn;

	public function __construct()
	{
		$host = "localhost";
		$dbname = "db_nci";
		$username = "root";
		$password = "";


		try {
			$this->conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
			// echo "Connected to $dbname at $host successfully.";
		} catch (PDOException $pe) {
			die("Could not connect to the database $dbname :" . $pe->getMessage());
		}
	}


	public function createUser($user_id, $username, $password, $role)
	{
		$sql = "INSERT INTO tbl_Users (user_id, username, password, role) VALUES (?,?,?,?)";
		$datas = $this->conn->prepare($sql);
		$datas->execute([$user_id, $username, $password, $role]);
		return true;
	}

	public function loginUser($username, $password)
	{
		$sql = "SELECT TOP 1 UserID, UserRole FROM tbl_Users WHERE UserID='" . $username . "' AND Password = CONVERT(VARCHAR(32), HashBytes('MD5', '" . $password . "'), 2)";
		$datas = $this->conn->prepare($sql);
		$datas->execute();

		if ($data = $datas->fetch(PDO::FETCH_ASSOC)) {
			$_SESSION[$this->sessionName]["userId"] = $data["UserID"];
			$_SESSION[$this->sessionName]["role"] = $data["UserRole"];
			$this->logged_in = true;
			return true;
		}

		return false;
	}

	public function logoutUser()
	{
		if (isset($_SESSION[$this->sessionName]))
			unset($_SESSION[$this->sessionName]);

		$this->logged_in = false;
	}

	public function setPassword($password, $userId = null)
	{
		if ($userId == null)
			$userId = $_SESSION[$this->sessionName]["userId"];

		$sql = "UPDATE tbl_Users SET Password=CONVERT(VARCHAR(32), HashBytes('MD5', '" . $password . "'), 2) WHERE UserID='" . $userId . "'";
		$datas = $this->conn->prepare($sql);
		$datas->execute();
	}

	public function getUsers()
	{

		$sql = "SELECT DISTINCT UserID FROM tbl_Users ORDER BY UserID ASC";

		$datas = $this->conn->prepare($sql);
		$datas->execute();

		$users = array();

		$i = 0;
		while ($data = $datas->fetch(PDO::FETCH_ASSOC)) {
			$users[$i]["userId"] = $data["UserID"];
			$i++;
		}

		return $users;
	}

	public function getSingleUser($userId)
	{

		$sql = "SELECT TOP 1 user_id FROM tbl_Users WHERE user_id='" . $userId . "'";
		$datas = $this->conn->prepare($sql);
		$datas->execute();

		if ($data = $datas->fetch(PDO::FETCH_ASSOC)) {
			$user["userId"] = $data["user_id"];
			return $user;
		}
		return false;
	}

	public function getSingleData($material_id)
	{

		$sql = "SELECT TOP 1 material_id FROM t_mixing WHERE material_id='" . $material_id . "'";
		$datas = $this->conn->prepare($sql);
		$datas->execute();

		if ($data = $datas->fetch(PDO::FETCH_ASSOC)) {
			$material_id["material_id"] = $data["material_id"];
			return $user;
		}
		return false;
	}

	public function deleteUser($userId)
	{
		$sql = "DELETE FROM tbl_Users WHERE user_id='" . $userId . "'";
		$datas = $this->conn->prepare($sql);
		$datas->execute();

		return;
	}

	private function _validateUser()
	{
		if (!isset($_SESSION[$this->sessionName]["userId"]))
			return;

		if (!$this->_validateUserId())
			return;

		$this->logged_in = true;
	}

	private function _validateUserId()
	{
		$userId = $_SESSION[$this->sessionName]["userId"];

		$sql = "SELECT TOP 1 UserID FROM tbl_Users WHERE UserID='" . $userId . "'";
		$datas = $this->conn->prepare($sql);
		$datas->execute();

		if ($data = $datas->fetch(PDO::FETCH_ASSOC)) {
			return true;
		}

		$this->logoutUser();

		return false;
	}

	public function getUserByIDPass($userId, $password)
	{
		if ($userId == null)
			$userId = $_SESSION[$this->sessionName]["userId"];

		$sql = "SELECT TOP 1 UserID FROM tbl_Users WHERE UserID='" . $userId . "' AND Password=CONVERT(VARCHAR(32), HashBytes('MD5', '" . $password . "'), 2)";
		$datas = $this->conn->prepare($sql);
		$datas->execute();

		if ($data = $datas->fetch(PDO::FETCH_ASSOC)) {
			$user["userId"] = $data["UserID"];
			return $user;
		}
		return false;
	}

	public function updateUser($userId, $password, $role)
	{
		$sql = "UPDATE tbl_Users SET Password = CONVERT(VARCHAR(32), HashBytes('MD5', '" . $password . "'), 2), UserRole = '" . $role . "' WHERE UserID='" . $userId . "'";
		$datas = $this->conn->prepare($sql);
		$datas->execute();
		return;
	}

	public function getListDT($search, $offset, $size)
	{
		$sql = "SELECT `id`, `trans_date`, `sup_name`, `material_name`, `sup_lot`, `qty`, `unit`, `certificate_no`, `rcv_date`, `insp_date`, `ex_date`, `insp_name`, `insp_result`, `remarks`FROM `t_incoming` WHERE LOWER(id) AND LOWER (material_name) LIKE '%" . strtolower($search) . "%' ORDER BY id ASC";
		$datas = $this->conn->prepare($sql);
		$datas->execute();

		$rack = array();

		$i = 0;
		while ($data = $datas->fetch(PDO::FETCH_ASSOC)) {
			// $rack[$i][0] = $data["id"];
			$rack[$i][0] = $data["id"];
			$rack[$i][1] = $data["trans_date"];
			$rack[$i][2] = $data["sup_name"];
			$rack[$i][3] = $data["material_name"];
			$rack[$i][4] = $data["sup_lot"];
			$rack[$i][5] = $data["qty"];
			$rack[$i][6] = $data["unit"];
			$rack[$i][7] = $data["certificate_no"];
			$rack[$i][8] = $data["rcv_date"];
			$rack[$i][9] = $data["insp_date"];
			$rack[$i][10] = $data["ex_date"];
			$rack[$i][11] = $data["insp_name"];
			$rack[$i][12] = $data["insp_result"];
			$rack[$i][13] = $data["remarks"];
			$rack[$i][16] = $data['id'] . "*" . $data['trans_date'] . "*" . $data['sup_name'] . "*" . $data['material_name'] . "*" . $data['sup_lot'] . "*" . $data['qty'] . "*" . $data['unit'] . "*" . $data['certificate_no'] . "*" . $data['rcv_date'] . "*" . $data['insp_date'] . "*" . $data['ex_date'] . "*" . $data['insp_name']. "*" . $data['insp_result']. "*" . $data['remarks'];
			$i++;
		}

		return $rack;
	}

	public function getSizeDT($search)
	{
		$sql = "SELECT `id`,`trans_date`, `sup_name`, `material_name`, `sup_lot`, `qty`, `unit`, `certificate_no`, `rcv_date`, `insp_date`, `ex_date`, `insp_name`, `insp_result`,`remarks` FROM `t_incoming` WHERE LOWER(id) AND LOWER (material_name) LIKE '%" . strtolower($search) . "%' ORDER BY id ASC";
		$datas = $this->conn->prepare($sql);
		$datas->execute();

		$rack = array();

		$i = 0;
		while ($data = $datas->fetch(PDO::FETCH_ASSOC)) {
			$i++;
		}

		return $i;
	}

	public function generate($length = 5)
	{
		$characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$charactersLength = strlen($characters);
		$randomString = '';
		for ($i = 0; $i < $length; $i++) {
			$randomString .= $characters[rand(0, $charactersLength - 1)];
		}
		return $randomString;
	}
}
