<?php
require('../dbcon.php');


header('Content-Type: application/json');
$response = array();


if (isset($_POST['data'])) {
	$json = json_decode($_POST['data']);
	if ($json->operation == "create-data") {
		$material_id = generate();
		$material_name = $json->material_name;
		$cust_lot = $json->cust_lot;
		$ex_date = $json->ex_date;
		$rcv_date = $json->rcv_date;
		$qty = $json->qty;
		$insp_no = $json->insp_no;
		$inspector = $json->inspector;

		if (!check_data($material_name)) {
			create_data($material_id, $material_name, $cust_lot, $ex_date, $rcv_date, $qty, $insp_no, $inspector);
			$response['success'] = true;
			$response['message'] = "Success";
		} else {
			$response['success'] = false;
			$response['message'] = "Material  already exists.";
		}
	} else if ($json->operation == "update-data") {
		update_data($json->material_id, $json->material_name, $json->cust_lot, $json->ex_date, $json->rcv_date, $json->qty, $json->insp_no, $json->inspector);
		$response['success'] = true;
		$response['message'] = "Data Berhasil di Update";
	} else if ($json->operation == "delete-data") {
		delete_data($json->material_id);
		$response['success'] = true;
		$response['message'] = "User Deleted";
	}

	echo json_encode($response);
} else {
	$response['success'] = false;
}




function check_data($material_name)
{

	require('../dbcon.php');
	$sql = $conn->prepare("SELECT material_name FROM t_mixing WHERE material_name = ?");
	$sql->execute([$material_name]);

	if ($sql->rowCount() > 0) {
		return true;
	} else {
		return false;
	}
}


function create_data($material_id, $material_name, $cust_lot, $ex_date, $rcv_date, $qty, $insp_no, $inspector)
{
	require('../dbcon.php');
	$sql = "INSERT INTO t_mixing (material_id, material_name, cust_lot, ex_date, rcv_date, qty, insp_no, inspector) VALUES (?,?,?,?,?,?,?,?)";
	$stmt = $conn->prepare($sql);
	$stmt->execute([$material_id, $material_name, $cust_lot, $ex_date, $rcv_date, $qty, $insp_no, $inspector]);
}

function update_data($material_id, $material_name, $cust_lot, $ex_date, $rcv_date, $qty, $insp_no, $inspector)
{
	require('../dbcon.php');
	
	$sql = "UPDATE `t_mixing` SET `material_name`=?, `cust_lot`=?, `ex_date`=?,`rcv_date`=?, `qty`=?, `insp_no`=?, `inspector`=? WHERE `material_id`=?";
	$stmt = $conn->prepare($sql);
	$stmt->execute([$material_name, $cust_lot, $ex_date, $rcv_date, $qty, $insp_no, $inspector, $material_id]);
}

function delete_data($material_id)
{
	require('../dbcon.php');
	$sql = "DELETE FROM t_mixing WHERE material_id=?";
	$stmt = $conn->prepare($sql);
	$stmt->execute([$material_id]);
}

function generate($length = 5)
{
	$characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
	$charactersLength = strlen($characters);
	$randomString = '';
	for ($i = 0; $i < $length; $i++) {
		$randomString .= $characters[rand(0, $charactersLength - 1)];
	}
	return $randomString;
}
