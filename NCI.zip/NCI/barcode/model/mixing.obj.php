<?php




class Mixing

{
    private $conn;

    public function __construct()
    {
        $host = "localhost";
        $dbname = "db_nci";
        $username = "root";
        $password = "";


        try {
            $this->conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
        } catch (PDOException $pe) {
            die("Could not connect to the database $dbname :" . $pe->getMessage());
        }
    }


    public function getListDT($search, $offset, $size)
    {

        require('../dbcon.php');

        $sql = "SELECT `material_id`, `material_name`, `cust_lot`, `ex_date`, `rcv_date`, `qty`, `insp_no`, `inspector` FROM `t_mixing` WHERE LOWER (`material_name`) LIKE '%" . strtolower($search) . "%' ORDER BY `material_name` ASC";
        $datas = $this->conn->prepare($sql);
        $datas->execute();
        $rack = array();
        $i = 0;
        while ($data = $datas->fetch(PDO::FETCH_ASSOC)) {
            $rack[$i][0] = $data["material_id"];
            $rack[$i][1] = $data["material_name"];
            $rack[$i][2] = $data["cust_lot"];
            $rack[$i][3] = $data["ex_date"];
            $rack[$i][4] = $data["rcv_date"];
            $rack[$i][5] = $data["qty"];
            $rack[$i][6] = $data["insp_no"];
            $rack[$i][7] = $data["inspector"];
            $rack[$i][10] = $data['material_name'] . "*" . $data['cust_lot'] . "*" . $data['ex_date'] . "*" . $data['rcv_date'] . "*" . $data['qty'] . "*" . $data['insp_no'] . "*" . $data['inspector'];
            $i++;
        }

        return $rack;
    }

    public function getSizeDT($search)
    {
        $datas = $this->conn->prepare("SELECT  material_id, material_name, cust_lot, ex_date, rcv_date, qty, insp_no, inspector FROM t_mixing WHERE LOWER(material_name) LIKE '%" . strtolower($search) . "%' ORDER BY material_name ASC");

        $datas->execute();

        $rack = array();

        $i = 0;
        while ($data = $datas->fetch()) {
            $i++;
        }

        return $i;
    }

    public function generate($length = 5)
    {
        $characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }

}
