<?php
require('../dbcon.php');

header('Content-Type: application/json');
$response = array();


if (isset($_POST['data'])) {
	$json = json_decode($_POST['data']);
	if ($json->operation == "create-data") {
		// $id = generate();
		$mppr_id = $json->mppr_id;
		$mpqc_id = $json->mpqc_id;
		$time_start = $json->time_start;
		$time_finish = $json->time_finish;
		$qty_in = $json->qty_in;
		$qty_out = $json->qty_out;
		$eq_using = $json->eq_using;
		$lmt_info = $json->lmt_info;

		if (!check_data($mppr_id)) {
			create_data($mppr_id, $mpqc_id, $time_start,$time_finish, $qty_in,	$qty_out, $eq_using, $lmt_info);
			$response['success'] = true;
			$response['message'] = "Success";
		} else {
			$response['success'] = false;
			$response['message'] = "Material ID already exists.";
		}
	} else if ($json->operation == "update-data") {
		update_data( $json->mppr_id, $json->mpqc_id,  $json->time_start, $json->time_finish, $json->qty_in, $json->qty_out, $json->eq_using,$json->lmt_info);
		$response['success'] = true;
		$response['message'] = "Data Berhasil di Update";
	} else if ($json->operation == "delete-data") {
		delete_data($json->id);
		$response['success'] = true;
		$response['message'] = "Data berhasil di hapus";
	}

	echo json_encode($response);
} else {
	$response['success'] = false;
}




function check_data($mppr_id)
{
	require('../dbcon.php');
	return;
	$sql = "SELECT TOP 1 mppr_id FROM t_laminate WHERE mppr_id=?";
	$stmt = $conn->prepare($sql);
	$stmt->execute([$mppr_id]);
	if ($data = $stmt->fetch(PDO::FETCH_ASSOC)) {
		return true;
	} else {
		return false;
	}
}


function create_data($mppr_id, $mpqc_id, $time_start,$time_finish, $qty_in,	$qty_out, $eq_using, $lmt_info)
{
	require('../dbcon.php');
	$sql = "INSERT INTO t_laminate ( mppr_id, mpqc_id, time_start, time_finish, qty_in, qty_out, eq_using, lmt_info) VALUES (?,?,?,?,?,?,?,?)";
	$stmt = $conn->prepare($sql);
	$stmt->execute([$mppr_id, $mpqc_id, $time_start,$time_finish, $qty_in,	$qty_out, $eq_using, $lmt_info]);
}

function update_data($mppr_id, $mpqc_id, $time_start,$time_finish, $qty_in,	$qty_out, $eq_using, $lmt_info)
{
	require('../dbcon.php');
	$sql = "UPDATE `t_laminate`  SET `mpqc_id`=?, `time_start`=?, `time_finish`=?, `qty_in`=?, `qty_out`=?, `eq_using`=?, `lmt_info`=? WHERE `mppr_id`=?";
	$stmt = $conn->prepare($sql);
	$stmt->execute([ $mpqc_id, $time_start,$time_finish, $qty_in, $qty_out, $eq_using, $lmt_info, $mppr_id]);
}

function delete_data($mppr_id)
{
	require('../dbcon.php');
	$sql = "DELETE FROM t_laminate WHERE mmpr_id=?";
	$stmt = $conn->prepare($sql);
	$stmt->execute([$mppr_id]);
}


function generate($length = 5)
{
	$characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
	$charactersLength = strlen($characters);
	$randomString = '';
	for ($i = 0; $i < $length; $i++) {
		$randomString .= $characters[rand(0, $charactersLength - 1)];
	}
	return $randomString;
}
