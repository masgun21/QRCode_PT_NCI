<!DOCTYPE html>
<html>
<head>
    <title>How to get Selected Checkbox Text and Value in jQuery</title>
</head>
<body>
    <section>
        <form action="/">
            <fieldset>
                <legend>Skillset: </legend>
                <label for="HTML">HTML5</label>
                <input type="checkbox" name="skillset" value="HTML" />
                <label for="CSS">CSS3</label>
                <input type="checkbox" name="skillset" value="CSS" />
                <label for="JavaScript">JS</label>
                <input type="checkbox" name="skillset" value="JavaScript" />
                <label for="jquery">jquery3.6</label>
                <input type="checkbox" name="skillset" value="jquery" />
            </fieldset>
            <br>
            <fieldset>
                <legend>Preferred Interview Location </legend>
                <label for="Kolkata">KOL</label>
                <input type="checkbox" name="location" value="Kolkata" />
                <label for="Bhubaneshwar">BBS</label>
                <input type="checkbox" name="location" value="Bhubaneshwar" />
                <label for="Bangalore">BLR</label>
                <input type="checkbox" name="location" value="Bangalore" />
                <label for="Pune">PUN</label>
                <input type="checkbox" name="location" value="Pune" />
            </fieldset>
        </form>
    </section>
    </br>
    <button class="demo" id="skillset" value="submit">Get skillset</button>
    <button class="demo" id="location" value="submit">Get location</button>
</body>
</html>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script>
    $(document).ready(function () {
        $('#skillset').click(function () {
            const CheckboxChecked = $('input[name="skillset"]:checked').length;
            console.log(`Total ${CheckboxChecked} checkboxes are checked`);
            $('input[name="skillset"]:checked').each(function () {
                let value = $(this).val();
                let checkboxText = $(`label[for="${value}"]`).text();
                console.log(`Checkbox value is ${value}`);
                console.log(`Check box text is ${checkboxText}`);

            })
        });
        $('#location').click(function () {
            const CheckboxChecked = $('input[name="location"]:checked').length;
            console.log(`Total ${CheckboxChecked} checkboxes are checked`);
            $('input[name="location"]:checked').each(function () {
                let value = $(this).val();
                let checkboxText = $(`label[for="${value}"]`).text();
                console.log(`Checkbox value is ${value}`);
                console.log(`Check box text is ${checkboxText}`);
            })
        });
    });
</script>