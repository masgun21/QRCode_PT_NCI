<?php
include('active-session.php');
?>
<!doctype html>
<html lang="en">

<head>
    <title>PT. NCI Indonesia</title>
    <?php include 'include/header.php'; ?>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>

    <div class="modal fade" id="createUserModal" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title" id="myModalLabel">Create Data Laminate</h4>
                </div>
                <div class="modal-body">
                    <form role="form" class="form-horizontal">
                        <fieldset>
                            <div class="form-group">
                                <label class="control-label col-sm-2">Man Power PR-ID</label>
                                <div class="col-sm-10">
                                    <input class="form-control" placeholder="Man Power PR-ID" name="mppr_id" id="cr_mppr_id" autofocus>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2">Man Power PR-QC</label>
                                <div class="col-sm-10">
                                    <input class="form-control" placeholder="Man Power PR-QC" name="mpqc_id" id="cr_mpqc_id" autofocus>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2">Start Time</label>
                                <div class="col-sm-10">
                                    <input class="form-control" type="time" name="time_start" id="cr_time_start" autofocus>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2">Finish Time</label>
                                <div class="col-sm-10">
                                    <input class="form-control" type="time" name="time_finish" id="cr_time_finish" autofocus>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2">Qty In</label>
                                <div class="col-sm-10">
                                    <input class="form-control" placeholder="Qty In" name="qty_in" id="cr_qty_in" autofocus>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2">Qty Out</label>
                                <div class="col-sm-10">
                                    <input class="form-control" placeholder="Qty Out" name="qty_out" id="cr_qty_out" autofocus>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2">Equipment Using</label>
                                <div class="col-sm-10">
                                    <input class="form-control" placeholder="Equipment Using" name="eq_using" id="cr_eq_using" autofocus>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2">Laminate Information</label>
                                <div class="col-sm-10">
                                    <input class="form-control" placeholder="Laminate Information" name="lmt_info" id="cr_lmt_info" autofocus>
                                </div>
                            </div>
                        </fieldset>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-fill btn-warning" data-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-fill btn-danger" id="create-btn">Create</button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="updateUserModal" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title" id="myModalLabel">Update Data Laminate</h4>
                </div>
                <div class="modal-body">
                    <form role="form" class="form-horizontal">
                        <fieldset>
                            <div class="form-group">
                                <label class="control-label col-sm-2">Man Power PR-ID</label>
                                <div class="col-sm-10">
                                    <input class="form-control" placeholder="Man Power PR-ID" name="mppr_id" id="up_mppr_id" autofocus>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2">Man Power PR-QC</label>
                                <div class="col-sm-10">
                                    <input class="form-control" placeholder="Man Power PR-QC" name="mpqc_id" id="up_mpqc_id" autofocus>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2">Start Time</label>
                                <div class="col-sm-10">
                                    <input class="form-control" type="time" name="time_start" id="up_time_start" autofocus>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2">Finish Time</label>
                                <div class="col-sm-10">
                                    <input class="form-control" type="time" name="time_finish" id="up_time_finish" autofocus>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2">Qty In</label>
                                <div class="col-sm-10">
                                    <input class="form-control" placeholder="Qty In" name="qty_in" id="up_qty_in" autofocus>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2">Qty Out</label>
                                <div class="col-sm-10">
                                    <input class="form-control" placeholder="Qty Out" name="qty_out" id="up_qty_out" autofocus>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2">Equipment Using</label>
                                <div class="col-sm-10">
                                    <input class="form-control" placeholder="Equipment Using" name="eq_using" id="up_eq_using" autofocus>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2">Laminate Information</label>
                                <div class="col-sm-10">
                                    <input class="form-control" placeholder="Laminate Information" name="lmt_info" id="up_lmt_info" autofocus>
                                </div>
                            </div>
                        </fieldset>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-fill btn-warning" data-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-fill btn-danger" id="save-btn">Save</button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="deleteUserModal" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title" id="myModalLabel">Delete Data</h4>
                </div>
                <div class="modal-body">
                    <p>Are you sure wants to delete Data? <strong><span id="deleteUserId"></span></strong>?</p>
                    <input type="hidden" name="de_id" id="de_id" value="">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-fill btn-warning" data-dismiss="modal">No</button>
                    <button type="button" class="btn btn-fill btn-danger" id="yes-btn">Yes</button>
                </div>
            </div>
        </div>
    </div>

    <div class="wrapper">
        <?php $menu = 2; ?>
        <?php include 'include/navigation.php'; ?>

        <div class="main-panel">
            <nav class="navbar navbar-default navbar-fixed">
                <div class="container-fluid">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation-example-2">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <a class="navbar-brand" href="#"></a>
                    </div>
                    <?php include 'include/navbar.php'; ?>
                </div>
            </nav>

            <div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="header">
                                    <h4 class="title">Data Barcode Laminate</h4>
                                    <p class="category">List Data Barcode Laminate</p>
                                </div>
                                <div class="content">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <button type="button" class="btn btn-fill btn-info" onclick="showCreateModal();">
                                                Input Data Laminate
                                            </button>
                                          
                                            <div class="content table-responsive table-full-width">
                                                <table id="table" class="table table-hover table-striped">
                                                    <thead>
                                                        <tr>
                                                            <th>Man Power PR-ID</th>
                                                            <th>Man Power QC-ID</th>
                                                            <th>Start Pengerjaan</th>
                                                            <th>Finish Pengerjaan</th>
                                                            <th>Qty In</th>
                                                            <th>Qty Out</th>
                                                            <th>Equipment Using</th>
                                                            <th>Laminate Information</th>
                                                            <th>Edit</th>
                                                            <th>Delete</th>
                                                        </tr>
                                                    </thead>
                                                    <!-- <tbody id="table_pick_body">
                                                    </tbody> -->
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <?php include 'include/content-footer.php'; ?>
        </div>
    </div>
</body>
<?php include 'include/footer.php'; ?>
<script type="text/javascript">
    var elem = [];

    // function print(data) {
    //     window.location.assign('print_qr_inspection.php?data=' + data);
    //     console.log(myTrim(data));
    // }

    function myTrim(x) {
        return x.replace(/^\s+|\s+$/gm, '');
    }
    $(document).ready(function() {
        $('#table').DataTable({
            "processing": true,
            "serverSide": true,
            "ajax": "api/laminate.php",
            "columnDefs": [

                {
                    "render": function(data, type, row) {
                        var html = '<button type="button" onClick="showUpdateModal(\'' + row[0] + '\',\'' + row[1] + '\',\'' + row[2] + '\', \'' + row[3] + '\', \'' + row[4] + '\', \'' + row[5] + '\', \'' + row[6] + '\',  \'' + row[7] + '\',  \'' + row[8] + '\');" class="hand btn btn-icon btn-fill waves-effect waves-light btn-info btn-xs"><i class="pe-7s-speaker"></i></span>';
                        return html;
                    },
                    "targets": 7
                },

                {
                    "render": function(data, type, row) {
                        var html = '<button type="button" onClick="showUpdateModal(\'' + row[0] + '\',\'' + row[1] + '\',\'' + row[2] + '\', \'' + row[3] + '\', \'' + row[4] + '\', \'' + row[5] + '\', \'' + row[6] + '\',  \'' + row[7] + '\',  \'' + row[8] + '\');" class="hand btn btn-icon btn-fill waves-effect waves-light btn-warning btn-xs"><i class="pe-7s-pen"></i></span>';
                        return html;
                    },
                    "targets": 8
                },

                {
                    "render": function(data, type, row) {
                        var html = '<button type="button" onClick="showDeleteModal(\'' + row[1] + '\');" class="hand btn btn-icon btn-fill waves-effect waves-light btn-danger btn-xs"><i class="pe-7s-trash"></i></span>';
                        return html;
                    },
                    "targets": 9
                },
                // {
                //     "render": function(data, type, row) {
                //         var html = '<button type="button" class="hand btn btn-icon btn-fill waves-effect waves-light btn-default btn-xs" value="' + data + '" onclick="print(this.value)">Add to Print</button>';
                //         return html;
                //     },
                //     "targets": 12
                // },
                // {
                //     "render": function(data, type, row) {
                //         var disabled = 'disbaled';
                //         return '<button id="btn-"  class="hand btn btn-icon btn-fill btn-info waves-effect waves-light btn-default btn-xs" onclick="addToList(\'' + row[11] + '\')">Add to Print</button>'
                //     },
                //     "targets": 11
                // }
            ]
        });

        $("#create-btn").click(function() {
            var data = Object();
            data.operation = "create-data";
            data.mppr_id = $("#cr_mppr_id").val();
            data.mpqc_id = $("#cr_mpqc_id").val();
            data.time_start = $("#cr_time_start").val();
            data.time_finish = $("#cr_time_finish").val();
            data.qty_in = $("#cr_qty_in").val();
            data.qty_out = $("#cr_qty_out").val();
            data.eq_using = $("#cr_eq_using").val();
            data.lmt_info = $("#cr_lmt_info").val();
            var json_data = JSON.stringify(data);
            console.log(data);
            if (data.mppr_id.length == 0) {
                alert("Man Power PR can't be null.");
                return;
            }

            if (data.mpqc_id.length == 0) {
                alert("Man Power PR can't be null.");
                return;
            }

            $.post("model/laminate-script.php", {

                    data: json_data

                },
                function(data, status) {

                    if (data.success) {
                        showNotification('top', 'center', 'success', "Create user successfull.");
                        $('#createUserModal').modal('hide');
                        $('#table').DataTable().ajax.reload();
                    } else {
                        showNotification('top', 'center', 'danger', response.message);
                        $('#createUserModal').modal('hide');
                    }
                });
        });

        $("#save-btn").click(function() {
            var data = Object();
            data.operation = "update-data";
            data.mppr_id = $("#up_mppr_id").val();
            data.mpqc_id = $("#up_mpqc_id").val();
            data.time_start = $("#up_time_start").val();
            data.time_finish = $("#up_time_finish").val();
            data.qty_in = $("#up_qty_in").val();
            data.qty_out = $("#up_qty_out").val();
            data.eq_using = $("#up_eq_using").val();
            data.lmt_info = $("#up_lmt_info").val();
            var json_data = JSON.stringify(data);
            console.log(data);
            if (data.mppr_id.length == 0) {
                alert("Material Name Harus di Isi...!");
                return;
            }

            if (data.mpqc_id.length == 0) {
                alert("Supplier Lot Harus di Isi");
                return;
            }

            $.post("model/laminate-script.php", {

                    data: json_data

                },
                function(data, status) {

                    if (data.success) {
                        showNotification('top', 'center', 'success', "Update user successfull.");
                        $('#updateUserModal').modal('hide');
                        $('#table').DataTable().ajax.reload();
                    } else {
                        showNotification('top', 'center', 'danger', response.message);
                        $('#updateUserModal').modal('hide');
                    }
                });
        });

        $("#yes-btn").click(function() {
            var data = Object();
            data.mppr_id = "delete-data";
            data.id = $("#de_id").val();
            var json_data = JSON.stringify(data);

            $.post("model/laminate-script.php", {

                    data: json_data

                },
                function(data, status) {

                    if (data.success) {
                        showNotification('top', 'center', 'success', "Delete data successfull.");
                        $('#deleteUserModal').modal('hide');
                        $('#table').DataTable().ajax.reload();
                    } else {
                        showNotification('top', 'center', 'danger', response.message);
                        $('#deleteUserModal').modal('hide');
                    }
                });
        });

        $("#btn-print").click(function(item) {
            var data = elem.map(item => `${item.id} * ${item.material_name}`);

            window.location.assign('print_qr_inspection.php?data=' + data.toString(/\s/g, ''));
            console.log(myTrim(data));
            console.log(data)
        });



    });


    function showCreateModal() {
        $('#cr_mppr_id').val("");
        $('#cr_mpqc_id').val("");
        $('#cr_time_start').val("");
        $('#cr_time_finish').val("");
        $('#cr_qty_in').val("");
        $('#cr_qty_out').val("");
        $('#cr_eq_using').val("");
        $('#cr_lmt_info').val("");
        $('#createUserModal').modal('show');
    }

    function showDeleteModal(id) {
        $('#de_id').val(id);
        $('#deleteUserId').html(id);
        $('#deleteUserModal').modal('show');
    }

    function showUpdateModal(mppr_id, mpqc_id, time_start, time_finish, qty_in, qty_out, eq_using, lmt_info) {
        $("#up_mppr_id").val(mppr_id);
        $("#up_mpqc_id").val( mpqc_id);
        $("#up_time_start").val(time_start);
        $("#up_time_finish").val(time_finish);
        $("#up_qty_in").val(qty_in);
        $("#up_qty_out").val(qty_out);
        $("#up_eq_using").val(eq_using);
        $("#up_lmt_info").val(lmt_info);
        $('#updateUserModal').modal('show');
    }

    // function addToList(data, id) {
    //     $("#btn-" + id).prop("disabled", true);
    //     var item = data.split('*');
    //     console.log(item);
    //     var picklist = {};
    //     picklist.id = item[0];
    //     picklist.material_name = item[1];
    //     picklist.sup_lot = item[2];
    //     picklist.qty = item[3];
    //     picklist.rcv_date = item[4];
    //     picklist.inspector = item[5];
    //     picklist.certificate = item[6];
    //     picklist.ex_date = item[7];
    //     picklist.insp_result = item[8];
    //     elem.push(picklist);
    //     console.log(JSON.stringify(elem));
    //     $("#table_pick_body").append("<tr><td>" + item[0] + "</td><td>" + item[1] + "</td><td>" + item[2] + "</td><td>" + item[3] + "</td><td>" + item[4] + "</td><td>" + item[5] + "</td><td>" + item[6] + "</td><td>" + item[7] + "</td><td>" + item[8] + "</td><td><button type='buton' class='hand btn btn-icon btn-fill waves-effect waves-light btn-danger btn-xs'><i class='pe-7s-trash'></i></span></td></tr>");
    //     console.log(elem);



    // }


    // function delete_data() {
    //     window.location.assign('inspection.php');

    // }

    // function print_All_QR() {

    //     // $("#btn-print").click(function() {
    //     //     var data = JSON.stringify(elem);
    //     //     console.log(data);
    //     //     window.location.assign('print_qr_inspection.php?data=' + data);
    //     //     console.log(myTrim(data));
    //     // });

    // }
</script>

</html>