<?php
include('active-session.php');
?>
<!doctype html>
<html lang="en">

<head>
    <title>PT. NCI Indonesia</title>
    <?php include 'include/header.php'; ?>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>

    <div class="modal fade" id="createUserModal" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title" id="myModalLabel">Create Data Incoming</h4>
                </div>
                <div class="modal-body">
                    <form role="form" class="form-horizontal">
                        <fieldset>
                            <div class="form-group">
                                <label class="control-label col-sm-2">Trans Date</label>
                                <div class="col-sm-10">
                                    <input class="form-control" type="date" name="trans_date" id="cr_trans_date" autofocus>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2">Supplier Name</label>
                                <div class="col-sm-10">
                                    <input class="form-control" placeholder="Supplier Name" name="sup_name" id="cr_sup_name" autofocus>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2">Material Name</label>
                                <div class="col-sm-10">
                                    <input class="form-control" placeholder="Material Name" name="material_name" id="cr_material_name" autofocus>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2">Supplier Lot No.</label>
                                <div class="col-sm-10">
                                    <input class="form-control" placeholder="Supplier Lot No." name="sup_lot" id="cr_sup_lot" autofocus>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2">Quantity Lot</label>
                                <div class="col-sm-10">
                                    <input class="form-control" placeholder="Quantity Lot" name="qty" id="cr_qty" autofocus>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2">Unit</label>
                                <div class="col-sm-10">
                                    <input class="form-control" placeholder="Quantity Lot" name="qty" id="cr_unit" autofocus>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2">Certificate No.</label>
                                <div class="col-sm-10">
                                    <input class="form-control" placeholder="Certificate No." name="cartificate" id="cr_certificate" autofocus>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2">Receiving Date</label>
                                <div class="col-sm-10">
                                    <input class="form-control" type="date" name="rcv_date" id="cr_rcv_date" autofocus>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2">Inspection Name</label>
                                <div class="col-sm-10">
                                    <input class="form-control" placeholder="Inspection Name" name="inspection_name" id="cr_inspection_name" autofocus>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2">Inspection Result</label>
                                <div class="col-sm-10">
                                    <input class="form-control" placeholder="Inspection Result" name="inspection_result" id="cr_inspection_result" autofocus>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="control-label col-sm-2">Remarks</label>
                                <div class="col-sm-10">
                                    <input class="form-control" type="date" name="rmarks" id="cr_remaks" autofocus>
                                </div>
                            </div>

                        </fieldset>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-fill btn-warning" data-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-fill btn-danger" id="create-btn">Create</button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="updateUserModal" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title" id="myModalLabel">Update Data Inspection</h4>
                </div>
                <div class="modal-body">
                    <form role="form" class="form-horizontal">
                        <fieldset>
                            <div class="form-group">
                                <label class="control-label col-sm-2">Trans Date</label>
                                <div class="col-sm-10">
                                    <input class="form-control" type="date" name="trans_date" id="up_trans_date" autofocus>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2">Supplier Name</label>
                                <div class="col-sm-10">
                                    <input class="form-control" placeholder="Supplier Name" name="sup_name" id="up_sup_name" autofocus>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2">Material Name</label>
                                <div class="col-sm-10">
                                    <input class="form-control" placeholder="Material Name" name="material_name" id="up_material_name" autofocus>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2">Supplier Lot No.</label>
                                <div class="col-sm-10">
                                    <input class="form-control" placeholder="Supplier Lot No." name="sup_lot" id="up_sup_lot" autofocus>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2">Quantity Lot</label>
                                <div class="col-sm-10">
                                    <input class="form-control" placeholder="Quantity Lot" name="qty" id="up_qty" autofocus>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2">Unit</label>
                                <div class="col-sm-10">
                                    <input class="form-control" placeholder="Quantity Lot" name="qty" id="up_unit" autofocus>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2">Certificate No.</label>
                                <div class="col-sm-10">
                                    <input class="form-control" placeholder="Certificate No." name="cartificate" id="up_certificate" autofocus>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2">Receiving Date</label>
                                <div class="col-sm-10">
                                    <input class="form-control" type="date" name="rcv_date" id="up_rcv_date" autofocus>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2">Inspection Name</label>
                                <div class="col-sm-10">
                                    <input class="form-control" placeholder="Inspection Name" name="inspection_name" id="up_inspection_name" autofocus>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-2">Inspection Result</label>
                                <div class="col-sm-10">
                                    <input class="form-control" placeholder="Inspection Result" name="inspection_result" id="up_inspection_result" autofocus>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="control-label col-sm-2">Remarks</label>
                                <div class="col-sm-10">
                                    <input class="form-control" type="date" name="rmarks" id="up_remaks" autofocus>
                                </div>
                            </div>

                        </fieldset>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-fill btn-warning" data-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-fill btn-danger" id="save-btn">Save</button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="deleteUserModal" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title" id="myModalLabel">Delete Data</h4>
                </div>
                <div class="modal-body">
                    <p>Are you sure wants to delete Data? <strong><span id="deleteUserId"></span></strong>?</p>
                    <input type="hidden" name="de_id" id="de_id" value="">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-fill btn-warning" data-dismiss="modal">No</button>
                    <button type="button" class="btn btn-fill btn-danger" id="yes-btn">Yes</button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="deleteTableModal" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title" id="myModalLabel">Delete Data</h4>
                </div>
                <div class="modal-body">
                    <p>Are you sure wants to delete Data? <strong><span id="deleteModalId"></span></strong>?</p>
                    <input type="hidden" name="del_id" id="del_id" value="">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-fill btn-warning" data-dismiss="modal">No</button>
                    <button type="button" class="btn btn-fill btn-danger" id="yes-btn2">Yes</button>
                </div>
            </div>
        </div>
    </div>

    <div class="wrapper">
        <?php $menu = 2; ?>
        <?php include 'include/navigation.php'; ?>

        <div class="main-panel">
            <nav class="navbar navbar-default navbar-fixed">
                <div class="container-fluid">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation-example-2">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <a class="navbar-brand" href="#"></a>
                    </div>
                    <?php include 'include/navbar.php'; ?>
                </div>
            </nav>

            <div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="header">
                                    <!-- <h4 class="title">Data Barcode Incoming</h4>
                                    <p class="category">List Data Barcode Incoming</p> -->
                                </div>
                                <div class="content">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <!-- <button type="button" class="btn btn-fill btn-info" onclick="showCreateModal();">
                                                Input Data Inspection
                                            </button> -->
                                            <!-- <button type="button" class="btn btn-fill btn-danger" name="deleteAll" value="Delete All">
                                                Delete Checkded Data
                                            </button> -->
                                            <h1>
                                                Data incoming yang akan dibuat barcode : <span id="count">0</span> <span>item</span>
                                            </h1>

                                            <div class="row">
                                                <div class="col-md-12" style="overflow: auto;">
                                                    <table id="table_atas" class="table table-hover table-bordered" style="width: 100%;">
                                                        <thead>
                                                            <tr>
                                                                <th>ID</th>
                                                                <th>Trans. Date</th>
                                                                <th>Supplier Name</th>
                                                                <th>Material Name</th>
                                                                <th>Supplier Lot No.</th>
                                                                <th>Quantity</th>
                                                                <th>Unit</th>
                                                                <th>Certificate No.</th>
                                                                <th>Receiving Date</th>
                                                                <th>Inspection Date</th>
                                                                <th>Expire Date</th>
                                                                <th>Inspection Name</th>
                                                                <th>Inspection Result</th>
                                                                <th>Remarks</th>
                                                                <th>Print Count</th>
                                                                <th>Delete</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody id="table_pick_body">
                                                        </tbody>
                                                    </table>
                                                    <button type="Button" class="btn" id="btn-print" disabled="disabled" style="width: 100%; background: #28a745; color: white; margin-bottom: 1%;">Print QR Code</button>
                                                    <button type="Button" class="btn" id="btn-sendData" style="width: 100%; background: #dc3545; color: white; margin-bottom: 2%;" onclick="delete_data()">Delete All Data</button>

                                                </div>
                                            </div>
                                            <!-- <form action="prosesscan.php" method="post">
                                                <button class="btn btn-fill btn-danger" type="submit">Delete Checkded Data</button>
                                            </form> -->
                                            <div class="content table-responsive table-full-width">
                                                <table id="table" class="table table-hover table-striped">
                                                    <thead>
                                                        <tr>

                                                            <th>ID</th>
                                                            <th>Trans. Date</th>
                                                            <th>Supplier Name</th>
                                                            <th>Material Name</th>
                                                            <th>Supplier Lot No.</th>
                                                            <th>Quantity</th>
                                                            <th>Unit</th>
                                                            <th>Certificate No.</th>
                                                            <th>Receiving Date</th>
                                                            <th>Inspection Date</th>
                                                            <th>Expire Date</th>
                                                            <th>Inspection Name</th>
                                                            <th>Inspection Result</th>
                                                            <th>Remarks</th>
                                                            <!-- <th>Edit</th>
                                                            <th>Delete</th> -->
                                                            <th>QR</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody id="table_pick_body">
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <?php include 'include/content-footer.php'; ?>
        </div>
    </div>
</body>
<?php include 'include/footer.php'; ?>
<script type="text/javascript">
    var elem = [];
    var count = 0;
    // function print(data) {
    //     window.location.assign('print_qr_inspection.php?data=' + data);
    //     console.log(myTrim(data));
    // }

    function myTrim(x) {
        return x.replace(/^\s+|\s+$/gm, '');
    }
    $(document).ready(function() {
        $('#table').DataTable({
            "processing": true,
            "serverSide": true,
            "ajax": "api/incoming.php",
            "columnDefs": [

                {
                    "render": function(data, type, row) {
                        disabled = "disabled"
                        return '<button id="btn-"   class="hand btn btn-icon btn-fill btn-info waves-effect waves-light btn-default btn-xs" onclick="addToList(\'' + row[16] + '\')">Add to Print</button>'
                    },
                    "targets": 14
                }
            ]
        });

        $("#create-btn").click(function() {
            var data = Object();
            data.operation = "create-data";
            data.trans_date = $("#cr_trans_date").val();
            data.sup_name = $("#cr_sup_name").val();
            data.material_name = $("#cr_material_name").val();
            data.sup_lot = $("#cr_sup_lot").val();
            data.qty = $("#cr_qty").val();
            data.rcv_date = $("#cr_rcv_date").val();
            data.inspector = $("#cr_inspector").val();
            data.certificate = $("#cr_certificate").val();
            data.ex_date = $("#cr_ex_date").val();
            data.insp_result = $("#cr_insp_result").val();
            var json_data = JSON.stringify(data);
            console.log(data);
            if (data.material_name.length == 0) {
                alert("Material Name can't be null.");
                return;
            }

            if (data.sup_lot.length == 0) {
                alert("Item Code can't be null.");
                return;
            }

            $.post("model/inspection-script.php", {

                    data: json_data

                },
                function(data, status) {

                    if (data.success) {
                        showNotification('top', 'center', 'success', "Create user successfull.");
                        $('#createUserModal').modal('hide');
                        $('#table').DataTable().ajax.reload();
                    } else {
                        showNotification('top', 'center', 'danger', response.message);
                        $('#createUserModal').modal('hide');
                    }
                });
        });

        $("#save-btn").click(function() {
            var data = Object();
            data.operation = "update-data";
            data.id = $("#up_material_id").val();
            data.material_name = $("#up_material_name").val();
            data.sup_lot = $("#up_sup_lot").val();
            data.qty = $("#up_qty").val();
            data.rcv_date = $("#up_rcv_date").val();
            data.inspector = $("#up_inspector").val();
            data.certificate = $("#up_certificate").val();
            data.ex_date = $("#up_ex_date").val();
            data.insp_result = $("#up_insp_result").val();
            var json_data = JSON.stringify(data);
            console.log(data);
            if (data.material_name.length == 0) {
                alert("Material Name Harus di Isi...!");
                return;
            }

            if (data.sup_lot.length == 0) {
                alert("Supplier Lot Harus di Isi");
                return;
            }

            $.post("model/incoming-script.php", {

                    data: json_data

                },
                function(data, status) {

                    if (data.success) {
                        showNotification('top', 'center', 'success', "Update user successfull.");
                        $('#updateUserModal').modal('hide');
                        $('#table').DataTable().ajax.reload();
                    } else {
                        showNotification('top', 'center', 'danger', response.message);
                        $('#updateUserModal').modal('hide');
                    }
                });
        });

        $("#yes-btn").click(function() {
            var data = Object();
            data.operation = "delete-data";
            data.id = $("#de_id").val();
            var json_data = JSON.stringify(data);

            $.post("model/incoming-script.php", {

                    data: json_data

                },
                function(data, status) {

                    if (data.success) {
                        showNotification('top', 'center', 'success', "Delete data successfull.");
                        $('#deleteUserModal').modal('hide');
                        $('#table').DataTable().ajax.reload();
                    } else {
                        showNotification('top', 'center', 'danger', response.message);
                        $('#deleteUserModal').modal('hide');
                    }
                });
        });

        $("#btn-print").click(function() {
            $(this).prop('disabled', true);
            var printCounts = [];
            var incoming = "INCOMING"; // Modify this line to change the incoming text
            $("#table_pick_body input[type='number']").each(function() {
                var printCount = parseInt($(this).val());
                printCounts.push(printCount);
            });
            var data = elem.map((item, index) => `${item.id} * ${item.sup_lot} * ${printCounts[index]}`);
            // Encode the data and append it to the URL
            var encodedData = encodeURIComponent(data.join(';'));
            var url = 'print_qr_inspection.php?data=' + encodedData;

            // Redirect to the URL
            window.location.assign(url);
            console.log(data);
        });

    });


    function showCreateModal() {
        $('#cr_material_name').val("");
        $('#cr_sup_lot').val("");
        $('#cr_qty').val("");
        $('#cr_rcv_date').val("");
        $('#cr_inspector').val("");
        $('#cr_certificate').val("");
        $('#cr_ex_date').val("");
        $('#cr_insp_result').val("");
        $('#createUserModal').modal('show');
    }

    function showDeleteModal(id) {
        $('#de_id').val(id);
        $('#deleteUserId').html(id);
        $('#deleteUserModal').modal('show');
    }

    function showUpdateModal(id, material_name, sup_lot, qty, rcv_date, inspector, certificate, ex_date, insp_result) {
        $("#up_material_id").val(id);
        $("#up_material_name").val(material_name);
        $("#up_sup_lot").val(sup_lot);
        $("#up_qty").val(qty);
        $("#up_rcv_date").val(rcv_date);
        $("#up_inspector").val(inspector);
        $("#up_certificate").val(certificate);
        $("#up_ex_date").val(ex_date);
        $("#up_insp_result").val(insp_result);
        $('#updateUserModal').modal('show');
    }

    function addToList(data, id) {

        var item = data.split('*');
        console.log(item);
        var picklist = {};
        picklist.id = item[0];
        picklist.trans_date = item[1];
        picklist.sup_name = item[2];
        picklist.material_name = item[3];
        picklist.sup_lot = item[4];
        picklist.qty = item[5];
        picklist.unit = item[6];
        picklist.certificate_no = item[7];
        picklist.rcv_date = item[8];
        picklist.insp_date = item[9];
        picklist.ex_date = item[10];
        picklist.insp_name = item[11];
        picklist.insp_result = item[12];
        picklist.remarks = item[13];
        elem.push(picklist);
        console.log(JSON.stringify(elem));
        $("#table_pick_body").append("<tr><td>" + item[0] + "</td><td>" + item[1] + "</td><td>" + item[2] + "</td><td>" + item[3] + "</td><td>" + item[4] + "</td><td>" + item[5] + "</td><td>" + item[6] + "</td><td>" + item[7] + "</td><td>" + item[8] + "</td><td>" + item[9] + "</td><td>" + item[10] + "</td><td>" + item[11] + "</td><td>" + item[12] + "</td><td>" + item[13] + "</td><td><input type='number' id='print_count' />" + "</td><td><button type='buton' onClick='deleteButton()' class='hand btn btn-icon btn-fill waves-effect waves-light btn-danger btn-xs'><i class='pe-7s-trash'></i></span></td></tr>");
        console.log(elem);




    }

    function delete_data() {
        window.location.assign('incoming.php');

    }

    function deleteButton() {
        count--;
        $('#count').text(count);
        $("#table_atas tr").on("click", function() {
            var deletedId = $(this).attr("id"); // Get the ID of the deleted row
            $(this).remove();
            enableButtonById(deletedId); // Enable button with the corresponding ID
            enableButtonsInOrder(); // Enable buttons in order
        });
    }

    $('#table').on('click', '#btn-', function() {
        count++;
        $('#count').text(count);

        $("#btn-").each(function(index) {
            $(this).prop("disabled", true);
        });

        if (count > 0) {
            $("#btn-print").prop("disabled", false);
            enableButtonsInOrder(); // Enable buttons in order if count is greater than zero
            $(this).prop("disabled", true);
        } else {
            enableAllButtons(); // Enable all buttons with ID "btn-" if count is zero
        }
    });

    function enableButtonsInOrder() {
        var buttons = $("#table_atas tr button[id^='btn-']"); // Select buttons within the table row
        buttons.each(function(index) {
            $(this).prop("disabled", index >= count); // Enable buttons based on the count
        });
    }

    function enableButtonById(id) {
        var button = $("#" + id).find("button[id^='btn-']"); // Find the button with the ID "btn-" within the element with the corresponding ID
        button.prop("disabled", false); // Enable the button
    }

    function enableAllButtons() {
        var buttons = $("#table_atas tr button[id^='btn-']"); // Select buttons within the table row
        buttons.prop("disabled", false); // Enable all buttons with ID "btn-"
    }
</script>

</html>