<?php

// $serverName = "DESKTOP-PH6BS4I\SQLEXPRESS";
// $db_name = "DBJKT";
// $conn = "";


$host = "localhost";
$dbname = "db_nci";
$username = "root";
$password = "";
$conn = "";

try {
	$conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
	$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	} catch (PDOException $pe) {
	die ("Could not connect to the database $dbname :" . $pe->getMessage());
	}
//1008884593 - scanned
//T000003044943 not scanned

?>

