<?php
/* session_start();

include "dbcon.php";

$username = $_POST["username"];
$p = md5($_POST["password"]);

$sql = "select * from tbl_users where username='".$username."' and password='".$p."' limit 1";
$hasil = mysqli_query ($conn,$sql);
$jumlah = mysqli_num_rows($hasil);


	if ($jumlah>0) {
		$row = mysqli_fetch_assoc($hasil);
		$_SESSION["user_id"]=$row["user_id"];
		$_SESSION["username"]=$row["username"];
		$_SESSION["role"]=$row["role"];

	

		header("Location:dashboard.php");
		
	}else {
		echo "Username atau password salah <br><a href='index.php'>Kembali</a>";
	} */
?>

<?php
include('dbcon.php');

session_start();
if(isset($_POST['username']) && isset($_POST['pw'])){
    $username = $_POST['username'];
    $pw = $_POST['pw'];
    $pw = md5($pw);

    $sql = "SELECT * FROM tbl_users WHERE username=? AND password=? AND role='ADMIN'";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$username, $pw]);

    if($row = $stmt->fetch(PDO::FETCH_ASSOC)){
        $_SESSION['userId'] = $row['user_id'];
        header('location:incoming.php?id='.md5($_SESSION['userId']));
    } else {
        header('location:index.php?error=invalid_credentials');
        $error = "Invalid Crendetials";
    }
}

?>