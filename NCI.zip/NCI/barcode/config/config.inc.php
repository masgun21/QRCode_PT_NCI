<?php

	/**
	* Configuration file
	*
	* This should be the only file you need to edit in, regarding the original script.
	* Please provide your MySQL login information below.
	*/
	$GLOBALS["db_server_name"] = "localhost";
	// $GLOBALS["db_server_name"] = "ACCOUNTING";
	// $GLOBALS["db_server_name"] = "DESKTOP-PDTK3V8\SQLEXPRESS";
	$GLOBALS["db_name"] = "db_nci";
	$GLOBALS["uname"] = "";
	$GLOBALS["pword"] = "";
	// $GLOBALS["mysql_hostname"] = "localhost";
	// $GLOBALS["mysql_username"] = "root";
	// $GLOBALS["mysql_password"] = "root";
	// $GLOBALS["mysql_database"] = "DaihoQRScanner";
	// $GLOBALS["mysql_port"] = 3306;

	/* Production */
	/*
	$GLOBALS["mysql_hostname"] = "appxmartdb";
	$GLOBALS["mysql_username"] = "test_user";
	$GLOBALS["mysql_password"] = "xM4rt_Test_";
	$GLOBALS["mysql_database"] = "DaihoQRScanner";
	$GLOBALS["mysql_port"] = 3306;
	*/

?>