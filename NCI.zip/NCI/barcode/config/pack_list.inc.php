<?php

	$path = dirname(__FILE__);

	include($path."/config.inc.php");
  include($path."/../model/pack_list.obj.php");
    


?>