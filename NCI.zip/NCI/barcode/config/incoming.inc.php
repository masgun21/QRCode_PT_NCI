<?php

	$path = dirname(__FILE__);

	include($path."/config.inc.php");
	// include($path."/../model/users.obj.php");
	// include($path."/../model/mixing.obj.php");
	include($path."/../model/incoming.obj.php");

?>