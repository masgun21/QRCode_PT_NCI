<?php

if(isset($_GET['ref'])){
    require_once("../config/pack_list.inc.php");
    require_once("../config/material.inc.php");
    require_once("../active-session.php");
    $packlist = new PACK_LIST();
    $matl = new MATERIAL();
    $header = $packlist->fetch_header($_GET['ref']);
    $items = $packlist->fetch_items($_GET['ref']);
    $supplier_name = $matl->GET_SUPPLIER_NAME($header['SENDER']);
}


?>

<style>
@media print
{    
    .no-print, .no-print *
    {
        display: none !important;
    }
}

#qrcode img  {
    padding-left: 48%;
}
</style>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="../assets/img/daiho.ico">


    <title>REF ITEMS</title>
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet">
    <script src="../assets/js/jquery.3.2.1.min.js"></script>
    <script src="../assets/js/bootstrap.min.js"></script>
    <script src="../assets/js/qrcode.min.js"></script>

  </head>

    <!-- Modal -->
    <div class="modal fade" id="print_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
        <div class="modal-header">
            <h4 class="modal-title text-center" id="exampleModalLabel">PRINT TAG SHEET</h4>
        </div>
        <div class="modal-body">
            <div class="form-group">
                <label>
                    Receive #
                </label>
                <input type="text" class="form-control" id="p_rcv" disabled/>
            </div>
            <div class="form-group">
                <label>
                    Material Code
                </label>
                <input type="text" class="form-control" id="p_code" disabled/>
            </div>
            <div class="form-group">
                <label>
                    Manufacturing Item
                </label>
                <input type="text" class="form-control" id="p_manuf" disabled/>
            </div>
            <div class="form-group">
                <label>
                    Lot No
                </label>
                <input type="text" class="form-control" id="p_lot" disabled/>
            </div>
            <div class="form-group">
                <label>
                    Available QTY
                </label>
                <input type="text" class="form-control" id="p_qty" disabled/>
            </div>
            <div class="form-group">
                <label>
                    Tag Sheet Count (PCS)
                </label>
                <input type="number" placeholder="1, 2, 3.." class="form-control" id="p_count"/>
            </div>
            <div class="form-group">
                <label>
                    Per Palette QTY (Kg)
                </label>
                <input type="number" placeholder="500, 1000, 1500.." class="form-control" id="p_palette"/>
            </div>

            <!-- hidden -->
            <input type="hidden" id="p_id_string"/>


            
        </div>
        <div class="modal-footer">
            <button type="button" class='btn btn-success' onclick="print_tagsheet(p_rcv.value, p_code.value, p_lot.value, p_qty.value, p_palette.value, p_count.value, p_manuf.value);">PRINT</button>
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        </div>
        </div>
    </div>
    </div>
    <!-- End Modal -->


<body>

<div class="container-fluid">
<div class="row" style="padding-left: 1%; padding-right: 1%;">

    <div class="row">
        <div class="col-md-12 text-center">
            <h2>MATERIAL KANBAN #: <span style="background-color: green; color: white;"><?php echo $_GET['ref'];?></span></h2>
            <h2>SUPPLIER: <?php echo $supplier_name;?></h2>
            <h3>DATE: <?php echo $header['PACKING_DATE'];?></h3>
            <div id="qrcode">
                <script type="text/javascript">
                var qrcode = new QRCode(document.getElementById("qrcode"), {width: 80, height: 80 });
                qrcode.clear();
                qrcode.makeCode("<?php echo $_GET['ref'];?>");
                </script>
            </div>
        </div>
    </div>
    <br />
    
    <div class="row">
        <table id="tbl_items" class="table table-bordered">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Receive #</th>
                    <th>CODE</th>
                    <th>MANUFACTURING CODE</th>
                    <th>LOT NO</th>
                    <th>BAG COUNT</th>
                    <th>ORDER QTY</th>
                    <th>BALANCE</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
            <?php 
                $items = $packlist->fetch_rcv_items($_GET['ref']);
                for($x = 0; $x <= sizeof($items)-1; $x++){
                    $assign_status = $matl->CHECK_ASSIGNED_MATERIAL($items[$x]['material_code'], $items[$x]['lot_no'], $items[$x]['receive_date'], $items[$x]['receive_no']);
                    $color = 'class="btn btn-sm btn-success no-print" style="background-color: #28a745;"';
                    if(sizeof($assign_status) > 0){
                        $balance = $items[$x]['QTY'] - $assign_status['QTY'][0];
                    } else {
                        $balance = $items[$x]['QTY'];
                        $assign_status['QTY'][0] = 0;
                    }
                    echo '<tr>
                    <td>'.($x+1).'</td>
                    <td>'.$items[$x]['receive_no'].'</td>
                    <td>'.$items[$x]['material_code'].'</td>
                    <td>'.$items[$x]['manu_item'].'</td>
                    <td>'.$items[$x]['lot_no'].'</td>
                    <td>'.($items[$x]['QTY']/25).'</td>
                    <td>'.$items[$x]['QTY'].'</td>
                    <td>'.$balance.'</td>';
                    if($assign_status['QTY'][0] == $items[$x]['QTY']){
                        $PID_STRING = implode('|', $assign_status['PID']);
                        echo '<td><button class="btn btn-sm btn-warning" onclick="window.location.assign(\'reprint_matl_tag.php?ref='.$PID_STRING.'\')">RE-PRINT</button></td>
                        </tr>';
                    } else {
                        echo '<td><button '.$color.' onclick="tagsheet_modal(\''.$items[$x]['material_code']."*".$items[$x]['lot_no']."*".$items[$x]['QTY']."*".$items[$x]['receive_no']."*".$items[$x]['manu_item'].'*'.$balance.'*'.'0'.'\')">PRINT</button></td>
                        </tr>';
                    }
                }

            ?>
            </tbody>
        </table>
    </div>
    
</div>
</div>    
</body>

<script>
    function tagsheet_modal(param){
        var d = param.split("*");
        $("#print_modal").modal('show');
        p_rcv.value = d[3];
        p_code.value = d[0];
        p_lot.value = d[1];
        p_qty.value = d[5]; //display the remaining balance for un-assigned material
        p_manuf.value = d[4];
        p_id_string.value = d[6]; //0 if new palette_id, PID-XXXX-X|PID-XXXX-1 is exisiting palette_id (for reprinting)

    } 

    function print_tagsheet(p_rcv, p_code, p_lot, p_qty, p_palette, p_count, p_manuf, p_id_string){
        var d = {};
        d.receive_id = p_rcv;
        d.lot_no = p_lot;
        d.rcv_qty = p_qty;
        d.palette_weight = p_palette;
        d.tag_count = p_count;
        d.manuf_item = p_manuf;
        d.pid = p_id_string;
        if((d.tag_count < 1 || d.palette_weight < 1)){
            alert("Incomplete Inputs");
        } else if((parseInt(d.rcv_qty) < (parseInt(d.tag_count) * parseInt(d.palette_weight)))){
            alert("Invalid QTY");
        } else {
            window.location.assign('matl_tag.php?ref='+encodeURI(JSON.stringify(d)));
        }
    }
</script>

</html>