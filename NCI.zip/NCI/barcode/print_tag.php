<?php

if (isset($_GET['ref'])) {

	$params = json_decode($_GET['ref'], true);
	$barcode = implode('*', $params);
	// echo ($barcode);
}


?>


<!DOCTYPE html>

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="../assets/css/bootstrap.min.css" rel="stylesheet">
	<script src="../assets/js/jquery.3.2.1.min.js"></script>
	<script src="../assets/js/bootstrap.min.js"></script>
	<script src="../assets/js/qrcode.min.js"></script>

</head>

<style>
	@medial all {
		.page-break {
			display: none;
		}
	}

	@media print {
		.page-break {
			display: block;
			page-break-before: auto;
			position: relative;
			border-collapse: collapse;
			margin: 0.00in;
			padding: 0;
			margin-left: 0.1in;
			margin-right: 0.1in;
			margin-top: 0.1in;
			margin-bottom: 0.1in;


			width: auto;
			height: 100%;
			border: 0px solid black;
			border-style: solid;
			background: white;

		}

	}

	.palette_qr img {
		width: 80px;
		height: 80px;
	}
</style>

<style type="text/css">
	.tg {
		border-collapse: collapse;
		border-spacing: 0;
	}

	.tg td {
		font-family: Arial, sans-serif;
		font-size: 70%;
		padding-bottom: 0.3%;
		padding-top: 0.3%;
		border-style: solid;
		border-width: 1px;
		overflow: hidden;
		word-break: normal;
		border-color: black;
	}

	.tg th {
		font-family: Arial, sans-serif;
		font-size: 70%;
		font-weight: normal;
		padding-bottom: 0.3%;
		padding-top: 0.3%;
		border-style: solid;
		border-width: 1px;
		overflow: hidden;
		word-break: normal;
		border-color: black;
	}

	.tg .tg-0lax {
		text-align: left;
		vertical-align: top;
	}

	.h {
		font-size: 10px;
		font-weight: bold;
	}

	#table_wrapper {
		height: 210px;
	}

	.grid-container {
		display: grid;
		grid-template-columns: repeat(9, 1fr);
		grid-gap: 20px;
		padding: 20px;
	}
</style>





<script src="../assets/js/jquery.3.2.1.min.js"></script>
<script src="../assets/js/jquery-qrcode-0.15.0.min.js"></script>

<link href="../assets/css/bootstrap.min.css" rel="stylesheet">
<script src="../assets/js/bootstrap.min.js"></script>


<body>
	<div id="container">

	</div>

	<script>
		var x = <?php echo $params['p_count']; ?>;
		var container = document.getElementById('container');

		while (x > 0) {
			var gridContainer = document.createElement('div');
			gridContainer.classList.add('grid-container');

			for (var i = 0; i < x; i++) {
				var barcodeContainer = document.createElement('div');
				var qrCodeDiv = document.createElement('div');
				var textDiv = document.createElement('div');

				var qrCode = new QRCode(qrCodeDiv, {
					width: 80,
					height: 80
				});
				qrCode.makeCode("<?php echo $params['material_name']; ?>");

				textDiv.textContent = "<?php echo $params['material_name']; ?>";
				textDiv.style.fontWeight = "bold"; // Set the font weight to bold

				barcodeContainer.appendChild(qrCodeDiv);
				barcodeContainer.appendChild(textDiv);
				gridContainer.appendChild(barcodeContainer);
			}

			container.appendChild(gridContainer);
			break;
		}
	</script>
</body>

</html>