<?php


include('dbcon.php');

//A2*hendrix*21232f297a57a5a743894a0e4a801fc3*ADMIN

session_start();
if(isset($_POST['user_info'])){
	$info = explode("*", $_POST['user_info']);

	$sql = "SELECT * FROM tbl_Users WHERE [user_id]=? AND [password]=?";
	$stmt = $conn->prepare($sql);
	$stmt->execute([$info[0], $info[2]]);

	if($row = $stmt->fetch(PDO::FETCH_ASSOC)){
		$_SESSION['id'] = $row['user_id'];
		header('location:dashboard.php?id='.md5($_SESSION['id']));
	} else {
		header('location:index.php?error=invalid_credentials');
	}
}




?>