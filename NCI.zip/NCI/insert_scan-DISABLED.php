<?php
date_default_timezone_set("Asia/Jakarta");
include('dbcon.php');


/*$_POST['doc_num'] = "CRT060918A";
$_POST['scanned'] = "J000003535263*EP-0147*2*18830B*1*B-8*2B4*20";
$_POST['loc_to'] = "CRSNG";
$_POST['loc_from'] = "ONHOLD";
$_POST['userID'] = "admin";
$_POST['date'] = "09-06-2018";*/
if(isset($_POST['doc_num']) && isset($_POST['scanned'])){
	
	$scanned = $_POST['scanned'];
	$loc_to = $_POST['loc_to'];
	$loc_from = $_POST['loc_from'];
	$DOCNUM = $_POST['doc_num'];
	$userID = $_POST['userID'];
	$date = $_POST['date'];

	//J000003535261*EP-0147*2*18830B*1*B-8*2B4*20

	$del_date_ex = explode("-", $date); //yyyy-mm-dd
	$date = $del_date_ex[2]."-".$del_date_ex[1]."-".$del_date_ex[0]; //dd/mm/yyyy

	$resp = array();

	$scanned_explode = explode("*", $scanned);

	if(sizeof($scanned_explode) == 8){
		$scanned_data = array();

		if(strlen($scanned_explode[0]) >= 13){
			$scanned_data['KanbanID'] = substr($scanned_explode[0], -13);
		} else if(strlen($scanned_explode[0]) < 13){
			//quick escape from the script
			echo json_encode($resp['message'] = true);
			exit();
		}
	
		$scanned_data['PartCode'] = $scanned_explode[1];
		$scanned_data['BoxNo'] = $scanned_explode[2];
		$scanned_data['LotDate'] = $scanned_explode[3];
		$scanned_data['Cavity'] = $scanned_explode[4];
		$scanned_data['MachineNo'] = $scanned_explode[5];
		$scanned_data['LocID'] = $scanned_explode[6];
		$scanned_data['QTY'] = $scanned_explode[7];
	
		
	
		$parts_select = "SELECT PART_NO, PART_NAME FROM tbl_parts WHERE PART_CODE=?";
		$stmt = $conn->prepare($parts_select);
		$stmt->execute([$scanned_data['PartCode']]);
	
		while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
			$scanned_data['PartNo'] = $row['PART_NO'];
			$scanned_data['PartName'] = htmlspecialchars($row['PART_NAME'], ENT_COMPAT);
		}
	
	
	
	
		if($loc_from == "FGWHS" && $loc_to == "ONHOLD"){

			$kanban_data = OH_transfer($scanned_explode[0]);
			if($kanban_data[0]){
				insert_inv_OH($scanned_data['KanbanID'], $DOCNUM, $scanned_data['PartCode'], $scanned_data['PartNo'], $scanned_data['PartName'], $scanned_data['LotDate'], $scanned_data['QTY'], $date, $scanned_data['LocID'], $loc_to, $scanned_data['MachineNo'], $scanned_data['BoxNo'], $scanned_data['Cavity'], $userID);
				OH_update_inv($scanned_explode[0]);

				$resp['box_qty'] = OH_check_box_qty($DOCNUM);
				$resp['message'] = false;
				echo json_encode($resp);

			} else {
				$resp['message'] = true; 
				echo json_encode($resp);
			}

		} else if($loc_from == "ONHOLD" && $loc_to == "FGWHS"){

			if(check_kanban_OH($scanned_explode[0])){
			update_OH($scanned_explode[0], $DOCNUM);
			$resp['box_qty'] = OH_check_box_qty($DOCNUM);
			$resp['message'] = false;
			echo json_encode($resp);
			} else {
				$resp['message'] = true; 
				echo json_encode($resp);
			}

		} else if(($loc_from == "ONHOLD" || $loc_from == "FGWHS") && $loc_to == "CRSNG"){

			if(check_kanban_OH_disposed($scanned_explode[0])){
				CRSNG($scanned_explode[0], $DOCNUM);
				$resp['box_qty'] = CRSNG_check_box_qty($DOCNUM);
				$resp['message'] = false;
				echo json_encode($resp);
			} else {
				$resp['message'] = true; 
				echo json_encode($resp);

			}

		} else if($loc_from == "MCPRD" && $loc_to == "WIP1" || $loc_to == "WIP2" || $loc_to == "WIP"){

			if(!check_kanban_WIP($scanned_explode[0])){
				if($scanned_data['LocID'] == "WIP1" || $scanned_data['LocID'] == "WIP2" || $scanned_data['LocID'] == "WIP"){
				insert_inv_WIP($scanned_data['KanbanID'], $DOCNUM, $scanned_data['PartCode'], $scanned_data['PartNo'], $scanned_data['PartName'], $scanned_data['LotDate'], $scanned_data['QTY'], $date, $scanned_data['LocID'], $loc_to, $scanned_data['MachineNo'], $scanned_data['BoxNo'], $scanned_data['Cavity'], $userID, '0');

				$resp['box_qty'] = WIP_check_box_qty($DOCNUM);
				$resp['message'] = false;
				echo json_encode($resp);
				} else {
					$resp['message'] = true; 
					echo json_encode($resp);
				}


			} else {

				$resp['message'] = true; 
				echo json_encode($resp);

			}



		} else {
			if(!check_kanban($scanned_data['KanbanID'])){

					if($scanned_data['LocID'] != "WIP" || $scanned_data['LocID'] != "WIP2" || $scanned_data['LocID'] != "WIP1"){
					insert_inv($scanned_data['KanbanID'], $DOCNUM, $scanned_data['PartCode'], $scanned_data['PartNo'], $scanned_data['PartName'], $scanned_data['LotDate'], $scanned_data['QTY'], $date, $scanned_data['LocID'], $loc_to, $scanned_data['MachineNo'], $scanned_data['BoxNo'], $scanned_data['Cavity'], $userID);
			
					$resp['box_qty'] = check_box_qty($DOCNUM);
					$resp['message'] = false;
					echo json_encode($resp);
					} else {
						$resp['message'] = true; //exisiting item, cannot insert
						echo json_encode($resp);
					}
			
				} else {
			
					$resp['message'] = true; //exisiting item, cannot insert
					echo json_encode($resp);
				}
			}


	} else { // OLD LABEL

		if($loc_from == "FGWHS" && $loc_to == "ONHOLD"){

			$kanban_data = OH_transfer($scanned_explode[0]);
			if($kanban_data[0]){
				insert_inv_OH($kanban_data[1], $DOCNUM, $kanban_data[2], $kanban_data[3], $kanban_data[4], $kanban_data[5], $kanban_data[6], $date, '0', $loc_to, $kanban_data[7], '1', $kanban_data[8], $userID);
				OH_update_inv($scanned_explode[0]);

				$resp['box_qty'] = OH_check_box_qty($DOCNUM);
				$resp['message'] = false;
				echo json_encode($resp);

			} else {
				$resp['message'] = true; 
				echo json_encode($resp);
			}

		} else if($loc_from == "ONHOLD" && $loc_to == "FGWHS"){

			if(check_kanban_OH($scanned_explode[0])){
			update_OH($scanned_explode[0], $DOCNUM);
			$resp['box_qty'] = OH_check_box_qty($DOCNUM);
			$resp['message'] = false;
			echo json_encode($resp);
			} else {
				$resp['message'] = true; 
				echo json_encode($resp);
			}


		} else if($loc_from == "ONHOLD" && $loc_to == "CRSNG"){

			if(check_kanban_OH_disposed($scanned_explode[0])){
				CRSNG($scanned_explode[0], $DOCNUM);
				$resp['box_qty'] = CRSNG_check_box_qty($DOCNUM);
				$resp['message'] = false;
				echo json_encode($resp);
			} else {
				$resp['message'] = true; 
				echo json_encode($resp);

			}

		} else if($loc_from == "MCPRD" && $loc_to == "WIP1" || $loc_to == "WIP2" || $loc_to == "WIP"){

			if(!check_kanban_WIP($scanned_explode[0])){
				$sel = "SELECT TOP 1 kanban_id, lot_no, part_code, part_no, part_name, qty FROM tbl_kanban WHERE kanban_id=?";
				$stmt = $conn->prepare($sel);
				$stmt->execute([$scanned_explode[0]]);

			if($data = $stmt->fetch(PDO::FETCH_ASSOC)){
				$old_kanban = array();
					$old_kanban['kanban_id'] = $data['kanban_id'];
					$old_kanban['lot_no_ext'] = $data['lot_no'];
					$old_kanban['part_code'] = $data['part_code'];
					$old_kanban['part_no'] = $data['part_no'];
					$old_kanban['part_name'] = $data['part_name'];
					$old_kanban['qty'] = $data['qty'];

					$lot_date = substr($old_kanban['lot_no_ext'], 3, 5);
					$cav = substr($old_kanban['lot_no_ext'], 10, 1);


					$sql = "SELECT TOP 1 mc_no FROM tbl_parts WHERE PART_CODE=?";
					$stmt = $conn->prepare($sql);
					$stmt->execute([$old_kanban['part_code']]);

					while($rows = $stmt->fetch(PDO::FETCH_ASSOC)){
						$old_kanban['mc_no'] = $rows['mc_no'];

					}

					if(WIP_Protection_old($scanned_explode[0], $loc_to, $old_kanban['part_code'])){

					insert_inv_WIP($old_kanban['kanban_id'], $DOCNUM, $old_kanban['part_code'], $old_kanban['part_no'], $old_kanban['part_name'], $lot_date, $old_kanban['qty'], $date, '0', $loc_to, $old_kanban['mc_no'], '0', $cav, $userID, '0');

					$resp['box_qty'] = WIP_check_box_qty($DOCNUM);
					$resp['message'] = false;
					echo json_encode($resp);
					} else {
						$resp['message'] = true; 
						echo json_encode($resp);
					}
				}

			} else {

				$resp['message'] = true; 
				echo json_encode($resp);
			}

		} else {



			$sel = "SELECT TOP 1 kanban_id, lot_no, part_code, part_no, part_name, qty FROM tbl_kanban WHERE kanban_id=?";
			$stmt = $conn->prepare($sel);
			$stmt->execute([$scanned_explode[0]]);

			if($data = $stmt->fetch(PDO::FETCH_ASSOC)){
				$old_kanban = array();
					$old_kanban['kanban_id'] = $data['kanban_id'];
					$old_kanban['lot_no_ext'] = $data['lot_no'];
					$old_kanban['part_code'] = $data['part_code'];
					$old_kanban['part_no'] = $data['part_no'];
					$old_kanban['part_name'] = $data['part_name'];
					$old_kanban['qty'] = $data['qty'];

					$lot_date = substr($old_kanban['lot_no_ext'], 3, 5);
					$cav = substr($old_kanban['lot_no_ext'], 10, 1);


					$sql = "SELECT TOP 1 mc_no FROM tbl_parts WHERE PART_CODE=?";
					$stmt = $conn->prepare($sql);
					$stmt->execute([$old_kanban['part_code']]);

					while($rows = $stmt->fetch(PDO::FETCH_ASSOC)){
						$old_kanban['mc_no'] = $rows['mc_no'];

					}

				if(!check_kanban($scanned_explode[0])){
					if(!WIP_Protection_old($scanned_explode[0], $loc_to, $old_kanban['part_code'])){
					insert_inv($old_kanban['kanban_id'], $DOCNUM, $old_kanban['part_code'], $old_kanban['part_no'], $old_kanban['part_name'], $lot_date, $old_kanban['qty'], $date, '0', $loc_to, $old_kanban['mc_no'], '0', $cav, $userID);

						$resp['box_qty'] = check_box_qty($DOCNUM);
						$resp['message'] = false;
						echo json_encode($resp);

					} else {

						$resp['message'] = true; //exisiting item, cannot insert
						echo json_encode($resp);

					}

				} else {
					$resp['message'] = true; //exisiting item, cannot insert
					echo json_encode($resp);
				}

			} else {
				$resp['message'] = true; //error, invalid qr code; kanban not found.
				echo json_encode($resp);

			}
		}
		
	}


} else {
	$resp['message'] = "NO ITEM SCANNED!";
	echo json_encode($resp);
}


function insert_inv($KanbanID, $DocNum, $PartCode, $PartNo, $PartName, $LotDate, $QTY, $RcvDate, $LocID, $LocationTo, $MachineNo, $BoxNo, $Cavity, $UserID){ 
	include('dbcon.php');
	$ins = "INSERT INTO tbl_inventory(Kanban_ID, DOCNUM, part_code, part_no, part_name, lot_date, qty, rcv_date, loc_id, location, mc_no, box_no, cavity, on_hold, UserID) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	$stmt = $conn->prepare($ins);
	$stmt->execute([$KanbanID, $DocNum, $PartCode, $PartNo, $PartName, $LotDate, $QTY, $RcvDate, $LocID, $LocationTo, $MachineNo, $BoxNo, $Cavity, '0', $UserID]);
	$resp['message'] = "OK";
}

function check_kanban($KanbanID){
	include('dbcon.php');
	$sel = "SELECT Kanban_ID FROM tbl_inventory WHERE Kanban_ID=?";
	$stmt = $conn->prepare($sel);
	$stmt->execute([$KanbanID]);

	if($row = $stmt->fetch(PDO::FETCH_ASSOC)){
		return true;
	} else {
		return false;
	}
}

function check_kanban_OH($kanbanID){
	include('dbcon.php');
	$sel = "SELECT TOP 1 Kanban_ID FROM tbl_inventory_OH WHERE Kanban_ID=? AND release_date IS NULL";
	$stmt = $conn->prepare($sel);
	$stmt->execute([$kanbanID]);

	if($row = $stmt->fetch(PDO::FETCH_ASSOC)){
		return true;
	} else {
		return false;
	}
}

function check_kanban_OH_disposed($kanbanID){
	include('dbcon.php');
	$sel = "SELECT TOP 1 Kanban_ID FROM tbl_inventory WHERE Kanban_ID=? AND disposed IS NULL";
	$stmt = $conn->prepare($sel);
	$stmt->execute([$kanbanID]);

	if($row = $stmt->fetch(PDO::FETCH_ASSOC)){
		return true;
	} else {
		return false;
	}
}



function check_kanban_WIP($kanbanID){
	include('dbcon.php');
	$sel = "SELECT Kanban_ID FROM tbl_inventory_WIP WHERE Kanban_ID=?";
	$stmt = $conn->prepare($sel);
	$stmt->execute([$kanbanID]);

	if($row = $stmt->fetch(PDO::FETCH_ASSOC)){
		return true;
	} else {
		return false;
	}
}



function check_box_qty($DocNum){
	include('dbcon.php');
	$sql = "SELECT Kanban_ID FROM tbl_inventory WHERE DOCNUM=?";
	$stmt = $conn->prepare($sql);
	$stmt->execute([$DocNum]);
	$i = 0;
	while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
		$i++;
	}

	return $i;
}

function OH_check_box_qty($DocNum){
	include('dbcon.php');
	$sql = "SELECT Kanban_ID FROM tbl_inventory_OH WHERE DOCNUM=?";
	$stmt = $conn->prepare($sql);
	$stmt->execute([$DocNum]);
	$i = 0;
	while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
		$i++;
	}

	return $i;
}

function WIP_check_box_qty($DocNum){
	include('dbcon.php');
	$sql = "SELECT Kanban_ID FROM tbl_inventory_WIP WHERE DOCNUM=?";
	$stmt = $conn->prepare($sql);
	$stmt->execute([$DocNum]);
	$i = 0;
	while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
		$i++;
	}

	return $i;
}

function CRSNG_check_box_qty($DOCNUM){
	include('dbcon.php');
	$sql = "SELECT Kanban_ID FROM tbl_inventory WHERE disposed=?";
	$stmt = $conn->prepare($sql);
	$stmt->execute([$DOCNUM]);
	$i = 0;
	while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
		$i++;
	}

	return $i;
}

function OH_transfer($kanbanID){
	include('dbcon.php');
	$sql = "SELECT TOP 1 * FROM tbl_inventory WHERE Kanban_ID=? AND on_hold='0'";
	$stmt = $conn->prepare($sql);
	$stmt->execute([$kanbanID]);
	$data = array();
	if($row = $stmt->fetch(PDO::FETCH_ASSOC)){
		$data[0] = true;
		$data[1] = $row['Kanban_ID'];
		$data[2] = $row['part_code'];
		$data[3] = $row['part_no'];
		$data[4] = $row['part_name'];
		$data[5] = $row['lot_date'];
		$data[6] = $row['qty'];
		$data[7] = $row['mc_no'];
		$data[8] = $row['cavity'];
	} else {
		$data[0] = false;
	}

	return $data;

}



function OH_update_inv($kanbanID){
	include('dbcon.php');
	$sql = "UPDATE tbl_inventory SET on_hold='1', on_hold_date=? WHERE Kanban_ID=?";
	$stmt = $conn->prepare($sql);
	$stmt->execute([date(DATE_W3C), $kanbanID]);
}

function insert_inv_OH($KanbanID, $DocNum, $PartCode, $PartNo, $PartName, $LotDate, $QTY, $RcvDate, $LocID, $LocationTo, $MachineNo, $BoxNo, $Cavity, $UserID){ 
	include('dbcon.php');
	$ins = "INSERT INTO tbl_inventory_OH(Kanban_ID, DOCNUM, part_code, part_no, part_name, lot_date, qty, rcv_date, loc_id, location, mc_no, box_no, cavity, UserID) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	$stmt = $conn->prepare($ins);
	$stmt->execute([$KanbanID, $DocNum, $PartCode, $PartNo, $PartName, $LotDate, $QTY, $RcvDate, $LocID, $LocationTo, $MachineNo, $BoxNo, $Cavity, $UserID]);
	$resp['message'] = "OK";
}

function insert_inv_WIP($KanbanID, $DocNum, $PartCode, $PartNo, $PartName, $LotDate, $QTY, $RcvDate, $LocID, $LocationTo, $MachineNo, $BoxNo, $Cavity, $UserID, $delivered){ 
	include('dbcon.php');
	$ins = "INSERT INTO tbl_inventory_WIP(Kanban_ID, DOCNUM, part_code, part_no, part_name, lot_date, qty, rcv_date, loc_id, location, mc_no, box_no, cavity, delivered, UserID) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	$stmt = $conn->prepare($ins);
	$stmt->execute([$KanbanID, $DocNum, $PartCode, $PartNo, $PartName, $LotDate, $QTY, $RcvDate, $LocID, $LocationTo, $MachineNo, $BoxNo, $Cavity, $delivered, $UserID]);
	$resp['message'] = "OK";
}

function update_OH($kanbanID, $DOCNUM){
	include('dbcon.php');

	$sql = "UPDATE tbl_inventory_OH SET DOCNUM_2=?, release_date=?, disposed='0' WHERE Kanban_ID=?";
	$stmt = $conn->prepare($sql);
	$stmt->execute([$DOCNUM, date(DATE_W3C), $kanbanID]);

	$x = "UPDATE tbl_inventory SET on_hold='0' WHERE Kanban_ID=?";
	$st = $conn->prepare($x);
	$st->execute([$kanbanID]);
}

function CRSNG($kanbanID, $DOCNUM){

	include('dbcon.php');
	$sql = "UPDATE tbl_inventory SET disposed=?, disposed_date=? WHERE Kanban_ID=?";
	$stmt = $conn->prepare($sql);
	$stmt->execute([$DOCNUM, date(DATE_W3C), $kanbanID]);
/*
	$x = "UPDATE tbl_inventory_OH SET disposed='1' WHERE Kanban_ID=?";
	$s = $conn->prepare($x);
	$s->execute([$kanbanID]);*/


}

function WIP_Protection_old($kanbanID, $loc_to, $PartCode){
	include('dbcon.php');
	$sql = "SELECT TOP 1 MONTH_PP FROM tbl_parts WHERE PART_CODE=?";
	$stmt = $conn->prepare($sql);
	$stmt->execute([$PartCode]);
	$locID = "";

	while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
		$locID = $row['MONTH_PP'];
	}


	if($locID == "WIP"){
		return true;
	} else {
		return false; 
	}


}






?>