<?php

include('dbcon.php');

/*$_POST['SCAN'] = "D000003604128";
$_POST['DOCNUM'] = "FGT100918A";
$_POST['LOCTO'] = "FGWHS";*/


if(isset($_POST['DOCNUM']) && isset($_POST['SCAN'])){
	$DOCNUM = $_POST['DOCNUM'];
	$SCAN = $_POST['SCAN'];
	$LOCTO = $_POST['LOCTO'];
	$new_data = array();
	$scanned_data = explode("*", $SCAN);
	$KanbanID = $scanned_data[0];

	$resp = array();

	$box_count = 0;

	if($LOCTO == "FGWHS"){
		if(check_inv($KanbanID)){
			delete_inv($KanbanID);
			$box_count = count_boxes($DOCNUM, $LOCTO);
			update_boie_count($DOCNUM, $box_count);
			$resp['message'] = false; 
		} else {
			$resp['message'] = true;
		}

	} else if($LOCTO == "WIP1" || $LOCTO == "WIP2"){
		if(check_WIP($KanbanID)){
			delete_WIP($KanbanID);
			$box_count = count_boxes($DOCNUM, $LOCTO);
			update_boie_count($DOCNUM, $box_count);
			$resp['message'] = false; 
		} else {
			$resp['message'] = true;
		}


	} else if($LOCTO == "ONHOLD"){
		if(check_OH($KanbanID)){
			delete_OH($KanbanID);
			$box_count = count_boxes($DOCNUM, $LOCTO);
			update_boie_count($DOCNUM, $box_count);
			$resp['message'] = false; 
		} else {
			$resp['message'] = true;
		}

	}


	echo json_encode($resp);

}


function delete_inv($kanbanID){
	include('dbcon.php');
	$sql = "DELETE FROM tbl_inventory WHERE Kanban_ID=? AND delivered IS NULL AND on_hold='0'";
	$s = $conn->prepare($sql);
	if($s->execute([$kanbanID])){
		return true;
	} else {
		return false;
	}
}

function delete_WIP($kanbanID){
	include('dbcon.php');
	$sql = "DELETE FROM tbl_inventory_WIP WHERE Kanban_ID=?";
	$s = $conn->prepare($sql);
	if($s->execute([$kanbanID])){
		return true;
	} else {
		return false;
	}
	
}

function delete_OH($kanbanID){
	include('dbcon.php');
	$sql = "DELETE FROM tbl_inventory_OH WHERE Kanban_ID=? AND DOCNUM_2 IS NULL";
	$s = $conn->prepare($sql);
	if($s->execute([$kanbanID])){
		return true;
	} else {
		return false;
	}
	
}

function count_boxes($docnum, $LOCTO){
	$loc = "";
	if($LOCTO == "WIP1" || $LOCTO == "WIP2"){
		$loc = "_WIP";
	} else if($LOCTO == "ONHOLD"){
		$loc = "_OH";
	}
	include('dbcon.php');
	$sql = "SELECT Kanban_ID FROM tbl_inventory".$loc." WHERE DOCNUM=?";
	$stmt = $conn->prepare($sql);
	$stmt->execute([$docnum]);
	$i = 0;
	while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
		$i++;
	}

	return $i;
}

function update_boie_count($docnum, $box_count){
	include('dbcon.php');
	$sql = "UPDATE tbl_inv_header SET TOTAL_BOX=? WHERE DOCNUM=?";
	$s = $conn->prepare($sql);
	$s->execute([$box_count, $docnum]);
}


function check_inv($kanbanID){
	include('dbcon.php');
	$sql = "SELECT Kanban_ID FROM tbl_inventory WHERE Kanban_ID=?";
	$s = $conn->prepare($sql);
	$s->execute([$kanbanID]);

	if($row = $s->fetch(PDO::FETCH_ASSOC)){
		return true;
	} else {
		return false; 
	}

}

function check_OH($kanbanID){
	include('dbcon.php');
	$sql = "SELECT Kanban_ID FROM tbl_inventory_OH WHERE Kanban_ID=?";
	$s = $conn->prepare($sql);
	$s->execute([$kanbanID]);

	if($row = $s->fetch(PDO::FETCH_ASSOC)){
		return true;
	} else {
		return false; 
	}

}

function check_WIP($kanbanID){
	include('dbcon.php');
	$sql = "SELECT Kanban_ID FROM tbl_inventory_WIP WHERE Kanban_ID=?";
	$s = $conn->prepare($sql);
	$s->execute([$kanbanID]);

	if($row = $s->fetch(PDO::FETCH_ASSOC)){
		return true;
	} else {
		return false; 
	}

}

?>