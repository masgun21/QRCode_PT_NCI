<?php

	$path = dirname(__FILE__);

	include($path."/config.inc.php");
	include($path."/../model/picklist.search.obj.php");

?>