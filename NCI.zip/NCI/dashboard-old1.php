<?php
include('active-session.php');
?>

<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="theme.css" type="text/css">
  <link rel="icon" href="assets/img/daiho.ico">
  <link rel="stylesheet" href="includes/w3.css" type="text/css">
  <title>PT. DAIHO INDONESIA</title>
</head>
 <embed src="pc_beep.WAV" hidden=true autostart=false loop=false name="firstSound" mastersound>
<body style="background-color: white; color: black;" onload="autofocus()">

  <!-- side nav -->
  <!-- <div class="w3-sidebar w3-bar-block" style="width: auto; background-color: #3a7ce8; color: white; height: 100%; font-size: 17px; margin-top: 0px;">
      <a href="#" class="w3-bar-item w3-button w3-hover-white"><i class="fa fa-home"></i></a>
      <a href="#" class="w3-bar-item w3-button w3-hover-white"><i class="fa fa-gear"></i></a>
  </div> -->


<!-- main container -->
<div class='container-fluid' style="margin: 0px; width: 100%; padding: 0px;">
  <!-- top nav -->
 
    <nav class="navbar navbar-expand-md navbar-dark bg-secondary" style="text-align: center; margin-bottom: 5%;">
    <a class="navbar-brand mx-3 " href="../../logo-login-1-daiho.png">
      <img style="margin-left: 70%;" src="assets/img/logo-nav-old.png" width="100%" alt="" height="auto" class="d-inline-block align-top"> </a>
    <!-- <div class="container">
      <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbar2SupportedContent">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse text-center justify-content-end" id="navbar2SupportedContent">
        <a class="btn navbar-btn ml-2 text-white btn-secondary">
          <i class="fa d-inline fa-lg fa-user-circle-o"></i>User</a>
      </div>
    </div> -->
  </nav>

  <style>
    .form-control{
      border-radius: 0px;
    }
    .input-width {
      width: 50%;
    }

  #btn_new{
    background-color: #4CAF50;
    border: none;
    color: white;
    padding: 5px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 15px;
    margin: 4px 2px;
    border-radius: 3px;

  }

  #logout{
    background-color: red;
    border: none;
    color: white;
    padding: 5px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 15px;
    margin: 4px 2px;
    border-radius: 3px;

  }

  label {
    font-weight: bold; 
  }
  </style>

  <style>
.switch {
  position: relative;
  display: inline-block;
  width: 60px;
  height: 34px;
}

.switch input {display:none;}

.slider {
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #ccc;
  -webkit-transition: .4s;
  transition: .4s;
}

.slider:before {
  position: absolute;
  content: "";
  height: 26px;
  width: 26px;
  left: 4px;
  bottom: 4px;
  background-color: white;
  -webkit-transition: .4s;
  transition: .4s;
}

input:checked + .slider {
  background-color: red;
}

input:focus + .slider {
  box-shadow: 0 0 1px #2196F3;
}

input:checked + .slider:before {
  -webkit-transform: translateX(26px);
  -ms-transform: translateX(26px);
  transform: translateX(26px);
}

/* Rounded sliders */
.slider.round {
  border-radius: 34px;
}

.slider.round:before {
  border-radius: 50%;
}

.bt {
  width: 100%;
  margin-bottom: 2%;
}
</style>


   <!-- The Modal -->
  <div class="modal fade" id="menu_modal">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">SELECT TRANSFER PROCESS</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
            
           <div class="form-group">
             <button class="btn btn-lg btn-danger bt" value="MCPRD-FGWHS" onclick="set_loc(this.value)">MCPRD - FGWHS</button>
             <button class="btn btn-lg btn-danger bt" value="FGWHS-CRSNG" onclick="set_loc(this.value)">FGWHS - CRSNG</button>
             <button class="btn btn-lg btn-danger bt" value="MCPRD-WIP" onclick="set_loc(this.value)">MCPRD - WIP</button>
             <button class="btn btn-lg btn-danger bt" value="WIP-FGWHS" onclick="set_loc(this.value)">WIP - FGWHS</button>
			       <button class="btn btn-lg btn-danger bt" value="MCPRD-FGPDD" onclick="set_loc(this.value)">MCPRD - FGPDD</button>
			 
           </div>


        </div>
        
        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        </div>
        
      </div>
    </div>
  </div>




   <div class="container-fluid">
  <div class="row">
    <div class="col-md-12">
      <div class="text-center">
        <strong>User: <?php echo $username;?></strong>
        <button id="logout" onclick="window.location.assign('logout.php')">Logout</button>
      </div>
      
      <form role="form" class="form-inline">
        <input type="hidden" id="userID" value="<?php echo $username;?>"> <!-- this will hold the username of the current user -->
        <div class="form-group input-width">
          <label for="location_from">
            Document No.
          </label>
          <input type="text" class="form-control" id="DOCNUM" placeholder="Document No." disabled>
        </div>

        <div class="form-group input-width">
          <label for="location_from">
            Select Doc. No.
          </label>
          <select class="form-control" id="select_receipt" onchange="select_doc_num(this.value)">
             <option value="default" selected>---</option>
              <?php
                 include('dbcon.php');
                 $sql = "SELECT DOCNUM FROM tbl_inv_header";
                 $st = $conn->prepare($sql);
                 $st->execute();

                 while($row = $st->fetch(PDO::FETCH_ASSOC)){
                  echo "<option>".$row['DOCNUM']."</option>";
                 }
               ?>         

          </select>
        </div>
        <div class="form-group input-width">
           <label for="location_from">
            Location From:
          </label>
          <select class="form-control" id="location_from" disabled>
            <option value="default" selected>---</option>
            <option vlaue="MCPRD">MCPRD</option>
            <option vlaue="ONHOLD">ONHOLD</option>
            <option vlaue="FGWHS">FGWHS</option>
            <option vlaue="WIP1">WIP1</option>
            <option vlaue="WIP">WIP</option>
            <option vlaue="WIP2">WIP2</option>
            <option vlaue="FGPDD">FGPDD</option>
           
          </select>
        </div>
        <div class="form-group input-width">
           <label for="location_from">
            Location To:
          </label>
          <select class="form-control" id="location_to" disabled>
            <option value="default" selected>---</option>
            <option vlaue="FGWHS">FGWHS</option>
            <option vlaue="CRSNG">CRSNG</option>
            <option vlaue="ONHOLD">ONHOLD</option>
            <option vlaue="WIP1">WIP1</option>
            <option vlaue="WIP">WIP</option>
            <option vlaue="WIP2">WIP2</option>
            <option vlaue="FGPDD">FGPDD</option>

          </select>
        </div>

        <div class="form-group input-width">
          <label for="location_from">
            Date:
          </label>
          <input type="date" class="form-control" id="transfer_date"> <!-- value="YYY-MM-DD" -->
        </div>

        <div class="form-group input-width">
          <label for="location_from">
            Shift: 
          </label>
          <select class="form-control" id="shift" onchange="generate_docnum()" disabled>
            <option value="default" selected>---</option>
            <option>A</option>
            <option>B</option>
            <option>C</option>
            <option>D</option>
          </select>
        </div>

        <div class="form-group" style="width: 100%;">
          <label for="scanned_text">Scanned QR Code:</label>
          <input type="text" class="form-control" id="scanned_text" onchange="delete_or_not()" disabled>
        </div>  

      </form>

      <div class="form-group" style="width: 100%;">

        <h5>Cancel Scan</h5>
          <label class="switch">
            <input type="checkbox" id="delete_check" onchange="toggle_delete()">
            <span class="slider round"></span>
          </label>

          <button id="btn_new" style="float: right;" onclick="window.location.assign('dashboard.php')">New Document No.</button>
        </div>

      <table class="table table-hover table-sm" id="res_table">
        <thead>
          <th>#</th>
          <th>P. Code</th>
          <th>P. No.</th>
          <th>P. Name</th>
          <th>Box QTY</th>
          <th>QTY</th>
        </thead>
        <tbody id="tbod">
          <?php
            include('box_data.php');
          ?>
         
          
        </tbody>
      </table>




    </div>
  </div>
</div>

<script>
  var checked;
  var box_counter = 0;
  function beep_ok() { var audio = new Audio("pc_beep.wav"); audio.play(); }
  function beep_x() { var audio = new Audio("error.wav"); audio.play(); }

  var d = new Date();
  var date_string = d.getFullYear() + "-" + checkTime(d.getMonth()+1) + "-" + checkTime(d.getDate());
  document.getElementById("transfer_date").value = date_string;

  function toggle_delete(){
      checked = document.getElementById("delete_check").checked;
      console.log(checked);
    }

  function delete_or_not(){
    if(checked){
      delete_mode();
    } else {
      send_data();
    }

  }

  

  function autofocus(){
    
    var url = new URL(window.location.href);
    var c = url.searchParams.get("docnum"); //get URL params
    if(c == null || c == "default"){
      document.getElementById("DOCNUM").value = "";
      document.getElementById("location_from").value = "default";
      document.getElementById("location_to").value = "default";
      document.getElementById("location_from").disabled = true;
      document.getElementById("location_to").disabled = true;
      document.getElementById("shift").value = "";
      document.getElementById("scanned_text").value = "";
      document.getElementById("scanned_text").disabled = true;
      $("#menu_modal").modal('show');
    } else {
      console.log(c);
      document.getElementById("DOCNUM").value = c;
      document.getElementById("scanned_text").disabled = false;
      document.getElementById("scanned_text").focus();
      generate_doc_data(c);
    }
  }

  function set_loc(loc_data){
    var loc = loc_data.split("-");
    document.getElementById("location_from").value = loc[0];
    document.getElementById("location_to").value = loc[1];
    document.getElementById("shift").disabled = false;
    $("#menu_modal").modal('hide');
  }

  function checkTime(i) {
  if (i < 10) {i = "0" + i};  // add zero in front of numbers < 10
  return i;
  }

  function init_1(){
    document.getElementById("location_to").disabled = false;
  }
  function init_2(){
    document.getElementById("shift").disabled = false;
  }

  function select_doc_num(doc_num){
    window.location.assign('dashboard.php?docnum='+doc_num);
  }

  function generate_docnum(){
    var loc_to = document.getElementById("location_to").value;
    var loc_from = document.getElementById("location_from").value;
    var shift_code = document.getElementById("shift").value;
    var loc_code, doc_num_string;
    date_string = document.getElementById("transfer_date").value;
    var date_split = date_string.split("-");

    if(loc_from == "MCPRD" && loc_to == "FGWHS"){
      loc_code = "FGT";
    }
    else if(loc_from == "WIP1" || loc_from == "WIP2" || loc_from == "WIP" && loc_to == "FGWHS"){
      loc_code = "FGW";
    } else if(loc_from == "ONHOLD" && loc_to == "FGWHS"){
      loc_code = "OHT";
    } else if(loc_from == "FGWHS" && loc_to == "CRSNG"){
      loc_code = "CRT";
    } else if(loc_from == "MCPRD" && loc_to == "WIP1" || loc_to == "WIP2" || loc_to == "WIP"){
      loc_code = "WPT";
    } else if(loc_from == "MCPRD" && loc_to == "FGPDD"){
      loc_code = "FGP";
    } else if(loc_from == "FGPDD" && loc_to == "CRSNG"){
      loc_code = "CPD";
    }

    doc_num_string = loc_code+date_split[2]+date_split[1]+date_split[0].substr(2,2)+shift_code;
    document.getElementById("DOCNUM").value = doc_num_string;
    document.getElementById("location_to").disabled = true;
    document.getElementById("location_from").disabled = true;

    document.getElementById("scanned_text").disabled = false;
    document.getElementById("scanned_text").focus();
  }

  function send_data(){
    var header_data = {};

    var doc_num = document.getElementById("DOCNUM").value;
    var loc_from = document.getElementById("location_from").value;
    var loc_to = document.getElementById("location_to").value;
    var shift_code = document.getElementById("shift").value;
    var date = document.getElementById("transfer_date").value;
    var scanned = document.getElementById("scanned_text").value;
    var userID = document.getElementById("userID").value;

    header_data.DOCNUM = doc_num;
    header_data.DATE = date_string;
    header_data.USERID = userID;
    header_data.FROMLOC = loc_from;
    header_data.TOLOC = loc_to;
    header_data.SHIFT = shift_code;

   


    $.post("insert_scan.php",
    {
        doc_num: doc_num,
        scanned: scanned,
        loc_to: loc_to,
        userID: userID,
        date: date_string,
        loc_from: loc_from

    },
    function(data, status){

      var resp = JSON.parse(data);
      console.log(resp);

      if(resp.message){
        beep_x();
        document.getElementById("scanned_text").value = "";
        document.getElementById("scanned_text").focus();

      } else {
       
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {

              $("#res_table").find("tbody").empty();
              document.getElementById("tbod").innerHTML = this.responseText;

              header_data.BOX_QTY = resp.box_qty;
              var string_header = JSON.stringify(header_data);


              $.post("insert-header.php",
              {
                  header_d: string_header
              },
              function(data, status){
                  //console.log(data, status);
              });
               
            }
            
        };
        xmlhttp.open("GET", "box_data.php?docnum="+doc_num, true);
        xmlhttp.send();

        //DISBALE ALL INPUTS EXCEPT SCANNED TEXT
        document.getElementById("shift").disabled = true;
        document.getElementById("select_receipt").disabled = true;
        document.getElementById("transfer_date").disabled = true;


        document.getElementById("scanned_text").value = "";
        document.getElementById("scanned_text").focus();
        beep_ok();
      }

    });


  }

  function delete_mode(){
      var docnum = document.getElementById("DOCNUM").value;
      var scanned = document.getElementById("scanned_text").value;
      var locto = document.getElementById("location_to").value;
      $.post("delete_mode.php",
        {
            DOCNUM: docnum,
            SCAN: scanned,
            LOCTO: locto
        },
        function(data, status){
          
          var respo = JSON.parse(data);

          if(respo.message){
            beep_x();
            document.getElementById("scanned_text").value = "";
            document.getElementById("scanned_text").focus();
            toggle_delete();
          } else {
           var xmlhttp = new XMLHttpRequest();
            xmlhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                  

                  $("#res_table").find("tbody").empty();
                  document.getElementById("tbod").innerHTML = this.responseText;

                } 
            };
            xmlhttp.open("GET", "box_data.php?docnum="+docnum, true);
            xmlhttp.send();

            document.getElementById("scanned_text").value = "";
            document.getElementById("scanned_text").focus();
            beep_ok();
            toggle_delete();
          
          }

            
        });

  }


  function generate_doc_data(docnum){
      var xmlhttp = new XMLHttpRequest();
            xmlhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                  var data_obj = JSON.parse(this.responseText);

                  console.log(data_obj);
                    var myDate = data_obj.DOC_DATE;
                   myDate = myDate.split("-");

                  document.getElementById("transfer_date").value = myDate[2] + "-" + myDate[1] + "-" + myDate[0];
                  document.getElementById("location_from").value = data_obj.FROMLOC;
                  document.getElementById("location_to").value = data_obj.TOLOC;
                  
                  document.getElementById("shift").value = data_obj.SHIFT;

                  
                  
                } 
            };
            xmlhttp.open("GET", "get_doc_data.php?docnum="+docnum, true);
            xmlhttp.send();
    }


</script>



  <!-- footer -->
    <!-- <div class="py-5 text-white bg-light" style="padding-top: 20px; padding-bottom: 20px;">
    <div class="container">
      <div class="row">
        <div class="col-md-9">
          <p class="lead text-center">
            <strong>PT. DAIHO INDONESIA 2018</strong>
          </p>
          <p class="">Greenland International Industrial Center Blok AB No. 5, Cikarang Pusat, Nagasari, Serang Baru, Bekasi, Jawa Barat 17730</p>
        </div>
        <div class="col-4 col-md-1 align-self-center">
          <a href="https://www.facebook.com" target="_blank">
            <i class="fa fa-fw fa-facebook fa-3x text-white"></i>
          </a>
        </div>
        <div class="col-4 col-md-1 align-self-center">
          <a href="https://twitter.com" target="_blank">
            <i class="fa fa-fw fa-twitter fa-3x text-white"></i>
          </a>
        </div>
        <div class="col-4 col-md-1 align-self-center">
          <a href="https://www.instagram.com" target="_blank">
            <i class="fa fa-fw fa-instagram text-white fa-3x"></i>
          </a>
        </div>
      </div>
    </div>
  </div> -->
  <!-- end footer -->

</div>
    
    





  <script src="assets/js/jquery-3.3.1.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>

</html>