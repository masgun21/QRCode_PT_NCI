<?php

include('dbcon.php');

if(isset($_POST['header_d'])){
	$header_data[] = json_decode($_POST['header_d']);
	$sub_docnum = $header_data[0]->DOCNUM;
	$sub_date = $header_data[0]->DATE;
	$sub_userID = $header_data[0]->USERID;
	$sub_fromLoc = $header_data[0]->FROMLOC;
	$sub_toLoc = $header_data[0]->TOLOC;
	$sub_shift = $header_data[0]->SHIFT;
	$sub_boxQTY = $header_data[0]->BOX_QTY;

	$del_date_ex = explode("-", $sub_date); //yyyy-mm-dd
	$sub_date = $del_date_ex[2]."-".$del_date_ex[1]."-".$del_date_ex[0]; //dd/mm/yyyy

	if(check_docnum($sub_docnum)){
		update_only($sub_docnum, $sub_boxQTY);
	} else {
		$ins = "INSERT INTO tbl_inv_header(DOCNUM, DOC_DATE, SHIFT, USER_ID, FROMLOC, TOLOC, TOTAL_BOX) VALUES (?,?,?,?,?,?,?)";
		$stmt = $conn->prepare($ins);
		$stmt->execute([$sub_docnum, $sub_date, $sub_shift, $sub_userID, $sub_fromLoc, $sub_toLoc, $sub_boxQTY]);
	}


}

function check_docnum($DOCNUM){
	include('dbcon.php');
	$sel = "SELECT DOCNUM FROM tbl_inv_header WHERE DOCNUM=?";
	$stmt = $conn->prepare($sel);
	$stmt->execute([$DOCNUM]);

	if($data = $stmt->fetch(PDO::FETCH_ASSOC)){
		return true;
	} else {
		return false;
	}
}

function update_only($docnum, $box_qty){
	include('dbcon.php');
	$upd = "UPDATE tbl_inv_header SET TOTAL_BOX=? WHERE DOCNUM=?";
	$stmt = $conn->prepare($upd);
	$stmt->execute([$box_qty, $docnum]);
}



?>