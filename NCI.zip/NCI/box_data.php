<?php

include('dbcon.php');
if(isset($_GET['docnum'])){
	$docnum = $_GET['docnum'];
	$doc_head = substr($docnum, 0, 3);

	if($doc_head == "FGH"){
		$select = "SELECT part_code, part_no, part_name, qty, SUM(qty) AS QTY FROM tbl_inventory WHERE DOCNUM2=? GROUP BY part_code, part_no, part_name, qty";
		$stmt = $conn->prepare($select);
		$stmt->execute([$docnum]);
		$i = 1;
		while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
		echo "<tr>
			<td>".$i."</td>
			<td>".$row['part_code']."</td>
			<td>".$row['part_no']."</td>
			<td>".$row['part_name']."</td>
			<td>".$row['QTY']/$row['qty']."</td>
			<td>".$row['QTY']."</td></tr>";
		$i++;
	 }

		$select = "SELECT part_code, part_no, part_name, qty, SUM(qty) AS QTY FROM tbl_inventory_WIP WHERE DOCNUM2=? GROUP BY part_code, part_no, part_name, qty";
		$stmt = $conn->prepare($select);
		$stmt->execute([$docnum]);
		while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
		echo "<tr>
			<td>".$i."</td>
			<td>".$row['part_code']."</td>
			<td>".$row['part_no']."</td>
			<td>".$row['part_name']."</td>
			<td>".$row['QTY']/$row['qty']."</td>
			<td>".$row['QTY']."</td></tr>";
		$i++;
	}

	} else if($doc_head == "CRT"){

		$select = "SELECT part_code, part_no, part_name, qty, SUM(qty) AS QTY FROM tbl_inventory WHERE DOCNUM_3=? GROUP BY part_code, part_no, part_name, qty";
		$stmt = $conn->prepare($select);
		$stmt->execute([$docnum]);
		$i = 1;
		while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
		echo "<tr>
			<td>".$i."</td>
			<td>".$row['part_code']."</td>
			<td>".$row['part_no']."</td>
			<td>".$row['part_name']."</td>
			<td>".$row['QTY']/$row['qty']."</td>
			<td>".$row['QTY']."</td></tr>";
		$i++;
	 }


	 	$select = "SELECT part_code, part_no, part_name, qty, SUM(qty) AS QTY FROM tbl_inventory_WIP WHERE DOCNUM_3=? GROUP BY part_code, part_no, part_name, qty";
		$stmt = $conn->prepare($select);
		$stmt->execute([$docnum]);
		while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
		echo "<tr>
			<td>".$i."</td>
			<td>".$row['part_code']."</td>
			<td>".$row['part_no']."</td>
			<td>".$row['part_name']."</td>
			<td>".$row['QTY']/$row['qty']."</td>
			<td>".$row['QTY']."</td></tr>";
		$i++;
	 }

	} else if($doc_head == "RFG"){


		$select = "SELECT part_code, part_no, part_name, qty, SUM(qty) AS QTY FROM tbl_inventory WHERE DOCNUM_3=? GROUP BY part_code, part_no, part_name, qty";
		$stmt = $conn->prepare($select);
		$stmt->execute([$docnum]);
		$i = 1;
		while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
		echo "<tr>
			<td>".$i."</td>
			<td>".$row['part_code']."</td>
			<td>".$row['part_no']."</td>
			<td>".$row['part_name']."</td>
			<td>".$row['QTY']/$row['qty']."</td>
			<td>".$row['QTY']."</td></tr>";
		$i++;
	 }

	 	$select = "SELECT part_code, part_no, part_name, qty, SUM(qty) AS QTY FROM tbl_inventory_WIP WHERE DOCNUM_3=? GROUP BY part_code, part_no, part_name, qty";
		$stmt = $conn->prepare($select);
		$stmt->execute([$docnum]);
		$i = 1;
		while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
		echo "<tr>
			<td>".$i."</td>
			<td>".$row['part_code']."</td>
			<td>".$row['part_no']."</td>
			<td>".$row['part_name']."</td>
			<td>".$row['QTY']/$row['qty']."</td>
			<td>".$row['QTY']."</td></tr>";
		$i++;
	 }

	}
}

?>