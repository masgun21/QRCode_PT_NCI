-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 31, 2024 at 12:24 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_nci`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE `tbl_users` (
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `user_id` varchar(50) NOT NULL,
  `role` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`username`, `password`, `user_id`, `role`) VALUES
('mis_gunawan', 'fca821ba523f52901a0613bfba6baa2a', 'MOJ9O', 'ADMIN     '),
('nci_gunawan', '5f4dcc3b5aa765d61d8327deb882cf99', 'MOJ92', 'ADMIN     '),
('gun', '21232f297a57a5a743894a0e4a801fc3', 'MO92', 'ADMIN');

-- --------------------------------------------------------

--
-- Table structure for table `t_incoming`
--

CREATE TABLE `t_incoming` (
  `id` varchar(50) NOT NULL,
  `trans_date` varchar(50) NOT NULL,
  `sup_name` varchar(50) NOT NULL,
  `material_name` varchar(50) NOT NULL,
  `sup_lot` varchar(50) NOT NULL,
  `qty` varchar(50) NOT NULL,
  `unit` varchar(50) NOT NULL,
  `certificate_no` varchar(50) NOT NULL,
  `rcv_date` varchar(50) NOT NULL,
  `insp_date` varchar(50) NOT NULL,
  `ex_date` varchar(50) NOT NULL,
  `insp_name` varchar(50) NOT NULL,
  `insp_result` varchar(50) NOT NULL,
  `remarks` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `t_incoming`
--

INSERT INTO `t_incoming` (`id`, `trans_date`, `sup_name`, `material_name`, `sup_lot`, `qty`, `unit`, `certificate_no`, `rcv_date`, `insp_date`, `ex_date`, `insp_name`, `insp_result`, `remarks`) VALUES
('1', '18-06-2023', 'test', 'test', 'lot-1', '100', 'pcs', 'c-001', '18-06-2023', '18-06-2023', '18-06-2023', 'gunawan', 'OK', 'OK'),
('2', '18-06-2023', 'test2', 'test2', 'lot-2', '100', '50', 'c-002', '19-06-2023', '18-06-2023', '18-06-2023', 'gunawan', 'OK', 'OK'),
('3', '18-06-2023', 'test3', 'test', 'lot-3', '150', 'pcs', 'c-003', '18-06-2023', '18-06-2023', '18-06-2023', 'gunawan', 'OK', 'OK');

-- --------------------------------------------------------

--
-- Table structure for table `t_inspection`
--

CREATE TABLE `t_inspection` (
  `id` int(50) NOT NULL,
  `material_name` varchar(50) NOT NULL,
  `sup_lot` varchar(50) NOT NULL,
  `qty` varchar(50) NOT NULL,
  `rcv_date` varchar(50) NOT NULL,
  `inspector` varchar(50) NOT NULL,
  `certificate` varchar(50) NOT NULL,
  `ex_date` varchar(50) NOT NULL,
  `insp_result` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `t_inspection`
--

INSERT INTO `t_inspection` (`id`, `material_name`, `sup_lot`, `qty`, `rcv_date`, `inspector`, `certificate`, `ex_date`, `insp_result`) VALUES
(1, 'PR 901 T', 'EE221130', '4 Roll', '02-03-2023', 'Haryono', '-', '-', 'Accept'),
(2, 'HISSP 2168 Scarlet', 'ZK2201374', '12 Kg', '08-03-2023', 'Triadi', 'HI2168', '23-11-2024', 'Accept'),
(3, 'PET LINER', '-', '4  Roll', '15-02-2023', 'Triadi', 'SDK 100 T-TI', '-', 'Accept'),
(4, 'Pel Urethane MU 662A', '43822310017', '540 Kg', '01-03-2023', 'Triadi', 'MU-210 B', '-', 'Accept'),
(5, 'MTIA SF14R2', '710230039-4', '1 Roll', '01-03-2023', 'Triadi', '-', '01-03-2023', 'Accept'),
(6, '468MP Transfer Tape', 'WT 6009 1296-6', '25 Roll', '15-02-2023', 'Triadi', '-', '-', 'Accept'),
(7, 'LC 3111 PO', '301091393', '2 Roll', '21-03-2023', 'Haryono', '-', '-', 'Accept'),
(8, 'm-008', 'Lot-008', 'qty-8', '2023-04-14', 'insp-8', 'C-08', '2023-04-10', 'result 08'),
(9, 'm-009', 's-009', 'qt-009', '2023-04-18', 'Name 9', 'C-09', '2023-04-20', 'insp-9'),
(10, 'm-010', 's-010', 'qt-010', '2023-04-18', 'Name 10', 'C-10', '2023-04-18', 'Insp-10'),
(11, 'm-011', 's-011', 'qt-011', '2023-04-18', 'Name11', 'C-11', '2023-04-18', 'Insp-11'),
(12, 'm-012', 's-012', 'qt-012', '2023-04-18', 'Name 12', 'C-12', '2023-04-18', 'Insp-12'),
(13, 'm-013', 's-013', 'qt-013', '2023-04-20', 'Name13', 'C-113', '2023-04-18', 'Insp-13'),
(14, 'm-014', 's-014', 'qt-014', '2023-04-20', 'Name 14', 'C-14', '2023-04-18', 'Insp-14'),
(15, 'm-015', 'coba buat hapus', 'qt-015', '2023-04-22', 'Name 15', 'C-15', '2023-04-15', 'Insp-15'),
(16, 'm-016', 's-016', 'qt-016', '2023-04-22', 'Name 16', 'C-16', '2023-04-15', 'Insp-16'),
(17, 'm-017', 's-017', 'qt-017', '2023-04-21', 'Name 17', 'C-17', '2023-04-22', 'result 17'),
(18, 'm-018', 's-018', 'qt-018', '2023-04-19', 'Name 18', 'C-18', '2023-04-22', 'insp-18'),
(19, 'm-19', 's-019', 'qt-019', '2023-04-19', 'Name 19', 'C-19', '2023-04-19', 'Insp-19'),
(20, 'm-020', 's-020', 'qt-020', '2023-04-19', 'Name 20', 'C-20', '2023-04-19', 'result 20');

-- --------------------------------------------------------

--
-- Table structure for table `t_laminate`
--

CREATE TABLE `t_laminate` (
  `mppr_id` varchar(50) NOT NULL,
  `mpqc_id` varchar(50) NOT NULL,
  `time_start` time NOT NULL,
  `time_finish` time NOT NULL,
  `qty_in` varchar(50) NOT NULL,
  `qty_out` varchar(50) NOT NULL,
  `eq_using` varchar(50) NOT NULL,
  `lmt_info` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `t_laminate`
--

INSERT INTO `t_laminate` (`mppr_id`, `mpqc_id`, `time_start`, `time_finish`, `qty_in`, `qty_out`, `eq_using`, `lmt_info`) VALUES
('001', '001', '05:05:00', '05:05:00', '200', '200', '200', 'test1'),
('5', '5', '00:00:00', '00:00:00', '55', '50', '50', '50'),
('59', '56', '11:42:00', '11:42:00', '55', '50', '50', '50');

-- --------------------------------------------------------

--
-- Table structure for table `t_mixing`
--

CREATE TABLE `t_mixing` (
  `material_id` varchar(50) NOT NULL,
  `material_name` varchar(50) NOT NULL,
  `cust_lot` varchar(50) NOT NULL,
  `ex_date` varchar(50) NOT NULL,
  `rcv_date` varchar(50) NOT NULL,
  `qty` varchar(50) NOT NULL,
  `insp_no` varchar(50) NOT NULL,
  `inspector` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `t_mixing`
--

INSERT INTO `t_mixing` (`material_id`, `material_name`, `cust_lot`, `ex_date`, `rcv_date`, `qty`, `insp_no`, `inspector`) VALUES
('F3ATZ', 'test', '123', '2024-01-09', '2023-04-09', '6 roll', '6', 'coba'),
('VJSSZ', 'test lagi', '123', '2023-04-09', '2023-04-09', '200', '1234', 'test');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `t_inspection`
--
ALTER TABLE `t_inspection`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `t_mixing`
--
ALTER TABLE `t_mixing`
  ADD PRIMARY KEY (`material_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `t_inspection`
--
ALTER TABLE `t_inspection`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=92;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
