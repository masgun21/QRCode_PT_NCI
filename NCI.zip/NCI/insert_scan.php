<?php
date_default_timezone_set("Asia/Jakarta");
	$resp = array();

	if(isset($_POST['scanned']) && $_POST['doc_num']){
		$doc_head = substr($_POST['doc_num'], 0, 3);
		$lbl = explode("*", $_POST['scanned']);
		$KanbanID = $lbl[0];

		//label checker
		if(sizeof($lbl) != 8){
			$resp['message'] = true;
			echo json_encode($resp);
			exit();
		}

		//kanban_string checker
		if(strlen($lbl[0]) >= 13){
			$lbl[0] = substr($lbl[0], -13);
		} else {
			$response['message'] = true;
			echo json_encode($response);
			exit();
		}
		
		$wip = 0;

		if(check_wip($lbl[1])){
			$wip = 1;
		}

		$kanban_status = check_kanban($wip, $KanbanID);


		if(!$kanban_status){
			$resp['message'] = true;
			echo json_encode($resp);
			exit();
		}

		if($doc_head == "FGH"){
			if($kanban_status[0] == '0' || $kanban_status[0] == NULL){
				OHT($wip, $KanbanID, $_POST['doc_num'], $_POST['userID']);
				$resp['message'] = false;
			} else {
				$resp['message'] = true;
			}
		} else if($doc_head == "CRT"){
			if($kanban_status[1] != '1' && $kanban_status[0] == '1'){
				CRT($wip, $KanbanID, $_POST['doc_num']);
				$resp['message'] = false;
			} else {
				$resp['message'] = true;
			}
		} else if($doc_head == "RFG"){
			if($kanban_status[0] == '1' && $kanban_status[1] != '1'){
				RFG($wip, $KanbanID, $_POST['doc_num']);
				$resp['message'] = false;
			} else {
				$resp['message'] = true;
			}
		}
	} else {
		$resp['message'] = true;
	}

echo json_encode($resp);

function OHT($wip, $kanban_id, $docnum, $user){
	require('dbcon.php');

	if($wip != 1){
		$sql = "UPDATE tbl_inventory SET on_hold='1', on_hold_date=?, hold_user=?, DOCNUM2=? WHERE Kanban_ID=? AND on_hold='0'";
	} else {
		$sql = "UPDATE tbl_inventory_WIP SET on_hold='1', on_hold_date=?, hold_user=?, DOCNUM2=? WHERE Kanban_ID=? AND on_hold IS NULL";
	}
	
	$stmt = $conn->prepare($sql);
	$stmt->execute([date('Y-m-d'), $user, $docnum, $kanban_id]);
}

function CRT($wip, $kanban_id, $docnum){
	require('dbcon.php');

	if($wip != 1){
		$sql = "UPDATE tbl_inventory SET disposed='1', disposed_date=?, DOCNUM_3=? WHERE Kanban_ID=? AND on_hold='1'";
	} else {
		$sql = "UPDATE tbl_inventory_WIP SET disposed='1', disposed_date=?, DOCNUM_3=? WHERE Kanban_ID=? AND on_hold='1'";
	}
	
	$stmt = $conn->prepare($sql);
	$stmt->execute([date('Y-m-d'), $docnum, $kanban_id]);	
}

function RFG($wip, $kanban_id, $docnum){
	require('dbcon.php');
	if($wip != 1){
		$sql = "UPDATE tbl_inventory SET on_hold='0', on_hold_date=NULL, DOCNUM_3=? WHERE Kanban_ID=? AND on_hold='1'";
	} else {
		$sql = "UPDATE tbl_inventory_WIP SET on_hold='0', on_hold_date=NULL, DOCNUM_3=? WHERE Kanban_ID=? AND on_hold='1'";
	}
	
	$stmt = $conn->prepare($sql);
	$stmt->execute([$docnum, $kanban_id]);
}

function check_kanban($wip, $kanban_id){
	require('dbcon.php');
	if($wip != 1){
		$sql = "SELECT on_hold, disposed FROM tbl_inventory WHERE Kanban_ID=?";
	} else {
		$sql = "SELECT on_hold, disposed FROM tbl_inventory_WIP WHERE Kanban_ID=?";

	}
	$stmt = $conn->prepare($sql);
	$stmt->execute([$kanban_id]);
	$x = array();
	if($data = $stmt->fetch(PDO::FETCH_ASSOC)){
		$x[0] = $data['on_hold'];
		$x[1] = $data['disposed'];
	} else {
		$x = false;
	}

	return $x;
}

function check_wip($part_code){
	require('dbcon.php');
	$sql = "SELECT MONTH_PP FROM tbl_parts WHERE PART_CODE=?";
	$stmt = $conn->prepare($sql);
	$stmt->execute([$part_code]);
	if($data = $stmt->fetch(PDO::FETCH_ASSOC)){
		if($data['MONTH_PP'] == "WIP" || $data['MONTH_PP'] == "WIP1" || $data['MONTH_PP'] == "WIP2"){
			return true;
		} else {
			if(substr($part_code,-1,1) == "P" || substr($part_code,-1,1) == "p"){
				return true;
			} else {
				return false;
			}
			return false;
		}
	}
}



?>