<?php 

	$resp = array();

	if(isset($_POST['DOCNUM']) && isset($_POST['SCAN'])){
		$lbl = explode("*", $_POST['SCAN']);
		$DOCHEAD = substr($_POST['DOCNUM'],0,3);

		$KanbanID = $lbl[0];
		$wip = 0;

		if(check_wip($lbl[1])){
			$wip = 1;
		}
		$kanban_status = check_kanban($wip, $KanbanID);

		if($DOCHEAD == "FGH"){
			if($kanban_status[0] == '1'){
				cancel_OHT($wip, $KanbanID);
				$resp['message'] = false;
				
			} else {
				$resp['message'] = true;
			}
		} else if($DOCHEAD == "CRT"){
			if($kanban_status[1] == '1' && $kanban_status[0] == '1'){
				cancel_CRT($wip, $KanbanID);
				$resp['message'] = false;
				
			} else {
				$resp['message'] = true;
			}
		} else if($DOCHEAD == "RFG"){
			if($kanban_status[0] == '0' && $kanban_status[1] != '1'){
				cancel_RFG($wip, $KanbanID);
				$resp['message'] = false;
				
			} else {
				$resp['message'] = true;
			}
		}


	} else {
		$resp['message'] = true;
	}

	echo json_encode($resp);


function cancel_OHT($wip, $kanban_id){
	require('dbcon.php');
	if($wip != 1){
		$sql = "UPDATE tbl_inventory SET on_hold='0', on_hold_date=NULL, hold_user=NULL, DOCNUM2=NULL WHERE Kanban_ID=?";
	} else {
		$sql = "UPDATE tbl_inventory_WIP SET on_hold=NULL, on_hold_date=NULL, hold_user=NULL, DOCNUM2=NULL WHERE Kanban_ID=?";
	}
	$stmt = $conn->prepare($sql);
	$stmt->execute([$kanban_id]);
}

function cancel_CRT($wip, $kanban_id){
	require('dbcon.php');
	if($wip != 1){
		$sql = "UPDATE tbl_inventory SET disposed=NULL, disposed_date=NULL, DOCNUM_3=NULL WHERE Kanban_ID=?";
	} else {
		$sql = "UPDATE tbl_inventory_WIP SET disposed=NULL, disposed_date=NULL, DOCNUM_3=NULL WHERE Kanban_ID=?";
		
	}
	$stmt = $conn->prepare($sql);
	$stmt->execute([$kanban_id]);
}

function cancel_RFG($wip, $kanban_id){
	require('dbcon.php');
	if($wip != 1){
		$sql= "UPDATE tbl_inventory SET DOCNUM_3=NULL, on_hold=1 WHERE Kanban_ID=?";
	} else {
		$sql= "UPDATE tbl_inventory_WIP SET DOCNUM_3=NULL, on_hold=1 WHERE Kanban_ID=?";
		
	}
	$stmt = $conn->prepare($sql);
	$stmt->execute([$kanban_id]);
}

function check_kanban($wip, $kanban_id){
	require('dbcon.php');
	if($wip != 1){
		$sql = "SELECT on_hold, disposed FROM tbl_inventory WHERE Kanban_ID=?";
	} else {
		$sql = "SELECT on_hold, disposed FROM tbl_inventory_WIP WHERE Kanban_ID=?";

	}
	$stmt = $conn->prepare($sql);
	$stmt->execute([$kanban_id]);
	$x = array();
	if($data = $stmt->fetch(PDO::FETCH_ASSOC)){
		$x[0] = $data['on_hold'];
		$x[1] = $data['disposed'];
	}

	return $x;
}

function check_wip($part_code){
	require('dbcon.php');
	$sql = "SELECT MONTH_PP FROM tbl_parts WHERE PART_CODE=?";
	$stmt = $conn->prepare($sql);
	$stmt->execute([$part_code]);
	if($data = $stmt->fetch(PDO::FETCH_ASSOC)){
		if($data['MONTH_PP'] == "WIP" || $data['MONTH_PP'] == "WIP1" || $data['MONTH_PP'] == "WIP2"){
			return true;
		} else {
			return false;
		}
	}
}


?>