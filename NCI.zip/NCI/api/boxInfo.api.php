<?php
	$path = dirname(__FILE__);
	require_once($path."/../config/su.inc.php");
	require_once($path."/../config/pickList.inc.php");
    session_start();

    header('Content-Type: application/json');
    $response = array();
    $json = array();

    $User = new User();
    if( !$User->logged_in ) {
        $response["success"] = false;
	    $response["message"] = "Session timeout";
		echo json_encode($response);
		return;
    } else {
    	$param = "";
		if (ISSET($_GET['param'])){
			$param = $_GET['param'];
		} else {
			$param = file_get_contents("php://input");
		}
		if ( strlen($param) == 0 ) {
		    $response["success"] = false;
		    $response["message"] = "Required parameter(s) is missing";
			echo json_encode($response);
			return;
		}
    }
    $userId = $_SESSION[$User->sessionName]["userId"];

    $json = json_decode($param);
    $PickList = new PickList();
    if(sizeof($json) > 0){
    	$order_no = $json[0]->OrderNo;
    	$order_cName = $json[0]->cName;
    	$order_time = $json[0]->OrderTime;
    	$order_received = $json[0]->OrderReceived;

    	for($x = 0; $x <= sizeof($json) - 1; $x++){
    				$data_cName = $json[$x]->cName;
					$data_OrderTime = $json[$x]->OrderTime;
					$data_OrderDate = $json[$x]->OrderDate;
					$data_OrderReceived = $json[$x]->OrderReceived;
					$data_OrderNo = $json[$x]->OrderNo;
					$data_production = $json[$x]->ProdDate;
					$data_RackID = $json[$x]->RackID;
					$data_PartCode = $json[$x]->PartCode;
					$data_qtyPerBox = $json[$x]->qtyPerBox;
					$data_qty = $json[$x]->pickQty;
					$data_PartNo = $json[$x]->PartNo;
					$data_PartName = $json[$x]->PartName;
					$data_PPU = $json[$x]->PPU;


			/*$isExist = $PickList->isExist($data_RackID, $data_production, $data_PartCode);
			if($isExist){
				$PickList->updatePickList($data_RackID, $data_production, $data_PartCode, $data_qty, $data_OrderNo);
			} else {
				$PickList->insertPickList($data_RackID, $data_production, $data_PartCode, $data_qty, $data_OrderNo);
			}*/

			$PickList->insertOrderChild($data_OrderNo, $data_RackID, $data_PartCode, $data_PartNo, $data_PartName, $data_production, $data_qty, $data_qtyPerBox, $order_received, $data_PPU);
    	}

    $PickList->insertOrder($data_OrderNo, $data_cName, $data_OrderTime, $data_OrderDate, $order_received);

    $response["success"] = true;
    $response["message"] = "Data Sent!";

    } else {
    	$response["success"] = false;
    	$response["message"] = "No data!";
    }
	echo json_encode($response);
?>