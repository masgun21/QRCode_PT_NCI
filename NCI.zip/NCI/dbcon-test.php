<?php

$serverName = "WS-DAIHO\SQLEXPRESS";
$db_name = "DBJKT_TEST";
$conn = "";

try {
	$conn = new PDO("sqlsrv:server=".$serverName." ; Database=".$db_name, "", "");
	$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (Exception $e) {
	throw new Exception("SQL SERVER CONNECT COULD NOT BE ESTABLISHED ".$e->getMessage());
	
}

//1008884593 - scanned
//T000003044943 not scanned

?>

